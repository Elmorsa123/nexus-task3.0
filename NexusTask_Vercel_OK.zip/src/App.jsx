import React from 'react';

export default function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', textAlign: 'center', marginTop: '40px' }}>
      <h1>Bienvenido a Nexus Task</h1>
      <p>Tu app está desplegada correctamente en Vercel.</p>
    </div>
  );
}