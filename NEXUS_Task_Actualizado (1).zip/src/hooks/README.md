# Custom Hooks

This directory contains custom React hooks used throughout the NEXUS Task application.

## `useDataManagement.js`

This hook is responsible for managing the application's core data, including incidents, tasks, cleaning jobs, and users. It handles:

- Initializing data from `localStorage` or default values.
- Providing functions to add, update, and delete data items.
- Persisting changes to `localStorage`.
- Displaying toast notifications for data operations.

### Usage

Import the hook into your component:

```jsx
import { useDataManagement } from '@/hooks/useDataManagement';

function MyComponent() {
  const { incidents, addTask, users, handleShowToast } = useDataManagement();
  // ... use the data and functions
}
```

This centralizes data logic, making components cleaner and data management more consistent across the application.