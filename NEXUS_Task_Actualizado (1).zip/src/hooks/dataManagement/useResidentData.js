
import { useState, useEffect } from 'react';
import { logAction, useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const RESIDENTS_STORAGE_KEY = 'nexus-residents';

export const useResidentData = (initialResidents = [], handleShowToast, fetchData) => {
  const [residents, setResidents] = useLocalStorage(RESIDENTS_STORAGE_KEY, initialResidents);

  useEffect(() => {
    if (typeof fetchData === 'function') {
      fetchData('residents', setResidents, 'Error cargando residentes', 'name', true);
    }
  }, [fetchData, setResidents]);

  const addResident = async (newResident) => {
    const processedResident = {
      ...newResident,
      id: parseInt(Date.now().toString().slice(-8)),
      medications: (newResident.medications || []).map(med => ({ ...med, status: 'pending' })),
      created_at: new Date().toISOString(),
    };
    
    const { data, error } = await supabase.from('residents').insert(processedResident).select().single();
    
    if (error) {
      handleShowToast("Error al añadir residente", error.message, "destructive");
    } else {
      setResidents(prevResidents => [data, ...prevResidents].sort((a,b) => a.name.localeCompare(b.name)));
      handleShowToast("Residente Añadido", `El residente "${data.name}" ha sido creado.`, "success");
      logAction('create', 'resident', data.id, { name: data.name });
    }
  };

  const updateResident = async (updatedResidentData) => {
    const { data, error } = await supabase.from('residents').update(updatedResidentData).eq('id', updatedResidentData.id).select().single();

    if (error) {
      handleShowToast("Error al actualizar residente", error.message, "destructive");
    } else {
      setResidents(prevResidents => prevResidents.map(res => res.id === data.id ? data : res).sort((a,b) => a.name.localeCompare(b.name)));
      handleShowToast("Residente Actualizado", `El residente "${data.name}" ha sido actualizado.`, "success");
      logAction('update', 'resident', data.id, { changes: Object.keys(updatedResidentData) });
    }
  };

  const deleteResident = async (residentId, residentName) => {
    const { error } = await supabase.from('residents').delete().eq('id', residentId);
    
    if (error) {
      handleShowToast("Error al eliminar residente", error.message, "destructive");
    } else {
      setResidents(prevResidents => prevResidents.filter(res => res.id !== residentId));
      handleShowToast("Residente Eliminado", `El residente "${residentName}" ha sido eliminado.`, "destructive");
      logAction('delete', 'resident', residentId, { name: residentName });
    }
  };

  const updateResidentMedicationStatus = async (residentId, medIndex, newStatus) => {
    const resident = residents.find(r => r.id === residentId);
    if (!resident) return;

    const newMedications = [...resident.medications];
    if (newMedications[medIndex]) {
      newMedications[medIndex].status = newStatus;
    } else {
      return;
    }
    
    const { data, error } = await supabase.from('residents').update({ medications: newMedications }).eq('id', residentId).select().single();
    
    if (error) {
      handleShowToast("Error al actualizar medicación", error.message, "destructive");
    } else {
      setResidents(prevResidents => prevResidents.map(res => res.id === residentId ? data : res));
      handleShowToast("Medicación Actualizada", `Estado de medicación actualizado.`, "success");
      logAction('update_med_status', 'resident', residentId, { medIndex, newStatus });
    }
  };
  
  return { residents, setResidents, addResident, updateResident, deleteResident, updateResidentMedicationStatus };
};
