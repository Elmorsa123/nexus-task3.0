
import { useState, useEffect } from 'react';
import { logAction, useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const INCIDENTS_STORAGE_KEY = 'nexus-incidents';

export const useIncidentData = (initialIncidents = [], handleShowToast, fetchData) => {
  const [incidents, setIncidents] = useLocalStorage(INCIDENTS_STORAGE_KEY, initialIncidents);

  useEffect(() => {
    if (typeof fetchData === 'function') {
      fetchData('incidents', setIncidents, 'Error cargando incidencias', 'reporteddate', false);
    }
  }, [fetchData, setIncidents]);

  const addIncident = async (newIncident) => {
    const processedIncident = { 
      ...newIncident, 
      id: parseInt(Date.now().toString().slice(-9)), 
      assignedto: newIncident.assignedto === 'NONE' ? null : newIncident.assignedto,
      reporteddate: newIncident.reporteddate || new Date().toISOString().split('T')[0],
      created_at: new Date().toISOString(),
    };
    
    const { data, error } = await supabase.from('incidents').insert(processedIncident).select().single();
    
    if (error) {
      handleShowToast("Error al añadir incidencia", error.message, "destructive");
    } else {
      setIncidents(prevIncidents => [data, ...prevIncidents].sort((a,b) => new Date(b.reporteddate) - new Date(a.reporteddate)));
      handleShowToast("Incidencia Añadida", `La incidencia "${data.title}" ha sido creada.`, "success");
      logAction('create', 'incident', data.id, { title: data.title });
    }
  };

  const updateIncident = async (updatedIncidentData) => {
    const processedIncident = { 
      ...updatedIncidentData, 
      assignedto: updatedIncidentData.assignedto === 'NONE' ? null : updatedIncidentData.assignedto,
    };
    
    const { data, error } = await supabase.from('incidents').update(processedIncident).eq('id', processedIncident.id).select().single();
    
    if (error) {
      handleShowToast("Error al actualizar incidencia", error.message, "destructive");
    } else {
      setIncidents(prevIncidents => prevIncidents.map(inc => inc.id === data.id ? data : inc).sort((a,b) => new Date(b.reporteddate) - new Date(a.reporteddate)));
      handleShowToast("Incidencia Actualizada", `La incidencia "${data.title}" ha sido actualizada.`, "success");
      logAction('update', 'incident', data.id, { changes: Object.keys(processedIncident) });
    }
  };

  return { incidents, setIncidents, addIncident, updateIncident };
};
