
import { useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

export const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    if (typeof window === 'undefined') {
      return initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    try {
      if (storedValue === undefined && !window.localStorage.getItem(key)) {
        window.localStorage.setItem(key, JSON.stringify(initialValue));
        setStoredValue(initialValue);
      } else {
         window.localStorage.setItem(key, JSON.stringify(storedValue));
      }
    } catch (error) {
      console.error(error);
    }
  }, [key, storedValue, initialValue]);
  
  return [storedValue, setStoredValue];
};

export const logAction = async (action_type, entity_type, entity_id, details = {}, user_id = null) => {
  if (!supabase) return;
  
  const publicUserId = user_id;
  
  const { error } = await supabase.from('action_logs').insert([
    { action_type, entity_type, entity_id, details, user_id: publicUserId },
  ]);

  if (error) {
    console.error('Error logging action:', error);
  }
};

export const useToastHandler = () => {
  const handleShowToast = useCallback((title, description, variant = 'default') => {
    toast({ title: title || "🚧 Función no implementada", description: description || "¡Puedes solicitarla en tu próximo prompt! 🚀", variant });
  }, []);
  return handleShowToast;
};

export const useSupabaseDataFetcher = (handleShowToast) => {
  const fetchData = useCallback(async (table, setter, errorMessage, orderBy = 'created_at', ascending = false) => {
    if (!supabase) {
      handleShowToast("Supabase no conectado", "El cliente de Supabase no está disponible.", 'destructive');
      return;
    }
    
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .order(orderBy, { ascending });

    if (error) {
      console.error(`Error fetching ${table}:`, error);
      handleShowToast(errorMessage, error.message, 'destructive');
      setter([]);
    } else {
      setter(data);
    }
  }, [handleShowToast]);
  return fetchData;
};
