
import { useState, useEffect } from 'react';
import { logAction, useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const USERS_STORAGE_KEY = 'nexus-users';

export const useUserData = (initialUsers = [], handleShowToast, createRoleIfNotExists, setRoles, fetchData) => {
  const [users, setUsers] = useLocalStorage(USERS_STORAGE_KEY, initialUsers);

  useEffect(() => {
    if (typeof fetchData === 'function') {
      fetchData('users', setUsers, 'Error cargando usuarios', 'name', true);
    }
  }, [fetchData, setUsers]);


  const addUser = async (userData) => {
    const { customRole, ...userFields } = userData;
    let finalCustomRoles = userFields.custom_roles || [];

    if (customRole && customRole.trim() !== "") {
      const newRoleName = customRole.trim();
      await createRoleIfNotExists(newRoleName);
      if (!finalCustomRoles.includes(newRoleName)) {
        finalCustomRoles = [...finalCustomRoles, newRoleName];
      }
    }
    
    const newUser = { 
      ...userFields, 
      id: parseInt(Date.now().toString().slice(-9)), 
      status: 'active', 
      custom_roles: finalCustomRoles.length > 0 ? finalCustomRoles : null,
      created_at: new Date().toISOString()
    };
    
    const { data, error } = await supabase.from('users').insert(newUser).select().single();

    if (error) {
      handleShowToast("Error al añadir usuario", error.message, "destructive");
    } else {
      setUsers(prevUsers => [data, ...prevUsers]);
      handleShowToast("Usuario Añadido", `El usuario "${data.name}" ha sido creado.`, "success");
      logAction('create', 'user', data.id, { name: data.name, custom_roles: data.custom_roles });
    }
  };

  const updateUser = async (updatedUserData) => {
    const { customRole, ...userFields } = updatedUserData;
    let finalCustomRoles = userFields.custom_roles || [];

    if (customRole && customRole.trim() !== "") {
      const newRoleName = customRole.trim();
      await createRoleIfNotExists(newRoleName);
      if (!finalCustomRoles.includes(newRoleName)) {
        finalCustomRoles = [...finalCustomRoles, newRoleName];
      }
    }
    
    const updatedUser = { 
      ...userFields, 
      custom_roles: finalCustomRoles.length > 0 ? finalCustomRoles : null 
    };

    const { data, error } = await supabase.from('users').update(updatedUser).eq('id', updatedUser.id).select().single();
    
    if (error) {
      handleShowToast("Error al actualizar usuario", error.message, "destructive");
    } else {
      setUsers(prevUsers => prevUsers.map(user => user.id === data.id ? data : user));
      handleShowToast("Usuario Actualizado", `El usuario "${data.name}" ha sido actualizado.`, "success");
      logAction('update', 'user', data.id, { name: data.name, custom_roles: data.custom_roles });
    }
  };

  const deleteUser = async (userId, userName) => {
    const { error } = await supabase.from('users').delete().eq('id', userId);

    if (error) {
      handleShowToast("Error al eliminar usuario", error.message, "destructive");
    } else {
      setUsers(prevUsers => prevUsers.filter(user => user.id !== userId));
      handleShowToast("Usuario Eliminado", `El usuario "${userName}" ha sido eliminado.`, "destructive");
      logAction('delete', 'user', userId, { name: userName });
    }
  };

  const toggleUserStatus = async (userId) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;
    
    const newStatus = user.status === 'active' ? 'inactive' : 'active';
    const { data, error } = await supabase.from('users').update({ status: newStatus }).eq('id', userId).select().single();

    if (error) {
      handleShowToast("Error al cambiar estado", error.message, "destructive");
    } else {
      setUsers(prevUsers => prevUsers.map(u => (u.id === userId ? data : u)));
      handleShowToast("Estado de Usuario Actualizado", `El usuario "${data.name}" ahora está ${data.status === 'active' ? 'activo' : 'inactivo'}.`, "success");
      logAction('status_change', 'user', userId, { status: newStatus });
    }
  };

  return { users, setUsers, addUser, updateUser, deleteUser, toggleUserStatus };
};
