
import { useState, useEffect } from 'react';
import { logAction, useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const TASKS_STORAGE_KEY = 'nexus-tasks';

export const useTaskData = (initialTasks = [], handleShowToast, fetchData) => {
  const [tasks, setTasks] = useLocalStorage(TASKS_STORAGE_KEY, initialTasks);

  useEffect(() => {
     if (typeof fetchData === 'function') {
      fetchData('tasks', setTasks, 'Error cargando tareas', 'duedate', false);
    }
  }, [fetchData, setTasks]);

  const addTask = async (newTask) => {
    const processedTask = { 
      ...newTask,
      assignedto: newTask.assignedto === 'NONE' ? null : newTask.assignedto,
      duedate: newTask.duedate || new Date().toISOString().split('T')[0],
      created_at: new Date().toISOString(),
    };
    
    const { data, error } = await supabase.from('tasks').insert(processedTask).select().single();
    
    if (error) {
      handleShowToast("Error al añadir tarea", error.message, "destructive");
    } else {
      setTasks(prevTasks => [data, ...prevTasks].sort((a,b) => new Date(b.duedate) - new Date(a.duedate)));
      handleShowToast("Tarea Añadida", `La tarea "${data.title}" ha sido creada.`, "success");
      logAction('create', 'task', data.id, { title: data.title });
    }
  };

  const updateTask = async (updatedTaskData) => {
    const processedTask = { 
      ...updatedTaskData,
      assignedto: updatedTaskData.assignedto === 'NONE' ? null : updatedTaskData.assignedto,
    };

    const { data, error } = await supabase.from('tasks').update(processedTask).eq('id', processedTask.id).select().single();
    
    if (error) {
      handleShowToast("Error al actualizar tarea", error.message, "destructive");
    } else {
      setTasks(prevTasks => prevTasks.map(task => task.id === data.id ? data : task).sort((a,b) => new Date(b.duedate) - new Date(a.duedate)));
      handleShowToast("Tarea Actualizada", `La tarea "${data.title}" ha sido actualizada.`, "success");
      logAction('update', 'task', data.id, { changes: Object.keys(updatedTaskData) });
    }
  };
  
  const quickUpdateTask = async (taskId, field, value) => {
    let updateValue = value;
    if (field === 'assignedto' && value === 'NONE') {
      updateValue = null;
    }
    
    const { data, error } = await supabase.from('tasks').update({ [field]: updateValue }).eq('id', taskId).select().single();

    if (error) {
      handleShowToast("Error en actualización rápida", error.message, "destructive");
    } else {
      setTasks(prevTasks => prevTasks.map(task => 
        task.id === taskId ? data : task
      ).sort((a,b) => new Date(b.duedate) - new Date(a.duedate)));
      handleShowToast("Tarea Actualizada", `Campo ${field} de la tarea "${data.title}" actualizado.`, "success");
      logAction('quick_update', 'task', taskId, { field: field, value: updateValue });
    }
  };

  const updateTaskStatus = async (taskId, newStatus) => {
    const { data, error } = await supabase.from('tasks').update({ status: newStatus }).eq('id', taskId).select().single();

    if (error) {
      handleShowToast("Error al actualizar estado", error.message, "destructive");
    } else {
      setTasks(prevTasks => prevTasks.map(task => task.id === taskId ? data : task).sort((a,b) => new Date(b.duedate) - new Date(a.duedate)));
      let toastMessage = `Estado de "${data.title}" actualizado.`;
      if (newStatus === 'completed') toastMessage = `¡"${data.title}" completada! 🎉`;
      else if (newStatus === 'progress') toastMessage = `"${data.title}" ahora en progreso.`;
      else if (newStatus === 'pending') toastMessage = `"${data.title}" marcada como pendiente.`;
      
      handleShowToast("Estado Actualizado", toastMessage, "success");
      logAction('status_change', 'task', taskId, { status: newStatus });
    }
  };

  return { tasks, setTasks, addTask, updateTask, quickUpdateTask, updateTaskStatus };
};
