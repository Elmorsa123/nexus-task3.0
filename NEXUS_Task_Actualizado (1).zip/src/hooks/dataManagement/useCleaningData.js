
import { useState, useEffect } from 'react';
import { logAction, useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const CLEANING_JOBS_STORAGE_KEY = 'nexus-cleaning-jobs';

export const useCleaningData = (initialCleaningJobs = [], handleShowToast, fetchData) => {
  const [cleaningJobs, setCleaningJobs] = useLocalStorage(CLEANING_JOBS_STORAGE_KEY, initialCleaningJobs);

  useEffect(() => {
    if (typeof fetchData === 'function') {
      fetchData('cleaning_jobs', setCleaningJobs, 'Error cargando tareas de limpieza', 'next_clean_due', true);
    }
  }, [fetchData, setCleaningJobs]);

  const addCleaningJob = async (newJob) => {
    const processedJob = { 
      ...newJob, 
      id: parseInt(Date.now().toString().slice(-8)),
      responsible: newJob.responsible === 'NONE' ? null : newJob.responsible,
      created_at: new Date().toISOString(),
    };

    const { data, error } = await supabase.from('cleaning_jobs').insert(processedJob).select().single();

    if (error) {
      handleShowToast("Error al añadir tarea de limpieza", error.message, "destructive");
    } else {
      setCleaningJobs(prevJobs => [data, ...prevJobs].sort((a,b) => new Date(a.next_clean_due) - new Date(b.next_clean_due)));
      handleShowToast("Tarea de Limpieza Añadida", `La tarea para "${data.area}" ha sido creada.`, "success");
      logAction('create', 'cleaning_job', data.id, { area: data.area });
    }
  };

  const updateCleaningJobStatus = async (jobId, newStatus) => {
    const { data, error } = await supabase.from('cleaning_jobs').update({ status: newStatus }).eq('id', jobId).select().single();

    if (error) {
      handleShowToast("Error al actualizar estado", error.message, "destructive");
    } else {
      setCleaningJobs(prevJobs => prevJobs.map(job => (job.id === jobId ? data : job)).sort((a,b) => new Date(a.next_clean_due) - new Date(b.next_clean_due)));
      handleShowToast("Estado Actualizado", `Tarea de limpieza para "${data.area}" actualizada a ${newStatus}.`, "success");
      logAction('status_change', 'cleaning_job', jobId, { status: newStatus });
    }
  };
  
  return { cleaningJobs, setCleaningJobs, addCleaningJob, updateCleaningJobStatus };
};
