
import { useState, useEffect } from 'react';
import { useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const ROLES_STORAGE_KEY = 'nexus-roles';

export const useRoleData = (initialRoles = [], handleShowToast, fetchData) => {
  const [roles, setRoles] = useLocalStorage(ROLES_STORAGE_KEY, initialRoles);

  useEffect(() => {
    if (typeof fetchData === 'function') {
      fetchData('roles', setRoles, 'Error cargando roles', 'name', true);
    }
  }, [fetchData, setRoles]);
  
  const createRoleIfNotExists = async (roleName) => {
    const { data: existingRoles, error: findError } = await supabase.from('roles').select('id, name').eq('name', roleName);
    if (findError) {
      handleShowToast("Error buscando rol", findError.message, "destructive");
      return null;
    }
    if (existingRoles && existingRoles.length > 0) {
      return existingRoles[0];
    }
    
    const newRole = { id: parseInt(Date.now().toString().slice(-7)), name: roleName, permissions: {} };
    const { data, error } = await supabase.from('roles').insert(newRole).select().single();

    if (error) {
      handleShowToast("Error creando rol", error.message, "destructive");
      return null;
    }

    setRoles(prev => [...prev, data].sort((a, b) => a.name.localeCompare(b.name)));
    handleShowToast("Rol Creado", `Rol "${data.name}" creado.`, "info");
    return data;
  };

  return { roles, setRoles, createRoleIfNotExists };
};
