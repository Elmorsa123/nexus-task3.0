
import { useState, useEffect } from 'react';
import { logAction, useLocalStorage } from './useSharedDataLogic';
import { supabase } from '@/lib/supabaseClient';

const IDEAS_STORAGE_KEY = 'nexus-ideas';

export const useIdeasData = (initialIdeas = [], handleShowToast, fetchData, currentUser) => {
  const [ideas, setIdeas] = useLocalStorage(IDEAS_STORAGE_KEY, initialIdeas);

  useEffect(() => {
    if (typeof fetchData === 'function') {
      fetchData('ideas', setIdeas, 'Error cargando ideas', 'created_at', false);
    }
  }, [fetchData, setIdeas]);

  const addIdea = async (newIdea) => {
    const processedIdea = { 
      ...newIdea, 
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      created_by: currentUser?.id,
    };
    
    const { data, error } = await supabase.from('ideas').insert(processedIdea).select().single();

    if (error) {
      handleShowToast("Error al añadir idea", error.message, "destructive");
    } else {
      setIdeas(prevIdeas => [data, ...prevIdeas]);
      handleShowToast("Idea Añadida", `La idea "${data.title}" ha sido creada.`, "success");
      logAction('create', 'idea', data.id, { title: data.title });
    }
  };

  const updateIdea = async (updatedIdeaData) => {
    const { data, error } = await supabase.from('ideas').update(updatedIdeaData).eq('id', updatedIdeaData.id).select().single();

    if (error) {
      handleShowToast("Error al actualizar idea", error.message, "destructive");
    } else {
      setIdeas(prevIdeas => prevIdeas.map(idea => idea.id === data.id ? data : idea));
      handleShowToast("Idea Actualizada", `La idea "${data.title}" ha sido actualizada.`, "success");
      logAction('update', 'idea', data.id, { changes: Object.keys(updatedIdeaData) });
    }
  };

  const deleteIdea = async (ideaId, ideaTitle) => {
    const { error } = await supabase.from('ideas').delete().eq('id', ideaId);
    
    if (error) {
      handleShowToast("Error al eliminar idea", error.message, "destructive");
    } else {
      setIdeas(prevIdeas => prevIdeas.filter(idea => idea.id !== ideaId));
      handleShowToast("Idea Eliminada", `La idea "${ideaTitle}" ha sido eliminada.`, "destructive");
      logAction('delete', 'idea', ideaId, { title: ideaTitle });
    }
  };
  
  return { ideas, setIdeas, addIdea, updateIdea, deleteIdea };
};
