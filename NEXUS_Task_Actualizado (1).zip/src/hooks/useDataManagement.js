
import { useToastHandler, useSupabaseDataFetcher, logAction as sharedLogAction } from './dataManagement/useSharedDataLogic';
import { useIncidentData } from './dataManagement/useIncidentData';
import { useTaskData } from './dataManagement/useTaskData';
import { useRoleData } from './dataManagement/useRoleData';
import { useUserData } from './dataManagement/useUserData';
import { useResidentData } from './dataManagement/useResidentData';
import { useCleaningData } from './dataManagement/useCleaningData';
import { useIdeasData } from './dataManagement/useIdeasData';
import { supabase } from '@/lib/supabaseClient';


export const useDataManagement = (currentUser) => {
  const handleShowToast = useToastHandler();
  const fetchData = useSupabaseDataFetcher(handleShowToast); 

  const { incidents, setIncidents, addIncident, updateIncident } = useIncidentData([], handleShowToast, fetchData);
  const { tasks, setTasks, addTask, updateTask, quickUpdateTask, updateTaskStatus } = useTaskData([], handleShowToast, fetchData);
  const { roles, setRoles, createRoleIfNotExists } = useRoleData([], handleShowToast, fetchData);
  const { users, setUsers, addUser, updateUser, deleteUser, toggleUserStatus } = useUserData([], handleShowToast, createRoleIfNotExists, setRoles, fetchData);
  const { residents, setResidents, addResident, updateResident, deleteResident, updateResidentMedicationStatus } = useResidentData([], handleShowToast, fetchData);
  const { cleaningJobs, setCleaningJobs, addCleaningJob, updateCleaningJobStatus } = useCleaningData([], handleShowToast, fetchData);
  const { ideas, setIdeas, addIdea, updateIdea, deleteIdea } = useIdeasData([], handleShowToast, fetchData, currentUser);

  const resetAllData = async () => {
    const tablesToReset = ['tasks', 'incidents', 'residents', 'cleaning_jobs', 'user_roles', 'users', 'roles', 'action_logs', 'ideas'];
    
    handleShowToast("Iniciando reseteo...", "Eliminando todos los datos de las tablas.", "info");

    for (const table of tablesToReset) {
      const { error } = await supabase.from(table).delete().neq('id', 'this-will-never-be-true');
      if (error) {
        console.error(`Error reseteando tabla ${table}:`, error);
        handleShowToast(`Error en ${table}`, error.message, "destructive");
        return; 
      }
    }
      
    setTasks([]);
    setIncidents([]);
    setResidents([]);
    setCleaningJobs([]);
    setUsers([]);
    setRoles([]);
    setIdeas([]);
    
    handleShowToast("Datos Reseteados", "Todos los datos han sido eliminados de Supabase.", "success");
    sharedLogAction('reset_all_data', 'application', null, {}, currentUser?.profile?.id);
  };


  return {
    incidents, tasks, cleaningJobs, users, roles, residents, ideas,
    handleShowToast,
    addIncident, updateIncident,
    addTask, updateTask, quickUpdateTask, updateTaskStatus,
    addUser, updateUser, deleteUser, toggleUserStatus,
    addResident, updateResident, deleteResident, updateResidentMedicationStatus,
    addCleaningJob, updateCleaningJobStatus,
    addIdea, updateIdea, deleteIdea,
    logAction: (action_type, entity_type, entity_id, details) => sharedLogAction(action_type, entity_type, entity_id, details, currentUser?.profile?.id),
    resetAllData,
  };
};
