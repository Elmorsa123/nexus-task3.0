
export const mockNotifications = [
  {
    id: '1',
    type: 'task_overdue',
    title: 'Tarea vencida',
    message: 'La tarea "Revisión mensual de extintores" venció hace 2 días',
    priority: 'high',
    user: 'Juan García (Mantenimiento)',
    created_at: '2025-06-16T08:00:00Z',
    read: false
  },
  {
    id: '2',
    type: 'medication_reminder',
    title: 'Recordatorio de medicación',
    message: 'Carmen García López necesita tomar Enalapril a las 20:00',
    priority: 'high',
    user: 'Ana Torres (Enfermería)',
    created_at: '2025-06-16T19:45:00Z',
    read: false
  },
  {
    id: '3',
    type: 'incident_assigned',
    title: 'Nueva incidencia asignada',
    message: 'Se te ha asignado la incidencia "Puerta de emergencia bloqueada"',
    priority: 'medium',
    user: 'Juan García (Mantenimiento)',
    created_at: '2025-06-16T08:15:00Z',
    read: true
  },
  {
    id: '4',
    type: 'cleaning_due',
    title: 'Limpieza programada',
    message: 'La limpieza de "Baños Planta 1" está programada para hoy',
    priority: 'medium',
    user: 'Laura Pérez (Limpieza)',
    created_at: '2025-06-16T07:00:00Z',
    read: false
  },
  {
    id: '5',
    type: 'system_update',
    title: 'Actualización del sistema',
    message: 'Nueva funcionalidad de estadísticas disponible',
    priority: 'low',
    user: 'all',
    created_at: '2025-06-15T12:00:00Z',
    read: true
  }
];
