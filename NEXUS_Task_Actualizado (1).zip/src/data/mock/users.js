
export const mockUsers = [
  {
    id: '1',
    name: 'Juan García (Mantenimiento)',
    email: 'juan.garcia@residencia.com',
    status: 'active',
    roles: [{ id: '1', name: 'Técnico' }],
    custom_roles: ['Técnico'],
    created_at: '2024-01-01T00:00:00Z',
    last_login: '2025-06-16T08:00:00Z',
    tasks_completed: 15,
    tasks_pending: 3
  },
  {
    id: '2',
    name: 'Laura Pérez (Limpieza)',
    email: 'laura.perez@residencia.com',
    status: 'active',
    roles: [{ id: '2', name: 'Responsable' }],
    custom_roles: ['Responsable'],
    created_at: '2024-01-01T00:00:00Z',
    last_login: '2025-06-16T07:30:00Z',
    tasks_completed: 22,
    tasks_pending: 1
  },
  {
    id: '3',
    name: 'Ana Torres (Enfermería)',
    email: 'ana.torres@residencia.com',
    status: 'active',
    roles: [{ id: '3', name: 'Enfermera' }],
    custom_roles: ['Enfermera'],
    created_at: '2024-01-01T00:00:00Z',
    last_login: '2025-06-16T06:45:00Z',
    tasks_completed: 28,
    tasks_pending: 2
  },
  {
    id: '4',
    name: 'Carlos Ruiz (Jardinería)',
    email: 'carlos.ruiz@residencia.com',
    status: 'active',
    roles: [{ id: '1', name: 'Técnico' }],
    custom_roles: ['Técnico'],
    created_at: '2024-01-01T00:00:00Z',
    last_login: '2025-06-15T14:20:00Z',
    tasks_completed: 8,
    tasks_pending: 2
  },
  {
    id: '5',
    name: 'Pedro Administrador',
    email: 'pedro.admin@residencia.com',
    status: 'active',
    roles: [{ id: '4', name: 'Administrador' }],
    custom_roles: ['Administrador'],
    created_at: '2024-01-01T00:00:00Z',
    last_login: '2025-06-16T09:00:00Z',
    tasks_completed: 5,
    tasks_pending: 1
  },
  {
    id: '6',
    name: 'María Fernández (Cocina)',
    email: 'maria.fernandez@residencia.com',
    status: 'active',
    roles: [{ id: '2', name: 'Responsable' }],
    custom_roles: ['Responsable'],
    created_at: '2024-01-01T00:00:00Z',
    last_login: '2025-06-15T11:30:00Z',
    tasks_completed: 12,
    tasks_pending: 3
  }
];
