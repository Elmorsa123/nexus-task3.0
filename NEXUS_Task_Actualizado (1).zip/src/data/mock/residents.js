
export const mockResidents = [
  {
    id: '1',
    name: 'Carmen García López',
    room_number: '101',
    photo_url: '',
    age: 78,
    admission_date: '2023-06-15',
    emergency_contact: 'Luis García (Hijo) - 666-123-456',
    medical_notes: 'Hipertensión controlada, diabetes tipo 2',
    medications: [
      { name: 'Enalapril', dosage: '10mg', schedule: '08:00, 20:00', status: 'pending', last_taken: '2025-06-15T20:00:00Z' },
      { name: 'Omeprazol', dosage: '20mg', schedule: '08:00', status: 'taken', last_taken: '2025-06-16T08:00:00Z' },
      { name: 'Metformina', dosage: '850mg', schedule: '08:00, 14:00, 20:00', status: 'pending', last_taken: '2025-06-15T20:00:00Z' }
    ],
    created_at: '2024-01-01T00:00:00Z'
  },
  {
    id: '2',
    name: 'José Martínez Ruiz',
    room_number: '102',
    photo_url: '',
    age: 82,
    admission_date: '2023-08-22',
    emergency_contact: 'Carmen Martínez (Hija) - 666-789-123',
    medical_notes: 'Problemas cardíacos, colesterol alto',
    medications: [
      { name: 'Simvastatina', dosage: '20mg', schedule: '22:00', status: 'taken', last_taken: '2025-06-15T22:00:00Z' },
      { name: 'Aspirina', dosage: '100mg', schedule: '08:00', status: 'pending', last_taken: '2025-06-15T08:00:00Z' },
      { name: 'Atenolol', dosage: '50mg', schedule: '08:00, 20:00', status: 'pending', last_taken: '2025-06-15T20:00:00Z' }
    ],
    created_at: '2024-01-01T00:00:00Z'
  },
  {
    id: '3',
    name: 'María Fernández Soto',
    room_number: '103',
    photo_url: '',
    age: 75,
    admission_date: '2023-11-10',
    emergency_contact: 'Pedro Fernández (Hijo) - 666-456-789',
    medical_notes: 'Artritis, movilidad reducida',
    medications: [
      { name: 'Amlodipino', dosage: '5mg', schedule: '08:00', status: 'pending', last_taken: '2025-06-15T08:00:00Z' },
      { name: 'Ibuprofeno', dosage: '400mg', schedule: '08:00, 20:00', status: 'taken', last_taken: '2025-06-16T08:00:00Z' }
    ],
    created_at: '2024-01-01T00:00:00Z'
  },
  {
    id: '4',
    name: 'Antonio Rodríguez Vega',
    room_number: '201',
    photo_url: '',
    age: 85,
    admission_date: '2023-04-03',
    emergency_contact: 'Isabel Rodríguez (Hija) - 666-321-654',
    medical_notes: 'Insuficiencia cardíaca, edemas',
    medications: [
      { name: 'Furosemida', dosage: '40mg', schedule: '08:00', status: 'taken', last_taken: '2025-06-16T08:00:00Z' },
      { name: 'Digoxina', dosage: '0.25mg', schedule: '08:00', status: 'pending', last_taken: '2025-06-15T08:00:00Z' },
      { name: 'Ramipril', dosage: '5mg', schedule: '20:00', status: 'pending', last_taken: '2025-06-15T20:00:00Z' }
    ],
    created_at: '2024-01-01T00:00:00Z'
  },
  {
    id: '5',
    name: 'Dolores Jiménez Castro',
    room_number: '202',
    photo_url: '',
    age: 79,
    admission_date: '2023-09-18',
    emergency_contact: 'Miguel Jiménez (Hijo) - 666-987-321',
    medical_notes: 'Alzheimer inicial, necesita supervisión',
    medications: [
      { name: 'Donepezilo', dosage: '10mg', schedule: '20:00', status: 'taken', last_taken: '2025-06-15T20:00:00Z' },
      { name: 'Lorazepam', dosage: '1mg', schedule: '22:00', status: 'pending', last_taken: '2025-06-15T22:00:00Z' }
    ],
    created_at: '2024-01-01T00:00:00Z'
  },
  {
    id: '6',
    name: 'Francisco López Moreno',
    room_number: '203',
    photo_url: '',
    age: 88,
    admission_date: '2023-02-14',
    emergency_contact: 'Ana López (Nieta) - 666-654-987',
    medical_notes: 'Diabetes, problemas de visión',
    medications: [
      { name: 'Insulina', dosage: '20 UI', schedule: '08:00, 14:00, 20:00', status: 'pending', last_taken: '2025-06-15T20:00:00Z' },
      { name: 'Metformina', dosage: '1000mg', schedule: '08:00, 20:00', status: 'taken', last_taken: '2025-06-16T08:00:00Z' }
    ],
    created_at: '2024-01-01T00:00:00Z'
  }
];
