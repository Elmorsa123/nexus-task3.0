
export const mockIdeas = [
  {
    id: '1',
    title: 'Sistema de notificaciones automáticas',
    description: 'Implementar un sistema que envíe notificaciones automáticas cuando una tarea esté próxima a vencer o cuando se detecten patrones de incidencias repetitivas.',
    status: 'pending',
    category: 'Tecnología',
    priority: 'high',
    estimated_impact: 'Alto',
    submitted_by: 'Ana Torres (Enfermería)',
    votes: 8,
    created_at: '2025-06-10T10:00:00Z'
  },
  {
    id: '2',
    title: 'App móvil para familiares',
    description: 'Desarrollar una aplicación móvil que permita a los familiares ver el estado de salud y actividades de sus seres queridos en tiempo real.',
    status: 'applied',
    category: 'Tecnología',
    priority: 'medium',
    estimated_impact: 'Alto',
    submitted_by: 'Pedro Administrador',
    votes: 12,
    implementation_date: '2025-06-05',
    created_at: '2025-06-05T15:30:00Z'
  },
  {
    id: '3',
    title: 'Optimización de rutas de limpieza',
    description: 'Crear rutas optimizadas para el personal de limpieza que reduzcan el tiempo de desplazamiento y mejoren la eficiencia del trabajo.',
    status: 'pending',
    category: 'Operaciones',
    priority: 'medium',
    estimated_impact: 'Medio',
    submitted_by: 'Laura Pérez (Limpieza)',
    votes: 6,
    created_at: '2025-06-12T09:15:00Z'
  },
  {
    id: '4',
    title: 'Sistema de reconocimiento facial',
    description: 'Implementar reconocimiento facial para el control de acceso y seguimiento de residentes con problemas de memoria.',
    status: 'pending',
    category: 'Seguridad',
    priority: 'high',
    estimated_impact: 'Alto',
    submitted_by: 'Juan García (Mantenimiento)',
    votes: 15,
    created_at: '2025-06-08T14:20:00Z'
  },
  {
    id: '5',
    title: 'Jardín terapéutico',
    description: 'Crear un espacio de jardín terapéutico con plantas aromáticas y senderos accesibles para actividades de rehabilitación.',
    status: 'applied',
    category: 'Bienestar',
    priority: 'medium',
    estimated_impact: 'Alto',
    submitted_by: 'Carlos Ruiz (Jardinería)',
    votes: 10,
    implementation_date: '2025-06-01',
    created_at: '2025-06-01T12:00:00Z'
  },
  {
    id: '6',
    title: 'Menús personalizados por IA',
    description: 'Utilizar inteligencia artificial para crear menús personalizados basados en las necesidades nutricionales y preferencias de cada residente.',
    status: 'pending',
    category: 'Alimentación',
    priority: 'low',
    estimated_impact: 'Medio',
    submitted_by: 'María Fernández (Cocina)',
    votes: 4,
    created_at: '2025-06-14T16:45:00Z'
  }
];
