
export const mockStatistics = {
  weekly_stats: {
    tasks_completed: 28,
    tasks_pending: 8,
    incidents_resolved: 5,
    incidents_pending: 3,
    completion_rate: 78,
    average_resolution_time: '2.5 días',
    most_active_user: 'Ana Torres (Enfermería)',
    most_common_task_type: 'Atención a residente'
  },
  monthly_stats: {
    tasks_completed: 112,
    tasks_pending: 15,
    incidents_resolved: 18,
    incidents_pending: 4,
    completion_rate: 88,
    average_resolution_time: '2.1 días',
    productivity_trend: '+12%',
    efficiency_score: 92
  },
  user_performance: [
    { name: 'Ana Torres (Enfermería)', completed: 28, pending: 2, efficiency: 93 },
    { name: 'Laura Pérez (Limpieza)', completed: 22, pending: 1, efficiency: 96 },
    { name: 'Juan García (Mantenimiento)', completed: 15, pending: 3, efficiency: 83 },
    { name: 'Carlos Ruiz (Jardinería)', completed: 8, pending: 2, efficiency: 80 },
    { name: 'Pedro Administrador', completed: 5, pending: 1, efficiency: 83 }
  ]
};
