
export const mockIncidents = [
  {
    id: '1',
    title: 'Fuga de agua en habitación 205',
    description: 'Se ha detectado una fuga de agua en el baño de la habitación 205. El agua está filtrándose hacia el pasillo.',
    status: 'pending',
    priority: 'high',
    residence: 'Residencia San Miguel',
    assignedto: 'Juan García (Mantenimiento)',
    reporteddate: '2024-01-15',
    created_at: '2024-01-15T10:30:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2024-01-15T10:30:00Z', details: 'Incidencia reportada' },
      { action: 'assigned', user: 'Ana Torres (Enfermería)', date: '2024-01-15T10:35:00Z', details: 'Asignada a Juan García' }
    ],
    comments: [
      { id: '1', user: 'Ana Torres (Enfermería)', message: 'Urgente: Los residentes no pueden usar el baño', date: '2024-01-15T10:32:00Z' }
    ]
  },
  {
    id: '2',
    title: 'Calefacción no funciona en zona común',
    description: 'La calefacción del salón principal no está funcionando correctamente. Los residentes se quejan del frío.',
    status: 'progress',
    priority: 'medium',
    residence: 'Residencia San Miguel',
    assignedto: 'Juan García (Mantenimiento)',
    reporteddate: '2024-01-14',
    created_at: '2024-01-14T14:20:00Z',
    history: [
      { action: 'created', user: 'Laura Pérez (Limpieza)', date: '2024-01-14T14:20:00Z', details: 'Incidencia reportada' },
      { action: 'assigned', user: 'Laura Pérez (Limpieza)', date: '2024-01-14T14:25:00Z', details: 'Asignada a Juan García' },
      { action: 'status_changed', user: 'Juan García (Mantenimiento)', date: '2024-01-15T09:00:00Z', details: 'Iniciado trabajo de reparación' }
    ],
    comments: [
      { id: '1', user: 'Juan García (Mantenimiento)', message: 'Revisando el sistema de calefacción central', date: '2024-01-15T09:05:00Z' }
    ]
  },
  {
    id: '3',
    title: 'Luz fundida en pasillo principal',
    description: 'Varias luces del pasillo principal están fundidas, creando zonas oscuras.',
    status: 'completed',
    priority: 'low',
    residence: 'Residencia San Miguel',
    assignedto: 'Carlos Ruiz (Jardinería)',
    reporteddate: '2024-01-13',
    created_at: '2024-01-13T09:15:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2024-01-13T09:15:00Z', details: 'Incidencia reportada' },
      { action: 'assigned', user: 'Ana Torres (Enfermería)', date: '2024-01-13T09:20:00Z', details: 'Asignada a Carlos Ruiz' },
      { action: 'completed', user: 'Carlos Ruiz (Jardinería)', date: '2024-01-13T16:30:00Z', details: 'Luces reemplazadas' }
    ],
    comments: [
      { id: '1', user: 'Carlos Ruiz (Jardinería)', message: 'Todas las luces han sido reemplazadas', date: '2024-01-13T16:35:00Z' }
    ]
  },
  {
    id: '4',
    title: 'Puerta de emergencia bloqueada',
    description: 'La puerta de emergencia del ala este está bloqueada y no se puede abrir desde el interior.',
    status: 'pending',
    priority: 'high',
    residence: 'Residencia San Miguel',
    assignedto: 'Juan García (Mantenimiento)',
    reporteddate: '2024-01-16',
    created_at: '2024-01-16T08:00:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2024-01-16T08:00:00Z', details: 'Incidencia reportada' }
    ],
    comments: []
  },
  {
    id: '5',
    title: 'Ascensor hace ruidos extraños',
    description: 'El ascensor principal emite ruidos extraños al subir al segundo piso.',
    status: 'progress',
    priority: 'medium',
    residence: 'Residencia San Miguel',
    assignedto: 'Juan García (Mantenimiento)',
    reporteddate: '2024-01-12',
    created_at: '2024-01-12T11:45:00Z',
    history: [
      { action: 'created', user: 'Laura Pérez (Limpieza)', date: '2024-01-12T11:45:00Z', details: 'Incidencia reportada' },
      { action: 'assigned', user: 'Laura Pérez (Limpieza)', date: '2024-01-12T12:00:00Z', details: 'Asignada a Juan García' },
      { action: 'status_changed', user: 'Juan García (Mantenimiento)', date: '2024-01-14T10:00:00Z', details: 'Iniciada inspección técnica' }
    ],
    comments: [
      { id: '1', user: 'Juan García (Mantenimiento)', message: 'Contactando con empresa de mantenimiento especializada', date: '2024-01-14T10:15:00Z' }
    ]
  }
];
