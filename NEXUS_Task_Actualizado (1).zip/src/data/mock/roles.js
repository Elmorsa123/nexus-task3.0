
export const mockRoles = [
  { id: '1', name: 'Técnico', permissions: {} },
  { id: '2', name: 'Responsable', permissions: {} },
  { id: '3', name: 'Enfermera', permissions: {} },
  { id: '4', name: 'Administrador', permissions: {} }
];
