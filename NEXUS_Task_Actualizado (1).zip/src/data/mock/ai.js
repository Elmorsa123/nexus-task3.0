
export const mockAIResponses = {
  'fuga de agua': {
    solution: 'Para fugas de agua: 1) Cerrar la llave de paso principal, 2) Evaluar la gravedad, 3) Contactar fontanero si es necesario, 4) Documentar daños',
    frequency: 'Esta incidencia se repite cada 3-4 meses',
    prevention: 'Revisar tuberías mensualmente y cambiar juntas cada 6 meses'
  },
  'calefacción': {
    solution: 'Para problemas de calefacción: 1) Verificar termostato, 2) Revisar radiadores, 3) Comprobar caldera, 4) Purgar sistema si es necesario',
    frequency: 'Problema común en invierno, ocurre 2-3 veces por temporada',
    prevention: 'Mantenimiento preventivo antes del invierno y revisión mensual'
  },
  'luz fundida': {
    solution: 'Para luces fundidas: 1) Verificar interruptor, 2) Cambiar bombilla, 3) Revisar fusibles, 4) Comprobar instalación eléctrica',
    frequency: 'Incidencia frecuente, 1-2 veces por semana',
    prevention: 'Usar bombillas LED de calidad y revisar instalación anualmente'
  },
  'ascensor': {
    solution: 'Para problemas de ascensor: 1) No usar hasta revisión, 2) Contactar empresa mantenimiento, 3) Activar protocolo escaleras, 4) Informar a residentes',
    frequency: 'Problema ocasional, 1 vez cada 2-3 meses',
    prevention: 'Mantenimiento mensual obligatorio y revisión técnica trimestral'
  }
};
