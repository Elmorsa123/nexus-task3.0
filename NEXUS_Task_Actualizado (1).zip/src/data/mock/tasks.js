
export const mockTasks = [
  {
    id: '1',
    title: 'Revisión mensual de extintores',
    details: 'Realizar la revisión mensual de todos los extintores de la residencia según normativa.',
    type: 'mantenimiento',
    status: 'pending',
    priority: 'high',
    assignedto: 'Juan García (Mantenimiento)',
    duedate: '2025-06-25',
    zone: 'Toda la residencia',
    created_at: '2025-06-10T08:00:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2025-06-10T08:00:00Z', details: 'Tarea programada mensualmente' }
    ],
    comments: []
  },
  {
    id: '2',
    title: 'Cambio de filtros de aire acondicionado',
    details: 'Sustituir los filtros de aire acondicionado de las habitaciones 201-210.',
    type: 'mantenimiento',
    status: 'progress',
    priority: 'medium',
    assignedto: 'Juan García (Mantenimiento)',
    duedate: '2025-06-22',
    zone: 'Planta 2',
    created_at: '2025-06-08T11:30:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2025-06-08T11:30:00Z', details: 'Tarea creada' },
      { action: 'status_changed', user: 'Juan García (Mantenimiento)', date: '2025-06-15T09:00:00Z', details: 'Iniciado cambio de filtros' }
    ],
    comments: [
      { id: '1', user: 'Juan García (Mantenimiento)', message: 'Filtros pedidos, llegaran mañana', date: '2025-06-15T09:30:00Z' }
    ]
  },
  {
    id: '3',
    title: 'Administrar medicación matutina',
    details: 'Administrar la medicación matutina a los residentes según el plan médico.',
    type: 'atencion-a-residente',
    status: 'completed',
    priority: 'high',
    assignedto: 'Ana Torres (Enfermería)',
    duedate: '2025-06-15',
    zone: 'Habitaciones asignadas',
    created_at: '2025-06-15T07:00:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2025-06-15T07:00:00Z', details: 'Tarea diaria creada' },
      { action: 'completed', user: 'Ana Torres (Enfermería)', date: '2025-06-15T09:30:00Z', details: 'Medicación administrada a todos los residentes' }
    ],
    comments: []
  },
  {
    id: '4',
    title: 'Reparar puerta del jardín',
    details: 'La puerta del jardín no cierra correctamente. Revisar bisagras y cerradura.',
    type: 'mantenimiento',
    status: 'pending',
    priority: 'medium',
    assignedto: 'Carlos Ruiz (Jardinería)',
    duedate: '2025-06-18',
    zone: 'Jardín exterior',
    created_at: '2025-06-12T16:45:00Z',
    history: [
      { action: 'created', user: 'Laura Pérez (Limpieza)', date: '2025-06-12T16:45:00Z', details: 'Tarea reportada' }
    ],
    comments: []
  },
  {
    id: '5',
    title: 'Limpieza profunda cocina',
    details: 'Realizar limpieza profunda de la cocina principal incluyendo electrodomésticos.',
    type: 'limpieza',
    status: 'completed',
    priority: 'high',
    assignedto: 'Laura Pérez (Limpieza)',
    duedate: '2025-06-14',
    zone: 'Cocina principal',
    created_at: '2025-06-12T08:00:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2025-06-12T08:00:00Z', details: 'Tarea semanal programada' },
      { action: 'completed', user: 'Laura Pérez (Limpieza)', date: '2025-06-14T15:30:00Z', details: 'Limpieza completada satisfactoriamente' }
    ],
    comments: [
      { id: '1', user: 'Laura Pérez (Limpieza)', message: 'Cocina completamente desinfectada', date: '2025-06-14T15:35:00Z' }
    ]
  },
  {
    id: '6',
    title: 'Preparar menú semanal',
    details: 'Planificar y preparar el menú de la próxima semana considerando dietas especiales.',
    type: 'comida-y-cocina',
    status: 'pending',
    priority: 'medium',
    assignedto: 'No asignar',
    duedate: '2025-06-21',
    zone: 'Cocina principal',
    created_at: '2025-06-13T10:00:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2025-06-13T10:00:00Z', details: 'Tarea semanal creada' }
    ],
    comments: []
  },
  {
    id: '7',
    title: 'Podar arbustos del jardín',
    details: 'Podar los arbustos del jardín principal y recoger las ramas cortadas.',
    type: 'jardineria',
    status: 'progress',
    priority: 'low',
    assignedto: 'Carlos Ruiz (Jardinería)',
    duedate: '2025-07-01',
    zone: 'Jardín principal',
    created_at: '2025-06-14T14:00:00Z',
    history: [
      { action: 'created', user: 'Carlos Ruiz (Jardinería)', date: '2025-06-14T14:00:00Z', details: 'Tarea de mantenimiento estacional' },
      { action: 'status_changed', user: 'Carlos Ruiz (Jardinería)', date: '2025-06-16T08:30:00Z', details: 'Iniciada poda de arbustos' }
    ],
    comments: []
  },
  {
    id: '8',
    title: 'Revisión médica mensual residentes',
    details: 'Realizar revisión médica mensual a todos los residentes y actualizar historiales.',
    type: 'revision-medica',
    status: 'pending',
    priority: 'high',
    assignedto: 'Ana Torres (Enfermería)',
    duedate: '2025-06-30',
    zone: 'Consulta médica',
    created_at: '2025-06-15T12:00:00Z',
    history: [
      { action: 'created', user: 'Ana Torres (Enfermería)', date: '2025-06-15T12:00:00Z', details: 'Revisión mensual programada' }
    ],
    comments: []
  }
];
