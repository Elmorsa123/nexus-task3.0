
export const mockTaskHistory = [
  {
    id: 'th1',
    taskId: '1',
    taskTitle: 'Revisión mensual de extintores',
    user: 'Pedro Administrador',
    action: 'created',
    timestamp: '2025-06-19T10:00:00Z',
    details: 'Creó la tarea con prioridad alta.'
  },
  {
    id: 'th2',
    taskId: '1',
    taskTitle: 'Revisión mensual de extintores',
    user: 'Pedro Administrador',
    action: 'assigned',
    timestamp: '2025-06-19T10:01:00Z',
    details: 'Asignó la tarea a Juan García (Mantenimiento).'
  },
  {
    id: 'th3',
    taskId: '2',
    taskTitle: 'Limpieza profunda de la cocina',
    user: 'Laura Pérez (Limpieza)',
    action: 'status_changed',
    timestamp: '2025-06-19T11:30:00Z',
    details: 'Cambió el estado de "Pendiente" a "En Progreso".'
  },
  {
    id: 'th4',
    taskId: '3',
    taskTitle: 'Administrar medicación a Carmen García',
    user: 'Ana Torres (Enfermería)',
    action: 'completed',
    timestamp: '2025-06-19T12:05:00Z',
    details: 'Marcó la tarea como completada.'
  },
  {
    id: 'th5',
    taskId: '2',
    taskTitle: 'Limpieza profunda de la cocina',
    user: 'Laura Pérez (Limpieza)',
    action: 'completed',
    timestamp: '2025-06-19T14:00:00Z',
    details: 'Marcó la tarea como completada.'
  },
  {
    id: 'th6',
    taskId: '4',
    taskTitle: 'Podar los rosales del jardín frontal',
    user: 'Carlos Ruiz (Jardinería)',
    action: 'status_changed',
    timestamp: '2025-06-20T09:00:00Z',
    details: 'Cambió el estado de "Pendiente" a "En Progreso".'
  }
];
