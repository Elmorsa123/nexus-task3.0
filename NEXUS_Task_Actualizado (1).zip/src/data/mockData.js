
import { mockIncidents } from './mock/incidents';
import { mockTasks } from './mock/tasks';
import { mockUsers } from './mock/users';
import { mockRoles } from './mock/roles';
import { mockResidents } from './mock/residents';
import { mockCleaningJobs } from './mock/cleaning';
import { mockIdeas } from './mock/ideas';
import { mockStatistics } from './mock/statistics';
import { mockNotifications } from './mock/notifications';
import { mockAIResponses } from './mock/ai';

export const initializeMockData = () => {
  const dataKeys = [
    { key: 'nexus-incidents', data: mockIncidents },
    { key: 'nexus-tasks', data: mockTasks },
    { key: 'nexus-users', data: mockUsers },
    { key: 'nexus-roles', data: mockRoles },
    { key: 'nexus-residents', data: mockResidents },
    { key: 'nexus-cleaning-jobs', data: mockCleaningJobs },
    { key: 'nexus-ideas', data: mockIdeas },
    { key: 'nexus-statistics', data: mockStatistics },
    { key: 'nexus-notifications', data: mockNotifications },
    { key: 'nexus-ai-responses', data: mockAIResponses }
  ];

  dataKeys.forEach(({ key, data }) => {
    if (!localStorage.getItem(key)) {
      localStorage.setItem(key, JSON.stringify(data));
    }
  });
};
