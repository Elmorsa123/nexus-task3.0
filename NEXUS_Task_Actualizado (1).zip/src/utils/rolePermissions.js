
export const PERMISSIONS_MAP = {
  canManageUsers: { label: 'Gestionar Usuarios', description: 'Añadir, editar y eliminar usuarios.' },
  canManagePermissions: { label: 'Gestionar Permisos', description: 'Modificar roles y permisos de la aplicación.' },
  canViewAllTasks: { label: 'Ver Todas las Tareas', description: 'Acceso a todas las tareas, no solo las propias.' },
  canCreateTasks: { label: 'Crear Tareas', description: 'Puede crear y asignar nuevas tareas.' },
  canEditAllTasks: { label: 'Editar Todas las Tareas', description: 'Editar detalles de cualquier tarea.' },
  canDeleteTasks: { label: 'Eliminar Tareas', description: 'Puede eliminar tareas del sistema.' },
  canManageIncidents: { label: 'Gestionar Incidencias', description: 'Crear y actualizar el estado de las incidencias.' },
  canManageResidents: { label: 'Gestionar Residentes', description: 'Añadir, editar y ver información de residentes.' },
  canManageMedication: { label: 'Gestionar Medicación', description: 'Actualizar el estado de la medicación de los residentes.' },
  canManageCleaning: { label: 'Gestionar Limpieza', description: 'Programar y actualizar tareas de limpieza.' },
  canManageIdeas: { label: 'Gestionar Ideas', description: 'Añadir y gestionar ideas de mejora.' },
  canViewStatistics: { label: 'Ver Estadísticas', description: 'Acceso al panel de estadísticas de rendimiento.' },
  canManageSettings: { label: 'Ajustes Generales', description: 'Modificar ajustes globales de la aplicación.' },
};

export const ROLE_STYLES = {
  super_admin: { text: 'text-purple-500 dark:text-purple-400', avatar: 'bg-purple-200 text-purple-700 dark:bg-purple-900 dark:text-purple-300' },
  administrador: { text: 'text-red-500 dark:text-red-400', avatar: 'bg-red-200 text-red-700 dark:bg-red-900 dark:text-red-300' },
  responsable: { text: 'text-blue-500 dark:text-blue-400', avatar: 'bg-blue-200 text-blue-700 dark:bg-blue-900 dark:text-blue-300' },
  enfermera_jefe: { text: 'text-emerald-500 dark:text-emerald-400', avatar: 'bg-emerald-200 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300' },
  enfermera: { text: 'text-green-500 dark:text-green-400', avatar: 'bg-green-200 text-green-700 dark:bg-green-900 dark:text-green-300' },
  técnico: { text: 'text-orange-500 dark:text-orange-400', avatar: 'bg-orange-200 text-orange-700 dark:bg-orange-900 dark:text-orange-300' },
  default: { text: 'text-muted-foreground', avatar: 'bg-secondary text-secondary-foreground' },
};

export const ROLE_PERMISSIONS = {
  super_admin: { ...Object.keys(PERMISSIONS_MAP).reduce((acc, key) => ({ ...acc, [key]: true }), {}) },
  administrador: {
    canManageUsers: true, canManagePermissions: false,
    canViewAllTasks: true, canCreateTasks: true, canEditAllTasks: true, canDeleteTasks: true,
    canManageIncidents: true, canManageResidents: true, canManageMedication: false,
    canManageCleaning: true, canManageIdeas: true, canViewStatistics: true, canManageSettings: false,
  },
  responsable: {
    canViewAllTasks: true, canCreateTasks: true, canEditAllTasks: false, canDeleteTasks: false,
    canManageIncidents: true, canManageResidents: true, canManageCleaning: true,
    canManageIdeas: true,
  },
  enfermera_jefe: {
    canViewAllTasks: true, canCreateTasks: true, canManageResidents: true, canManageMedication: true,
  },
  enfermera: {
    canManageResidents: true, canManageMedication: true,
  },
  técnico: {
    canCreateTasks: true,
  },
};

export const getUserRole = (user) => {
  if (!user) return 'técnico';
  const roles = user.custom_roles || user.roles?.map(r => r.name) || [];
  const primaryRole = roles[0]?.toLowerCase().replace(/ /g, '_');
  return ROLE_PERMISSIONS[primaryRole] ? primaryRole : 'técnico';
};

export const getRoleStyle = (role) => {
  return ROLE_STYLES[role] || ROLE_STYLES.default;
};

export const hasPermission = (user, permission) => {
  const userRole = getUserRole(user);
  return ROLE_PERMISSIONS[userRole]?.[permission] || false;
};

export const getFilteredNavigationItems = (user, navigationItems, t) => {
  const userRole = getUserRole(user);
  const permissions = ROLE_PERMISSIONS[userRole];

  const translatedItems = navigationItems.map(item => ({
    ...item,
    label: t(`sidebar.${item.id}`)
  }));
  
  if (!permissions) return translatedItems.filter(item => ['dashboard', 'mytasks', 'settings'].includes(item.id));

  return translatedItems.filter(item => {
    switch (item.id) {
      case 'users': return permissions.canManageUsers;
      case 'permissions': return permissions.canManagePermissions;
      case 'settings': return true; 
      case 'residents': return permissions.canManageResidents;
      case 'incidents': return permissions.canManageIncidents;
      case 'cleaning': return permissions.canManageCleaning;
      case 'ideas': return permissions.canManageIdeas;
      case 'statistics': return permissions.canViewStatistics;
      case 'tasks': return permissions.canViewAllTasks;
      case 'history': return permissions.canViewAllTasks; 
      default: return true;
    }
  });
};
