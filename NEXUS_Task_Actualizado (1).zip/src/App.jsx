
import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import AppMain from '@/components/AppMain';
import { initializeMockData } from '@/data/mockData';
import { hexToHsl } from '@/lib/utils';
import { toast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/lib/supabaseClient';

function App() {
  const { i18n } = useTranslation();

  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const storedTheme = localStorage.getItem('nexus-task-theme');
      if (storedTheme) return storedTheme;
    }
    return 'light';
  });

  const [currentUser, setCurrentUser] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  const [appSettings, setAppSettings] = useState(() => {
    const storedSettings = localStorage.getItem('nexus-app-settings');
    try {
      const settings = storedSettings ? JSON.parse(storedSettings) : {};
      return {
        language: settings.language || 'es',
        primaryColor: settings.primaryColor || '#3B82F6',
        welcomeMessage: settings.welcomeMessage || '¡Bienvenido de nuevo!',
        autoTheme: settings.autoTheme === undefined ? true : settings.autoTheme,
        notifications: settings.notifications === undefined ? true : settings.notifications
      };
    } catch (e) {
      return {
        language: 'es',
        primaryColor: '#3B82F6',
        welcomeMessage: '¡Bienvenido de nuevo!',
        autoTheme: true,
        notifications: true
      };
    }
  });

  useEffect(() => {
    initializeMockData();
  }, []);
  
  useEffect(() => {
    setLoadingAuth(true);
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      const user = session?.user || null;
      if (user) {
        const { data: userProfile, error } = await supabase
          .from('users')
          .select('*')
          .eq('email', user.email)
          .single();

        if (error && error.code !== 'PGRST116') { // Ignore 'exact one row' error if user not in public table yet
          console.error('Error fetching user profile:', error);
          setCurrentUser(user);
        } else {
          setCurrentUser({ ...user, profile: userProfile });
        }
      } else {
        setCurrentUser(null);
      }
      setLoadingAuth(false);
    });

    return () => {
      subscription?.unsubscribe();
    };
  }, []);


  useEffect(() => {
    if (appSettings.language && i18n.language !== appSettings.language) {
      i18n.changeLanguage(appSettings.language);
      localStorage.setItem('nexus-app-language', appSettings.language);
    }
  }, [appSettings.language, i18n]);

  useEffect(() => {
    localStorage.setItem('nexus-app-settings', JSON.stringify(appSettings));
  }, [appSettings]);

  useEffect(() => {
    const root = document.documentElement;
    if (appSettings.autoTheme) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = (e) => {
        const newTheme = e.matches ? 'dark' : 'light';
        setTheme(newTheme);
        root.classList.toggle('dark', e.matches);
      };
      
      handleChange(mediaQuery);
      mediaQuery.addEventListener('change', handleChange);
      
      return () => mediaQuery.removeEventListener('change', handleChange);
    } else {
      root.classList.toggle('dark', theme === 'dark');
      localStorage.setItem('nexus-task-theme', theme);
    }
  }, [theme, appSettings.autoTheme]);

  useEffect(() => {
    if (appSettings.primaryColor) {
      const hsl = hexToHsl(appSettings.primaryColor);
      if (hsl) {
        document.documentElement.style.setProperty('--primary-base', `${hsl.h} ${hsl.s}% ${hsl.l}%`);
      }
    }
  }, [appSettings.primaryColor]);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    updateAppSettings({ autoTheme: false });
  };

  const updateAppSettings = (newSettings) => {
    setAppSettings(prev => ({ ...prev, ...newSettings }));
  };

  const handleShowToast = useCallback((title, description, variant = 'default') => {
    toast({
      title: title || "🚧 Función no implementada",
      description: description || "¡Puedes solicitarla en tu próximo prompt! 🚀",
      variant
    });
  }, []);

  if (loadingAuth) {
     return (
      <div className="min-h-screen bg-bg-main flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-main text-foreground transition-colors duration-300">
      <Helmet>
        <title>NEXUS Task - Gestión Inteligente</title>
        <meta name="description" content="NEXUS Task: Plataforma para la gestión de incidencias, tareas, limpieza y residentes." />
        <html lang={i18n.language} />
      </Helmet>
      <AppMain
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        theme={theme}
        toggleTheme={toggleTheme}
        handleShowToast={handleShowToast}
        appSettings={appSettings}
        updateAppSettings={updateAppSettings}
      />
    </div>
  );
}

export default App;
