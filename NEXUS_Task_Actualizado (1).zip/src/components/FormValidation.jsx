
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';

export const useFormValidation = (initialValues, validationRules) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const validateField = (name, value) => {
    const rules = validationRules[name];
    if (!rules) return '';

    for (const rule of rules) {
      const error = rule(value, values);
      if (error) return error;
    }
    return '';
  };

  const handleChange = (name, value) => {
    setValues(prev => ({ ...prev, [name]: value }));
    
    if (touched[name]) {
      const error = validateField(name, value);
      setErrors(prev => ({ ...prev, [name]: error }));
    }
  };

  const handleBlur = (name) => {
    setTouched(prev => ({ ...prev, [name]: true }));
    const error = validateField(name, values[name]);
    setErrors(prev => ({ ...prev, [name]: error }));
  };

  const validateAll = () => {
    const newErrors = {};
    const newTouched = {};
    
    Object.keys(validationRules).forEach(name => {
      newTouched[name] = true;
      newErrors[name] = validateField(name, values[name]);
    });
    
    setTouched(newTouched);
    setErrors(newErrors);
    
    return Object.values(newErrors).every(error => !error);
  };

  const reset = () => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
  };

  return {
    values,
    errors,
    touched,
    handleChange,
    handleBlur,
    validateAll,
    reset,
    setValues
  };
};

export const ValidationMessage = ({ error, success, info, className = "" }) => {
  if (!error && !success && !info) return null;

  const getIcon = () => {
    if (error) return <AlertCircle className="w-3 h-3 mr-1.5 text-destructive" />;
    if (success) return <CheckCircle className="w-3 h-3 mr-1.5 text-success" />;
    if (info) return <Info className="w-3 h-3 mr-1.5 text-info" />;
    return null;
  };

  const getTextColor = () => {
    if (error) return 'text-destructive';
    if (success) return 'text-success';
    if (info) return 'text-info';
    return '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className={`flex items-center text-xs mt-1 ${className}`}
    >
      {getIcon()}
      <span className={getTextColor()}>{error || success || info}</span>
    </motion.div>
  );
};

export const validationRules = {
  required: (value) => {
    if (!value || (typeof value === 'string' && value.trim() === '')) {
      return 'Este campo es obligatorio';
    }
    return '';
  },
  
  email: (value) => {
    if (value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      return 'Introduce un email válido';
    }
    return '';
  },
  
  minLength: (min) => (value) => {
    if (value && value.length < min) {
      return `Debe tener al menos ${min} caracteres`;
    }
    return '';
  },
  
  maxLength: (max) => (value) => {
    if (value && value.length > max) {
      return `No puede tener más de ${max} caracteres`;
    }
    return '';
  },
  
  phoneNumber: (value) => {
    if (value && !/^[+]?[\d\s\-\(\)]{9,}$/.test(value)) {
      return 'Introduce un número de teléfono válido';
    }
    return '';
  },
  
  positiveNumber: (value) => {
    if (value && (isNaN(value) || parseFloat(value) <= 0)) {
      return 'Debe ser un número positivo';
    }
    return '';
  },
  
  futureDate: (value) => {
    if (value && new Date(value) <= new Date()) {
      return 'La fecha debe ser futura';
    }
    return '';
  },

  roomNumber: (value) => {
    if (value && !/^\d{3}$/.test(value)) {
      return 'Debe ser un número de habitación válido (3 dígitos)';
    }
    return '';
  },

  medicationDosage: (value) => {
    if (value && !/^\d+(\.\d+)?\s*(mg|ml|UI|g)$/i.test(value)) {
      return 'Formato: número + unidad (ej: 10mg, 5ml)';
    }
    return '';
  },

  timeFormat: (value) => {
    if (value && !/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(value)) {
      return 'Formato de hora inválido (HH:MM)';
    }
    return '';
  }
};

export const FormFieldWrapper = ({ label, error, success, info, children, required = false }) => (
  <div className="space-y-1">
    {label && (
      <label className="text-sm font-medium text-text-secondary block">
        {label}
        {required && <span className="text-destructive ml-1">*</span>}
      </label>
    )}
    {children}
    <ValidationMessage error={error} success={success} info={info} />
  </div>
);
