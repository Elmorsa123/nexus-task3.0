
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

const Sidebar = ({ navigationItems, activeView, setActiveView, isMobileSidebarOpen, setIsMobileSidebarOpen }) => {
  const handleItemClick = (item) => {
    if (item.action) {
      item.action();
    } else if (item.path) {
      setActiveView(item.path);
    }
    setIsMobileSidebarOpen(false);
  };

  const SidebarContent = () => (
    <div className="space-y-1.5">
      {navigationItems.map((item, index) => (
        <motion.button
          key={item.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.05, duration: 0.3 }}
          whileHover={{ 
            x: 5, 
            backgroundColor: 'hsl(var(--accent))',
            boxShadow: "0 0 15px hsl(var(--primary) / 0.2)" 
          }}
          whileTap={{ scale: 0.98 }}
          onClick={() => handleItemClick(item)}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ease-in-out group ${
            activeView === item.id
              ? 'bg-primary text-primary-foreground shadow-md shadow-[hsl(var(--primary)/0.3)]'
              : 'text-text-secondary hover:text-text-main'
          }`}
        >
          <item.icon className={`w-5 h-5 transition-colors ${activeView === item.id ? 'text-primary-foreground' : 'text-muted-foreground group-hover:text-primary'}`} />
          <span className="font-medium text-sm">{item.label}</span>
        </motion.button>
      ))}
    </div>
  );
  
  return (
    <>
      <motion.aside
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, ease: "circOut" }}
        className="lg:w-60 xl:w-64 space-y-2 hidden lg:block"
      >
        <nav className="bg-card/60 backdrop-blur-lg rounded-xl p-3 shadow-sm border-border h-full">
          <SidebarContent />
        </nav>
      </motion.aside>

      <AnimatePresence>
        {isMobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setIsMobileSidebarOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 lg:hidden"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed top-0 left-0 h-full w-72 bg-background p-4 z-50 lg:hidden flex flex-col"
            >
              <div className="flex items-center justify-between mb-6 flex-shrink-0">
                <h2 className="text-xl font-bold text-text-main">NEXUS Task</h2>
                <Button variant="ghost" size="icon" onClick={() => setIsMobileSidebarOpen(false)} aria-label="Cerrar menú">
                  <X className="w-6 h-6" />
                </Button>
              </div>
              <div className="flex-grow overflow-y-auto">
                <SidebarContent />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Sidebar;
