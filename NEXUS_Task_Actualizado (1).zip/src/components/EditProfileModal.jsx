import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, Save, UserCog, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const EditProfileModal = ({ user, onClose, onSave, handleShowToast }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [bio, setBio] = useState('');

  useEffect(() => {
    if (user) {
      setName(user.user_metadata?.name || '');
      setPhone(user.user_metadata?.phone || '');
      setBio(user.user_metadata?.bio || '');
    }
  }, [user]);

  if (!user) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ name, phone, bio });
  };
  
  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";
  const userInitial = (user.user_metadata?.name || user.email || 'U').charAt(0).toUpperCase();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <UserCog className="w-6 h-6 mr-3 text-primary" />
            Editar Perfil
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="flex items-center space-x-6">
            <div className="relative">
              <Avatar className="w-24 h-24 border-4 border-primary/20">
                <AvatarImage src={user.user_metadata?.avatar_url} alt={name} />
                <AvatarFallback className="text-4xl bg-secondary text-secondary-foreground">{userInitial}</AvatarFallback>
              </Avatar>
              <Button 
                type="button" 
                size="icon" 
                className="absolute bottom-0 right-0 rounded-full w-8 h-8"
                onClick={() => handleShowToast("Cambiar Foto", "🚧 Función en desarrollo.", "info")}
              >
                <Camera className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex-1 space-y-5">
              <div>
                <Label htmlFor="name" className={labelClass}>Nombre Completo</Label>
                <Input type="text" name="name" id="name" value={name} onChange={(e) => setName(e.target.value)} className={inputClass} required />
              </div>
              <div>
                <Label htmlFor="email" className={labelClass}>Email (no editable)</Label>
                <Input type="email" name="email" id="email" value={user.email} className={inputClass} disabled />
              </div>
            </div>
          </div>
          
          <div>
            <Label htmlFor="phone" className={labelClass}>Teléfono</Label>
            <Input type="tel" name="phone" id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} className={inputClass} placeholder="+34 123 456 789" />
          </div>

          <div>
            <Label htmlFor="bio" className={labelClass}>Biografía Corta</Label>
            <Textarea name="bio" id="bio" value={bio} onChange={(e) => setBio(e.target.value)} className={inputClass} placeholder="Una breve descripción sobre ti..." rows={3} />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" variant="default">
              <Save className="w-4 h-4 mr-2" />
              Guardar Cambios
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default EditProfileModal;