
import React from 'react';
import { motion } from 'framer-motion';
import { X, Save, UserPlus, BedDouble, Pill, PlusCircle, Trash2, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useFormValidation, ValidationMessage, validationRules } from '@/components/FormValidation';

const AddResidentModal = ({ onClose, onSave }) => {
  const { values, errors, touched, handleChange, handleBlur, validateAll, setValues } = useFormValidation(
    {
      name: '',
      room_number: '',
      photo_url: '',
      medications: [],
    },
    {
      name: [validationRules.required, validationRules.minLength(3)],
      room_number: [validationRules.required],
    }
  );

  const [currentMed, setCurrentMed] = React.useState({ name: '', dosage: '', schedule: '' });

  const handleMedChange = (e) => {
    const { name, value } = e.target;
    setCurrentMed(prev => ({ ...prev, [name]: value }));
  };

  const handleAddMedication = () => {
    if (currentMed.name && currentMed.dosage && currentMed.schedule) {
      setValues(prev => ({
        ...prev,
        medications: [...prev.medications, { ...currentMed, status: 'pending' }]
      }));
      setCurrentMed({ name: '', dosage: '', schedule: '' });
    }
  };

  const handleRemoveMedication = (index) => {
    setValues(prev => ({
      ...prev,
      medications: prev.medications.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateAll()) {
      onSave(values);
    }
  };
  
  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <UserPlus className="w-6 h-6 mr-3 text-primary" />
            Añadir Nuevo Residente
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label htmlFor="name" className={labelClass}><UserPlus className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Nombre Completo</Label>
            <Input type="text" name="name" id="name" value={values.name} onChange={(e) => handleChange('name', e.target.value)} onBlur={() => handleBlur('name')} className={inputClass} />
            <ValidationMessage error={touched.name && errors.name} />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="room_number" className={labelClass}><BedDouble className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Nº Habitación</Label>
              <Input type="text" name="room_number" id="room_number" value={values.room_number} onChange={(e) => handleChange('room_number', e.target.value)} onBlur={() => handleBlur('room_number')} className={inputClass} />
              <ValidationMessage error={touched.room_number && errors.room_number} />
            </div>
            <div>
              <Label htmlFor="photo_url" className={labelClass}><Camera className="inline w-4 h-4 mr-1.5 text-text-secondary"/>URL de la Foto (Opcional)</Label>
              <Input type="text" name="photo_url" id="photo_url" value={values.photo_url} onChange={(e) => handleChange('photo_url', e.target.value)} className={inputClass} placeholder="https://example.com/photo.jpg"/>
            </div>
          </div>
          
          <div className="space-y-3">
            <Label className={labelClass}><Pill className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Medicación</Label>
            {values.medications.map((med, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between p-2.5 bg-accent/50 rounded-md border border-border"
              >
                <div className="text-xs">
                  <p className="font-medium text-text-main">{med.name} ({med.dosage})</p>
                  <p className="text-text-secondary">Horario: {med.schedule}</p>
                </div>
                <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveMedication(index)} className="text-destructive hover:bg-destructive/10 w-7 h-7">
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </motion.div>
            ))}
            <div className="p-3 border border-dashed border-border rounded-lg space-y-2.5 bg-background/50">
              <Input type="text" name="name" placeholder="Nombre Medicamento" value={currentMed.name} onChange={handleMedChange} className={`${inputClass} h-9 text-xs`} />
              <div className="grid grid-cols-2 gap-2">
                <Input type="text" name="dosage" placeholder="Dosis (ej: 10mg)" value={currentMed.dosage} onChange={handleMedChange} className={`${inputClass} h-9 text-xs`} />
                <Input type="text" name="schedule" placeholder="Horario (ej: 8:00, 20:00)" value={currentMed.schedule} onChange={handleMedChange} className={`${inputClass} h-9 text-xs`} />
              </div>
              <Button type="button" variant="outline" size="sm" onClick={handleAddMedication} className="w-full text-xs">
                <PlusCircle className="w-3.5 h-3.5 mr-1.5" /> Añadir Medicamento
              </Button>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" variant="default"><Save className="w-4 h-4 mr-2" />Guardar Residente</Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default AddResidentModal;
