
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { LayoutDashboard, AlertTriangle as AlertTriangleIcon, ListChecks, SprayCan, Users as UsersIcon, CalendarClock, UserCircle, Settings as SettingsIcon, MessageCircle as MessageCircleQuestion, Lightbulb, UserCheck, BarChart3, ShieldCheck, History, Bell } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import DashboardView from '@/components/views/DashboardView';
import IncidentsView from '@/components/views/IncidentsView';
import TasksView from '@/components/views/TasksView';
import CleaningView from '@/components/views/CleaningView';
import ManageUsersView from '@/components/views/ManageUsersView';
import CalendarView from '@/components/views/CalendarView';
import LoginView from '@/components/views/LoginView.jsx';
import ResidentsView from '@/components/views/ResidentsView.jsx';
import ChatView from '@/components/views/ChatView.jsx';
import SettingsView from '@/components/views/SettingsView.jsx';
import IdeasView from '@/components/views/IdeasView.jsx';
import MyTasksView from '@/components/views/MyTasksView.jsx';
import StatisticsView from '@/components/views/StatisticsView.jsx';
import PermissionsView from '@/components/views/PermissionsView.jsx';
import NotificationsView from '@/components/views/NotificationsView.jsx';
import TaskHistoryView from '@/components/views/TaskHistoryView.jsx';
import ChatWidget from '@/components/ChatWidget.jsx';
import AddTaskModal from '@/components/AddTaskModal.jsx';
import EditTaskModal from '@/components/EditTaskModal.jsx';
import AddResidentModal from '@/components/AddResidentModal.jsx';
import EditResidentModal from '@/components/EditResidentModal.jsx';
import AddUserModal from '@/components/AddUserModal.jsx';
import EditUserModal from '@/components/EditUserModal.jsx';
import AddIdeaModal from '@/components/AddIdeaModal.jsx';
import EditIdeaModal from '@/components/EditIdeaModal.jsx';
import AddCleaningJobModal from '@/components/AddCleaningJobModal.jsx';
import EditProfileModal from '@/components/EditProfileModal.jsx';
import AccountSettingsModal from '@/components/AccountSettingsModal.jsx';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import { useDataManagement } from '@/hooks/useDataManagement';
import { getFilteredNavigationItems } from '@/utils/rolePermissions';

const AppMain = ({ 
  currentUser, 
  setCurrentUser, 
  theme, 
  toggleTheme, 
  handleShowToast,
  appSettings,
  updateAppSettings
}) => {
  const [activeView, setActiveView] = useState('dashboard');
  const [loadingAuth, setLoadingAuth] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();

  useEffect(() => {
    if (!currentUser && location.pathname !== '/login') {
      navigate('/login');
    }
  }, [currentUser, location.pathname, navigate]);

  const {
    incidents, tasks, cleaningJobs, users, roles, residents, ideas, statistics, permissions,
    addIncident, updateIncident,
    addTask, updateTask, quickUpdateTask, updateTaskStatus,
    addUser, updateUser, deleteUser, toggleUserStatus,
    addResident, updateResident, deleteResident, updateResidentMedicationStatus,
    addCleaningJob, updateCleaningJobStatus,
    addIdea, updateIdea, deleteIdea,
    updatePermissions,
    resetAllData,
  } = useDataManagement(currentUser);

  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  const [preselectedUserForTask, setPreselectedUserForTask] = useState(null);
  const [isEditTaskModalOpen, setIsEditTaskModalOpen] = useState(false);
  const [currentTaskToEdit, setCurrentTaskToEdit] = useState(null);

  const [isAddResidentModalOpen, setIsAddResidentModalOpen] = useState(false);
  const [isEditResidentModalOpen, setIsEditResidentModalOpen] = useState(false);
  const [currentResidentToEdit, setCurrentResidentToEdit] = useState(null);
  const [isDeleteResidentAlertOpen, setIsDeleteResidentAlertOpen] = useState(false);
  const [residentToDelete, setResidentToDelete] = useState(null);

  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [currentUserToEdit, setCurrentUserToEdit] = useState(null);
  const [isDeleteUserAlertOpen, setIsDeleteUserAlertOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  const [isAddIdeaModalOpen, setIsAddIdeaModalOpen] = useState(false);
  const [isEditIdeaModalOpen, setIsEditIdeaModalOpen] = useState(false);
  const [currentIdeaToEdit, setCurrentIdeaToEdit] = useState(null);
  const [isDeleteIdeaAlertOpen, setIsDeleteIdeaAlertOpen] = useState(false);
  const [ideaToDelete, setIdeaToDelete] = useState(null);

  const [isAddCleaningJobModalOpen, setIsAddCleaningJobModalOpen] = useState(false);

  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [isAccountSettingsModalOpen, setIsAccountSettingsModalOpen] = useState(false);

  const handleOpenAddTaskModal = (userId = null) => { 
    setPreselectedUserForTask(userId);
    setIsAddTaskModalOpen(true);
  };
  const handleCloseAddTaskModal = () => {
    setIsAddTaskModalOpen(false);
    setPreselectedUserForTask(null);
  };
  const handleAddTaskAndCloseModal = (newTask) => { addTask(newTask); handleCloseAddTaskModal(); };
  const handleOpenEditTaskModal = (task) => { setCurrentTaskToEdit(task); setIsEditTaskModalOpen(true); };
  const handleCloseEditTaskModal = () => { setIsEditTaskModalOpen(false); setCurrentTaskToEdit(null); };
  const handleUpdateTaskAndCloseModal = (updatedTaskData) => { updateTask(updatedTaskData); handleCloseEditTaskModal(); };

  const handleOpenAddResidentModal = () => setIsAddResidentModalOpen(true);
  const handleCloseAddResidentModal = () => setIsAddResidentModalOpen(false);
  const handleAddResidentAndCloseModal = (newResident) => { addResident(newResident); handleCloseAddResidentModal(); };
  const handleOpenEditResidentModal = (resident) => { setCurrentResidentToEdit(resident); setIsEditResidentModalOpen(true); };
  const handleCloseEditResidentModal = () => { setIsEditResidentModalOpen(false); setCurrentResidentToEdit(null); };
  const handleUpdateResidentAndCloseModal = (updatedResidentData) => { updateResident(updatedResidentData); handleCloseEditResidentModal(); };
  const handleOpenDeleteResidentAlert = (resident) => { setResidentToDelete(resident); setIsDeleteResidentAlertOpen(true); };
  const handleCloseDeleteResidentAlert = () => { setResidentToDelete(null); setIsDeleteResidentAlertOpen(false); };
  const handleDeleteResidentAndCloseAlert = () => { if (!residentToDelete) return; deleteResident(residentToDelete.id, residentToDelete.name); handleCloseDeleteResidentAlert(); };

  const handleOpenAddUserModal = () => setIsAddUserModalOpen(true);
  const handleCloseAddUserModal = () => setIsAddUserModalOpen(false);
  const handleAddUserAndCloseModal = (newUser) => { addUser(newUser); handleCloseAddUserModal(); };
  const handleOpenEditUserModal = (user) => { setCurrentUserToEdit(user); setIsEditUserModalOpen(true); };
  const handleCloseEditUserModal = () => { setIsEditUserModalOpen(false); setCurrentUserToEdit(null); };
  const handleUpdateUserAndCloseModal = (updatedUserData) => { updateUser(updatedUserData); handleCloseEditUserModal(); };
  const handleOpenDeleteUserAlert = (user) => { setUserToDelete(user); setIsDeleteUserAlertOpen(true); };
  const handleCloseDeleteUserAlert = () => { setUserToDelete(null); setIsDeleteUserAlertOpen(false); };
  const handleDeleteUserAndCloseAlert = () => { if (!userToDelete) return; deleteUser(userToDelete.id, userToDelete.name); handleCloseDeleteUserAlert(); };

  const handleOpenAddIdeaModal = () => setIsAddIdeaModalOpen(true);
  const handleCloseAddIdeaModal = () => setIsAddIdeaModalOpen(false);
  const handleAddIdeaAndCloseModal = (newIdea) => { addIdea(newIdea); handleCloseAddIdeaModal(); };
  const handleOpenEditIdeaModal = (idea) => { setCurrentIdeaToEdit(idea); setIsEditIdeaModalOpen(true); };
  const handleCloseEditIdeaModal = () => { setIsEditIdeaModalOpen(false); setCurrentIdeaToEdit(null); };
  const handleUpdateIdeaAndCloseModal = (updatedIdeaData) => { updateIdea(updatedIdeaData); handleCloseEditIdeaModal(); };
  const handleOpenDeleteIdeaAlert = (idea) => { setIdeaToDelete(idea); setIsDeleteIdeaAlertOpen(true); };
  const handleCloseDeleteIdeaAlert = () => { setIdeaToDelete(null); setIsDeleteIdeaAlertOpen(false); };
  const handleDeleteIdeaAndCloseAlert = () => { if (!ideaToDelete) return; deleteIdea(ideaToDelete.id, ideaToDelete.title); handleCloseDeleteIdeaAlert(); };

  const handleOpenAddCleaningJobModal = () => setIsAddCleaningJobModalOpen(true);
  const handleCloseAddCleaningJobModal = () => setIsAddCleaningJobModalOpen(false);
  const handleAddCleaningJobAndCloseModal = (newJob) => { addCleaningJob(newJob); handleCloseAddCleaningJobModal(); };

  const handleOpenEditProfileModal = () => setIsEditProfileModalOpen(true);
  const handleCloseEditProfileModal = () => setIsEditProfileModalOpen(false);
  const handleOpenAccountSettingsModal = () => setIsAccountSettingsModalOpen(true);
  const handleCloseAccountSettingsModal = () => setIsAccountSettingsModalOpen(false);

  const handleUpdateProfile = (updatedProfileData) => {
    const updatedUser = {
      ...currentUser,
      user_metadata: {
        ...currentUser.user_metadata,
        ...updatedProfileData,
      },
    };
    setCurrentUser(updatedUser);
    updateUser(updatedUser);
    handleCloseEditProfileModal();
    handleShowToast("Perfil Actualizado", "Tu información ha sido guardada.", "success");
  };

  const handleUpdateAccountSettings = () => {
    handleCloseAccountSettingsModal();
    handleShowToast("Ajustes Guardados", "Tus ajustes de cuenta han sido actualizados (simulación).", "success");
  };

  const handleLogout = async () => {
    setCurrentUser(null);
    navigate('/login');
    handleShowToast("Sesión Cerrada", "Has cerrado sesión exitosamente.", "success");
  };

  const navigationItems = [
    { id: 'dashboard', icon: LayoutDashboard, path: '/dashboard' },
    { id: 'myTasks', icon: UserCheck, path: '/mytasks' },
    { id: 'notifications', icon: Bell, path: '/notifications' },
    { id: 'history', icon: History, path: '/history', label: 'Historial / Exportar' },
    { id: 'statistics', icon: BarChart3, path: '/statistics' },
    { id: 'residents', icon: UserCircle, path: '/residents' },
    { id: 'tasks', icon: ListChecks, path: '/tasks' },
    { id: 'cleaning', icon: SprayCan, path: '/cleaning' },
    { id: 'incidents', icon: AlertTriangleIcon, path: '/incidents' },
    { id: 'ideas', icon: Lightbulb, path: '/ideas' },
    { id: 'calendar', icon: CalendarClock, path: '/calendar' },
    { id: 'chat', icon: MessageCircleQuestion, path: '/chat' },
    { id: 'users', icon: UsersIcon, path: '/users'},
    { id: 'permissions', icon: ShieldCheck, path: '/permissions' },
    { id: 'settings', icon: SettingsIcon, path: '/settings' },
  ];

  const filteredNavigationItems = getFilteredNavigationItems(currentUser, navigationItems, t);
  
  const safeIncidents = Array.isArray(incidents) ? incidents : [];
  const safeTasks = Array.isArray(tasks) ? tasks : [];
  const safeUsers = Array.isArray(users) ? users : [];
  const safeRoles = Array.isArray(roles) ? roles : [];
  const safeResidents = Array.isArray(residents) ? residents : [];
  const safeCleaningJobs = Array.isArray(cleaningJobs) ? cleaningJobs : [];
  const safeIdeas = Array.isArray(ideas) ? ideas : [];
  
  const assignableUsers = safeUsers.filter(u => 
    u.name && u.status === 'active' && (
      (Array.isArray(u.roles) && u.roles.some(r => r && r.name && (r.name.toLowerCase() === 'técnico' || r.name.toLowerCase() === 'responsable'))) ||
      (Array.isArray(u.custom_roles) && u.custom_roles.some(cr => cr && (cr.toLowerCase().includes('técnico') || cr.toLowerCase().includes('responsable'))))
    )
  );

  const handleNavigate = (path) => {
    const currentNavItem = filteredNavigationItems.find(item => item.path === path);
    if (currentNavItem) {
      setActiveView(currentNavItem.id);
      navigate(path);
    } else if (path === '/login') {
      setActiveView('login');
      navigate(path);
    }
    setIsMobileSidebarOpen(false);
  };

  useEffect(() => {
    const currentNavItem = filteredNavigationItems.find(item => item.path === location.pathname);
    if (currentNavItem) {
      setActiveView(currentNavItem.id);
    } else if (location.pathname === '/login') {
      setActiveView('login');
    }
  }, [location.pathname, filteredNavigationItems]);

  if (loadingAuth) {
    return (
      <div className="min-h-screen bg-bg-main flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }} 
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!currentUser && location.pathname !== '/login') {
    return <Navigate to="/login" replace />;
  }
  if (currentUser && location.pathname === '/login') {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen bg-bg-main text-foreground transition-colors duration-300">
      {currentUser && location.pathname !== '/login' && (
        <Header 
          appName="NEXUS Task" 
          handleShowToast={handleShowToast} 
          theme={theme} 
          toggleTheme={toggleTheme} 
          onLogout={handleLogout}
          currentUser={currentUser}
          appSettings={appSettings}
          tasks={safeTasks}
          onOpenEditProfile={handleOpenEditProfileModal}
          onOpenAccountSettings={handleOpenAccountSettingsModal}
          onNavigate={handleNavigate}
          setIsMobileSidebarOpen={setIsMobileSidebarOpen}
          location={location}
          navigate={navigate}
        />
      )}

      <div className={`max-w-full mx-auto ${currentUser && location.pathname !== '/login' ? 'px-4 sm:px-6 lg:px-8 py-6' : ''}`}>
        <div className={`flex flex-col ${currentUser && location.pathname !== '/login' ? 'lg:flex-row gap-6' : ''}`}>
          {currentUser && location.pathname !== '/login' && (
            <Sidebar 
              navigationItems={filteredNavigationItems} 
              activeView={activeView} 
              setActiveView={handleNavigate}
              isMobileSidebarOpen={isMobileSidebarOpen}
              setIsMobileSidebarOpen={setIsMobileSidebarOpen}
            />
          )}
          <main className="flex-1 min-w-0">
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/login" element={<LoginView setCurrentUser={setCurrentUser} handleShowToast={handleShowToast} />} />
                {currentUser && (
                  <>
                    <Route path="/dashboard" element={<DashboardView incidents={safeIncidents} tasks={safeTasks} cleaningJobs={safeCleaningJobs} handleShowToast={handleShowToast} setActiveView={handleNavigate} currentUser={currentUser} appSettings={appSettings} />} />
                    <Route path="/mytasks" element={<MyTasksView tasks={safeTasks} handleShowToast={handleShowToast} updateTaskStatus={updateTaskStatus} users={assignableUsers} onQuickUpdateTask={quickUpdateTask} currentUser={currentUser} onEditTask={handleOpenEditTaskModal} onAddTask={handleOpenAddTaskModal} />} />
                    <Route path="/incidents" element={<IncidentsView incidents={safeIncidents} handleShowToast={handleShowToast} users={assignableUsers} currentUser={currentUser} />} />
                    <Route path="/tasks" element={<TasksView tasks={safeTasks} handleShowToast={handleShowToast} updateTaskStatus={updateTaskStatus} users={safeUsers} onQuickUpdateTask={quickUpdateTask} onAddTask={handleOpenAddTaskModal} onEditTask={handleOpenEditTaskModal} currentUser={currentUser} />} />
                    <Route path="/calendar" element={<CalendarView tasks={safeTasks} incidents={safeIncidents} handleShowToast={handleShowToast} setActiveView={handleNavigate} onEditTask={handleOpenEditTaskModal} />} />
                    <Route path="/cleaning" element={<CleaningView cleaningJobs={safeCleaningJobs} handleShowToast={handleShowToast} onUpdateStatus={updateCleaningJobStatus} users={assignableUsers} onAddCleaningJob={handleOpenAddCleaningJobModal} currentUser={currentUser} />} />
                    <Route path="/users" element={<ManageUsersView users={safeUsers} availableRoles={safeRoles} handleShowToast={handleShowToast} onToggleUserStatus={toggleUserStatus} onAddUser={handleOpenAddUserModal} onEditUser={handleOpenEditUserModal} onDeleteUser={handleOpenDeleteUserAlert} currentUser={currentUser} />} />
                    <Route path="/residents" element={<ResidentsView residents={safeResidents} handleShowToast={handleShowToast} onUpdateMedicationStatus={updateResidentMedicationStatus} onAddResident={handleOpenAddResidentModal} onEditResident={handleOpenEditResidentModal} onDeleteResident={handleOpenDeleteResidentAlert} currentUser={currentUser} />} />
                    <Route path="/ideas" element={<IdeasView ideas={safeIdeas} onAddIdea={handleOpenAddIdeaModal} onEditIdea={handleOpenEditIdeaModal} onDeleteIdea={handleOpenDeleteIdeaAlert} currentUser={currentUser} />} />
                    <Route path="/chat" element={<ChatView handleShowToast={handleShowToast} />} />
                    <Route path="/statistics" element={<StatisticsView tasks={safeTasks} incidents={safeIncidents} users={safeUsers} handleShowToast={handleShowToast} />} />
                    <Route path="/permissions" element={<PermissionsView permissions={permissions} roles={roles} handleShowToast={handleShowToast} onUpdatePermissions={updatePermissions} />} />
                    <Route path="/settings" element={<SettingsView theme={theme} toggleTheme={toggleTheme} handleShowToast={handleShowToast} appSettings={appSettings} updateAppSettings={updateAppSettings} currentUser={currentUser} onOpenEditProfile={handleOpenEditProfileModal} tasks={safeTasks} incidents={safeIncidents} cleaningJobs={safeCleaningJobs} resetAllData={resetAllData} />} />
                    <Route path="/notifications" element={<NotificationsView handleShowToast={handleShowToast} />} />
                    <Route path="/history" element={<TaskHistoryView tasks={safeTasks} incidents={safeIncidents} cleaningJobs={safeCleaningJobs} />} />
                    <Route path="/" element={<Navigate to="/dashboard" replace />} />
                    <Route path="*" element={<Navigate to="/dashboard" replace />} />
                  </>
                )}
              </Routes>
            </AnimatePresence>
          </main>
        </div>
      </div>
      
      {currentUser && location.pathname !== '/login' && (
        <div className="fixed bottom-5 right-5 sm:right-8 z-50">
          <ChatWidget />
        </div>
      )}
      
      <Toaster />
      
      <AnimatePresence>
        {isAddTaskModalOpen && <AddTaskModal onClose={handleCloseAddTaskModal} onSave={handleAddTaskAndCloseModal} users={assignableUsers} preselectedUserId={preselectedUserForTask} currentUser={currentUser} />}
        {isEditTaskModalOpen && currentTaskToEdit && <EditTaskModal task={currentTaskToEdit} onClose={handleCloseEditTaskModal} onSave={handleUpdateTaskAndCloseModal} users={assignableUsers} />}
        {isAddResidentModalOpen && <AddResidentModal onClose={handleCloseAddResidentModal} onSave={handleAddResidentAndCloseModal} />}
        {isEditResidentModalOpen && currentResidentToEdit && <EditResidentModal resident={currentResidentToEdit} onClose={handleCloseEditResidentModal} onSave={handleUpdateResidentAndCloseModal} />}
        {isAddUserModalOpen && <AddUserModal onClose={handleCloseAddUserModal} onSave={handleAddUserAndCloseModal} availableRoles={safeRoles} />}
        {isEditUserModalOpen && currentUserToEdit && <EditUserModal user={currentUserToEdit} onClose={handleCloseEditUserModal} onSave={handleUpdateUserAndCloseModal} availableRoles={safeRoles} />}
        {isAddIdeaModalOpen && <AddIdeaModal onClose={handleCloseAddIdeaModal} onSave={handleAddIdeaAndCloseModal} />}
        {isEditIdeaModalOpen && currentIdeaToEdit && <EditIdeaModal idea={currentIdeaToEdit} onClose={handleCloseEditIdeaModal} onSave={handleUpdateIdeaAndCloseModal} />}
        {isAddCleaningJobModalOpen && <AddCleaningJobModal onClose={handleCloseAddCleaningJobModal} onSave={handleAddCleaningJobAndCloseModal} users={assignableUsers} />}
        {isEditProfileModalOpen && <EditProfileModal user={currentUser} onClose={handleCloseEditProfileModal} onSave={handleUpdateProfile} handleShowToast={handleShowToast} />}
        {isAccountSettingsModalOpen && <AccountSettingsModal user={currentUser} onClose={handleCloseAccountSettingsModal} onSave={handleUpdateAccountSettings} handleShowToast={handleShowToast} />}
      </AnimatePresence>
      
      <AlertDialog open={isDeleteUserAlertOpen} onOpenChange={setIsDeleteUserAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción es irreversible. Se eliminará al usuario "{userToDelete?.name}".</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel onClick={handleCloseDeleteUserAlert}>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDeleteUserAndCloseAlert}>Eliminar</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={isDeleteResidentAlertOpen} onOpenChange={setIsDeleteResidentAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción es irreversible. Se eliminará al residente "{residentToDelete?.name}".</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel onClick={handleCloseDeleteResidentAlert}>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDeleteResidentAndCloseAlert}>Eliminar</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={isDeleteIdeaAlertOpen} onOpenChange={setIsDeleteIdeaAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción es irreversible. Se eliminará la idea "{ideaToDelete?.title}".</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel onClick={handleCloseDeleteIdeaAlert}>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDeleteIdeaAndCloseAlert}>Eliminar</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AppMain;