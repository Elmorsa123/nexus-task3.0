import React from 'react';
import { motion } from 'framer-motion';
import { X, Save, Settings, Shield, Bell, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AccountSettingsModal = ({ user, onClose, onSave, handleShowToast }) => {
  if (!user) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave();
  };

  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <Settings className="w-6 h-6 mr-3 text-primary" />
            Ajustes de la Cuenta
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <Tabs defaultValue="security" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="security"><Shield className="w-4 h-4 mr-2"/>Seguridad</TabsTrigger>
            <TabsTrigger value="notifications"><Bell className="w-4 h-4 mr-2"/>Notificaciones</TabsTrigger>
            <TabsTrigger value="data"><Database className="w-4 h-4 mr-2"/>Datos</TabsTrigger>
          </TabsList>
          
          <TabsContent value="security" className="mt-6">
            <form className="space-y-5">
              <h3 className="text-lg font-medium text-text-main">Cambiar Contraseña</h3>
              <div>
                <Label htmlFor="current-password" className={labelClass}>Contraseña Actual</Label>
                <Input type="password" id="current-password" className={inputClass} placeholder="••••••••" />
              </div>
              <div>
                <Label htmlFor="new-password" className={labelClass}>Nueva Contraseña</Label>
                <Input type="password" id="new-password" className={inputClass} placeholder="••••••••" />
              </div>
              <div>
                <Label htmlFor="confirm-password" className={labelClass}>Confirmar Nueva Contraseña</Label>
                <Input type="password" id="confirm-password" className={inputClass} placeholder="••••••••" />
              </div>
              <div className="border-t border-border pt-5 mt-5">
                <h3 className="text-lg font-medium text-text-main">Autenticación de Dos Factores (2FA)</h3>
                <div className="flex items-center justify-between mt-3 bg-background p-4 rounded-lg border border-border">
                  <Label htmlFor="2fa-switch" className="text-sm text-text-secondary">Activar 2FA para mayor seguridad.</Label>
                  <Switch id="2fa-switch" />
                </div>
              </div>
            </form>
          </TabsContent>

          <TabsContent value="notifications" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-text-main">Preferencias de Notificación</h3>
              <div className="flex items-center justify-between bg-background p-4 rounded-lg border border-border">
                <Label htmlFor="task-notif" className="text-sm text-text-secondary">Nuevas tareas asignadas</Label>
                <Switch id="task-notif" defaultChecked />
              </div>
              <div className="flex items-center justify-between bg-background p-4 rounded-lg border border-border">
                <Label htmlFor="incident-notif" className="text-sm text-text-secondary">Incidencias urgentes</Label>
                <Switch id="incident-notif" defaultChecked />
              </div>
              <div className="flex items-center justify-between bg-background p-4 rounded-lg border border-border">
                <Label htmlFor="summary-notif" className="text-sm text-text-secondary">Resumen de actividad semanal</Label>
                <Switch id="summary-notif" />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="data" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-text-main">Gestión de Datos</h3>
              <div className="bg-background p-4 rounded-lg border border-border">
                <h4 className="font-medium text-text-main">Exportar mis datos</h4>
                <p className="text-sm text-text-secondary mb-3">Descarga una copia de tus datos personales y de actividad.</p>
                <Button variant="outline" onClick={() => handleShowToast("Exportar Datos", "🚧 Función en desarrollo.", "info")}>Exportar Datos</Button>
              </div>
              <div className="bg-background p-4 rounded-lg border border-destructive/20">
                <h4 className="font-medium text-destructive">Eliminar mi cuenta</h4>
                <p className="text-sm text-text-secondary mb-3">Esta acción es irreversible. Se eliminarán todos tus datos de forma permanente.</p>
                <Button variant="destructive" onClick={() => handleShowToast("Eliminar Cuenta", "🚧 Función en desarrollo.", "info")}>Eliminar Cuenta</Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end space-x-3 pt-6 border-t border-border mt-6">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="button" variant="default" onClick={handleSubmit}>
            <Save className="w-4 h-4 mr-2" />
            Guardar Ajustes
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default AccountSettingsModal;