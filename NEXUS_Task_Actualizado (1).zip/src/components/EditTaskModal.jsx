
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, Save, ListChecks, User, Type, MessageSquare, CalendarDays, Edit, Tag, AlertTriangle as PriorityIcon, MapPin, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const EditTaskModal = ({ task, onClose, onSave, users }) => {
  const [formData, setFormData] = useState({
    title: '',
    details: '',
    type: 'mantenimiento',
    status: 'pending',
    priority: 'medium',
    assignedto: 'NONE',
    duedate: '',
    zone: '',
  });

  const taskTypeOptions = [
    { value: 'mantenimiento', label: 'Mantenimiento' },
    { value: 'limpieza', label: 'Limpieza' },
    { value: 'atencion-a-residente', label: 'Atención a residente' },
    { value: 'revision-medica', label: 'Revisión médica' },
    { value: 'comida-y-cocina', label: 'Comida y cocina' },
    { value: 'jardineria', label: 'Jardinería' },
    { value: 'otro', label: 'Otro' },
  ];

  useEffect(() => {
    if (task) {
      setFormData({
        title: task.title || '',
        details: task.details || '',
        type: task.type || 'mantenimiento',
        status: task.status || 'pending',
        priority: task.priority || 'medium',
        assignedto: task.assignedto || 'NONE',
        duedate: task.duedate || new Date().toISOString().split('T')[0],
        zone: task.zone || '',
      });
    }
  }, [task]);

  if (!task) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ ...task, ...formData });
  };
  
  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";
  const safeUsers = Array.isArray(users) ? users : [];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <Edit className="w-6 h-6 mr-3 text-primary" />
            Editar Tarea
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label htmlFor="title" className={labelClass}><Type className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Título de la Tarea</Label>
            <Input type="text" name="title" id="title" value={formData.title} onChange={handleChange} className={inputClass} required />
          </div>
          
          <div>
            <Label htmlFor="details" className={labelClass}><MessageSquare className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Detalles</Label>
            <Textarea name="details" id="details" value={formData.details} onChange={handleChange} className={`${inputClass} min-h-[100px]`} required />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="type" className={labelClass}><Tag className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Tipo de Tarea</Label>
              <Select name="type" value={formData.type} onValueChange={(value) => handleSelectChange('type', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar tipo" />
                </SelectTrigger>
                <SelectContent>
                  {taskTypeOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="priority" className={labelClass}><PriorityIcon className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Prioridad</Label>
              <Select name="priority" value={formData.priority} onValueChange={(value) => handleSelectChange('priority', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar prioridad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baja</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="status" className={labelClass}><Activity className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Estado</Label>
              <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="progress">En Progreso</SelectItem>
                  <SelectItem value="completed">Completada</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <div>
              <Label htmlFor="assignedto" className={labelClass}><User className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Asignado A</Label>
              <Select name="assignedto" value={formData.assignedto} onValueChange={(value) => handleSelectChange('assignedto', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar técnico" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NONE">No asignar</SelectItem>
                  {safeUsers.map(user => (
                    <SelectItem key={user.id} value={user.name}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="duedate" className={labelClass}><CalendarDays className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Fecha de Entrega</Label>
              <Input type="date" name="duedate" id="duedate" value={formData.duedate} onChange={handleChange} className={`${inputClass} appearance-none`} />
            </div>
            <div>
              <Label htmlFor="zone" className={labelClass}><MapPin className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Zona/Ubicación</Label>
              <Input type="text" name="zone" id="zone" value={formData.zone} onChange={handleChange} className={inputClass} placeholder="Ej: Planta 2, Habitación 201" />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" variant="default">
              <Save className="w-4 h-4 mr-2" />
              Guardar Cambios
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default EditTaskModal;
