
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, MessageCircle, User, Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area'; 

const ChatMessage = ({ message, isUser }) => {
  const Icon = isUser ? User : Bot;
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={`flex items-end space-x-2 my-3 ${isUser ? 'justify-end' : ''}`}
    >
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center">
          <Icon className="w-5 h-5" />
        </div>
      )}
      <div
        className={`max-w-xs px-4 py-2.5 rounded-xl shadow-md ${
          isUser ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-card text-text-main border border-border rounded-bl-none'
        }`}
      >
        <p className="text-sm whitespace-pre-wrap">{message}</p>
      </div>
      {isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center">
          <Icon className="w-5 h-5" />
        </div>
      )}
    </motion.div>
  );
};

const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setIsTyping(true);
      const timer = setTimeout(() => {
        setMessages([{ text: "¡Hola! Soy tu asistente IA. ¿En qué puedo ayudarte?", isUser: false, id: Date.now() }]);
        setIsTyping(false);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [isOpen, messages.length]);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]');
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  };

  useEffect(() => {
    const timer = setTimeout(scrollToBottom, 100);
    return () => clearTimeout(timer);
  }, [messages, isTyping]);

  const simulateBotResponse = (userInput) => {
    setIsTyping(true);
    const timer = setTimeout(() => {
      let response = "Lo siento, no entendí tu pregunta. ¿Podrías reformularla?";
      const lowerInput = userInput.toLowerCase();

      if (lowerInput.includes("añadir una tarea")) {
        response = "Ve a la sección 'Tareas' y haz clic en el botón '+ Nueva Tarea'.";
      } else if (lowerInput.includes("tareas tengo asignadas")) {
        response = "Puedes ver tus tareas asignadas en el Dashboard, en la sección 'Mis Tareas Asignadas'.";
      } else if (lowerInput.includes("marcar una tarea como finalizada")) {
        response = "En la vista de 'Tareas', puedes hacer clic en el botón de acción de una tarea para cambiar su estado a 'Completada'.";
      } else if (lowerInput.includes("hola")) {
        response = "¡Hola! ¿Cómo puedo asistirte hoy?";
      }

      setMessages(prev => [...prev, { text: response, isUser: false, id: Date.now() }]);
      setIsTyping(false);
    }, 1000);
    return () => clearTimeout(timer);
  };

  const handleSend = () => {
    if (input.trim() === '') return;
    const newUserMessage = { text: input, isUser: true, id: Date.now() };
    setMessages(prev => [...prev, newUserMessage]);
    simulateBotResponse(input);
    setInput('');
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="fixed bottom-24 right-5 sm:right-8 w-[calc(100vw-2.5rem)] sm:w-96 h-[60vh] max-h-[500px] bg-card/90 backdrop-blur-xl rounded-xl shadow-2xl border border-border z-40 flex flex-col overflow-hidden"
          >
            <header className="p-3 border-b border-border flex items-center justify-between flex-shrink-0">
              <div className="flex items-center space-x-2">
                <Bot className="w-6 h-6 text-primary" />
                <h3 className="font-semibold text-text-main">Asistente IA</h3>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-text-secondary hover:text-text-main">
                <X className="w-5 h-5" />
              </Button>
            </header>
            
            <ScrollArea className="flex-1 p-3" ref={scrollAreaRef}>
              <AnimatePresence>
                {messages.map((msg) => (
                  <ChatMessage key={msg.id} message={msg.text} isUser={msg.isUser} />
                ))}
              </AnimatePresence>
              {isTyping && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  exit={{ opacity: 0, y: -10 }}
                  className="flex items-end space-x-2 my-3"
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div className="px-4 py-2.5 rounded-xl shadow-md bg-card text-text-main border border-border rounded-bl-none">
                    <motion.div className="flex space-x-1">
                      <motion.div 
                        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} 
                        transition={{ duration: 0.8, repeat: Infinity, delay: 0 }} 
                        className="w-2 h-2 bg-muted-foreground rounded-full" 
                      />
                      <motion.div 
                        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} 
                        transition={{ duration: 0.8, repeat: Infinity, delay: 0.2 }} 
                        className="w-2 h-2 bg-muted-foreground rounded-full" 
                      />
                      <motion.div 
                        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} 
                        transition={{ duration: 0.8, repeat: Infinity, delay: 0.4 }} 
                        className="w-2 h-2 bg-muted-foreground rounded-full" 
                      />
                    </motion.div>
                  </div>
                </motion.div>
              )}
            </ScrollArea>
            
            <div className="p-3 border-t border-border flex-shrink-0">
              <div className="flex items-center space-x-2">
                <Input
                  type="text"
                  placeholder="Escribe aquí..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  className="flex-1 bg-input border-border focus:ring-primary h-10"
                  disabled={isTyping}
                />
                <Button onClick={handleSend} disabled={isTyping || input.trim() === ''} size="icon">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.5 }}
      >
        <Button
          size="lg"
          className="rounded-full w-16 h-16 shadow-2xl shadow-primary/30"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Abrir chat de asistente"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={isOpen ? 'close' : 'chat'}
              initial={{ opacity: 0, rotate: -30, y: 10 }}
              animate={{ opacity: 1, rotate: 0, y: 0 }}
              exit={{ opacity: 0, rotate: 30, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {isOpen ? <X className="w-7 h-7" /> : <MessageCircle className="w-7 h-7" />}
            </motion.div>
          </AnimatePresence>
        </Button>
      </motion.div>
    </>
  );
};

export default ChatWidget;
