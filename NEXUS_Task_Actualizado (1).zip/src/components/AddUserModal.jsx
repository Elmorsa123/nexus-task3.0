
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, Save, UserPlus, Mail, ShieldCheck, Briefcase, Users as UserRoleIcon, Check, PlusCircle, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Checkbox } from "@/components/ui/checkbox";

const AddUserModal = ({ onClose, onSave, availableRoles = [] }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    roleIds: [], 
    customRole: '',
  });
  const [newCustomRoleInput, setNewCustomRoleInput] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRoleToggle = (roleId) => {
    setFormData(prev => ({
      ...prev,
      roleIds: prev.roleIds.includes(roleId)
        ? prev.roleIds.filter(id => id !== roleId)
        : [...prev.roleIds, roleId]
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const dataToSave = { ...formData };
    if (newCustomRoleInput.trim() !== "") {
        dataToSave.customRole = newCustomRoleInput.trim();
    } else {
        delete dataToSave.customRole;
    }
    onSave(dataToSave);
  };
  
  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";

  const roleIcons = {
    administrador: ShieldCheck,
    responsable: Briefcase,
    técnico: UserRoleIcon,
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <UserPlus className="w-6 h-6 mr-3 text-primary" />
            Añadir Nuevo Usuario
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label htmlFor="name" className={labelClass}><UserPlus className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Nombre Completo</Label>
            <Input type="text" name="name" id="name" value={formData.name} onChange={handleChange} className={inputClass} required />
          </div>

          <div>
            <Label htmlFor="email" className={labelClass}><Mail className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Correo Electrónico</Label>
            <Input type="email" name="email" id="email" value={formData.email} onChange={handleChange} className={inputClass} required />
          </div>
          
          <div>
            <Label className={labelClass}><UserRoleIcon className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Roles Asignados</Label>
            <div className="space-y-2 p-3 bg-background rounded-md border-border max-h-40 overflow-y-auto">
              {availableRoles.map(role => {
                const Icon = roleIcons[role.name.toLowerCase()] || Tag;
                return (
                  <div key={role.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`role-${role.id}`}
                      checked={formData.roleIds.includes(role.id)}
                      onCheckedChange={() => handleRoleToggle(role.id)}
                    />
                    <Label htmlFor={`role-${role.id}`} className="text-sm text-text-secondary flex items-center cursor-pointer">
                      <Icon className="w-4 h-4 mr-2 text-muted-foreground"/>
                      {role.name}
                    </Label>
                  </div>
                );
              })}
            </div>
          </div>

          <div>
             <Label htmlFor="customRole" className={labelClass}><PlusCircle className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Añadir Rol Personalizado (Opcional)</Label>
            <Input 
              type="text" 
              name="customRole" 
              id="customRole" 
              value={newCustomRoleInput} 
              onChange={(e) => setNewCustomRoleInput(e.target.value)} 
              className={inputClass}
              placeholder="Ej: Supervisor de Noche" 
            />
          </div>


          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" variant="default">
              <Save className="w-4 h-4 mr-2" />
              Guardar Usuario
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default AddUserModal;
