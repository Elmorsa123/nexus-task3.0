
import { cn } from '@/lib/utils';
import * as ToastPrimitives from '@radix-ui/react-toast';
import { cva } from 'class-variance-authority';
import { X, CheckCircle, AlertTriangle, Info, AlertCircle } from 'lucide-react';
import React from 'react';

const ToastProvider = ToastPrimitives.Provider;

const ToastViewport = React.forwardRef(({ className, ...props }, ref) => (
	<ToastPrimitives.Viewport
		ref={ref}
		className={cn(
			'fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col sm:max-w-[420px]',
			className,
		)}
		{...props}
	/>
));
ToastViewport.displayName = ToastPrimitives.Viewport.displayName;

const toastVariants = cva(
	'data-[swipe=move]:transition-none group relative pointer-events-auto flex w-full items-center justify-between space-x-4 overflow-hidden rounded-xl border p-5 pr-8 shadow-2xl transition-all data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full data-[state=closed]:slide-out-to-right-full',
	{
		variants: {
			variant: {
				default: 'bg-slate-800 border-slate-700 text-slate-50',
				destructive:
          'group destructive border-red-600/50 bg-red-700 text-red-50',
        success:
          'group success border-green-600/50 bg-green-700 text-green-50',
        info:
          'group info border-sky-600/50 bg-sky-700 text-sky-50',
        warning:
          'group warning border-yellow-600/50 bg-yellow-600 text-yellow-950',
			},
		},
		defaultVariants: {
			variant: 'default',
		},
	},
);

const Toast = React.forwardRef(({ className, variant, ...props }, ref) => {
	return (
		<ToastPrimitives.Root
			ref={ref}
			className={cn(toastVariants({ variant }), className)}
			{...props}
		/>
	);
});
Toast.displayName = ToastPrimitives.Root.displayName;

const ToastAction = React.forwardRef(({ className, ...props }, ref) => (
	<ToastPrimitives.Action
		ref={ref}
		className={cn(
			'inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-slate-900 transition-colors hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50',
      'group-[.destructive]:border-red-500/40 group-[.destructive]:hover:border-red-500/70 group-[.destructive]:hover:bg-red-600 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-500',
      'group-[.success]:border-green-500/40 group-[.success]:hover:border-green-500/70 group-[.success]:hover:bg-green-600 group-[.success]:hover:text-green-50 group-[.success]:focus:ring-green-500',
      'group-[.info]:border-sky-500/40 group-[.info]:hover:border-sky-500/70 group-[.info]:hover:bg-sky-600 group-[.info]:hover:text-sky-50 group-[.info]:focus:ring-sky-500',
      'group-[.warning]:border-yellow-500/40 group-[.warning]:hover:border-yellow-500/70 group-[.warning]:hover:bg-yellow-500 group-[.warning]:hover:text-yellow-950 group-[.warning]:focus:ring-yellow-500',
			className,
		)}
		{...props}
	/>
));
ToastAction.displayName = ToastPrimitives.Action.displayName;

const ToastClose = React.forwardRef(({ className, ...props }, ref) => (
	<ToastPrimitives.Close
		ref={ref}
		className={cn(
			'absolute right-2 top-2 rounded-md p-1 text-slate-300/50 opacity-0 transition-opacity hover:text-slate-100 focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-cyan-500 group-hover:opacity-100',
			'group-[.destructive]:text-red-300/50 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600',
      'group-[.success]:text-green-300/50 group-[.success]:hover:text-green-50 group-[.success]:focus:ring-green-400 group-[.success]:focus:ring-offset-green-600',
      'group-[.info]:text-sky-300/50 group-[.info]:hover:text-sky-50 group-[.info]:focus:ring-sky-400 group-[.info]:focus:ring-offset-sky-600',
      'group-[.warning]:text-yellow-800/50 group-[.warning]:hover:text-yellow-950 group-[.warning]:focus:ring-yellow-400 group-[.warning]:focus:ring-offset-yellow-600',
			className,
		)}
		toast-close=""
		{...props}
	>
		<X className="h-4 w-4" />
	</ToastPrimitives.Close>
));
ToastClose.displayName = ToastPrimitives.Close.displayName;

const ToastTitle = React.forwardRef(({ className, ...props }, ref) => (
	<ToastPrimitives.Title
		ref={ref}
		className={cn('text-sm font-semibold', className)}
		{...props}
	/>
));
ToastTitle.displayName = ToastPrimitives.Title.displayName;

const ToastDescription = React.forwardRef(({ className, ...props }, ref) => (
	<ToastPrimitives.Description
		ref={ref}
		className={cn('text-sm opacity-90', className)}
		{...props}
	/>
));
ToastDescription.displayName = ToastPrimitives.Description.displayName;

const ToastIcon = ({ variant }) => {
  switch (variant) {
    case 'success':
      return <CheckCircle className="w-5 h-5 text-current mr-2" />;
    case 'destructive':
      return <AlertCircle className="w-5 h-5 text-current mr-2" />;
    case 'info':
      return <Info className="w-5 h-5 text-current mr-2" />;
    case 'warning':
      return <AlertTriangle className="w-5 h-5 text-current mr-2" />;
    default:
      return null;
  }
};

export {
	Toast,
	ToastAction,
	ToastClose,
	ToastDescription,
	ToastProvider,
	ToastTitle,
	ToastViewport,
  ToastIcon
};
