
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Save, SprayCan, MapPin, Users, CalendarDays, AlertTriangle as PriorityIcon, RefreshCw, Home, Route, Building, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const empleados = [
  "Juan García (Mantenimiento)",
  "Laura Pérez (Limpieza)",
  "Carlos Ruiz (Jardinería)",
  "Ana Torres (Enfermería)",
  "No asignar"
];

const AddCleaningJobModal = ({ onClose, onSave, users }) => {
  const [formData, setFormData] = useState({
    area: '',
    zone_type: 'room',
    frequency: 'daily',
    priority: 'medium',
    responsible: 'NONE',
    status: 'pending',
    last_cleaned: '',
    next_clean_due: new Date().toISOString().split('T')[0],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };
  
  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <SprayCan className="w-6 h-6 mr-3 text-primary" />
            Nueva Tarea de Limpieza
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="area" className={labelClass}><MapPin className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Nombre del Área</Label>
              <Input type="text" name="area" id="area" value={formData.area} onChange={handleChange} className={inputClass} required placeholder="Ej: Cocina Principal"/>
            </div>
            <div>
              <Label htmlFor="zone_type" className={labelClass}><Home className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Tipo de Zona</Label>
              <Select name="zone_type" value={formData.zone_type} onValueChange={(value) => handleSelectChange('zone_type', value)}>
                <SelectTrigger className={inputClass}><SelectValue placeholder="Seleccionar tipo" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="room"><Home className="inline w-4 h-4 mr-2"/>Habitación</SelectItem>
                  <SelectItem value="hallway"><Route className="inline w-4 h-4 mr-2"/>Pasillo</SelectItem>
                  <SelectItem value="common_area"><Building className="inline w-4 h-4 mr-2"/>Zona Común</SelectItem>
                  <SelectItem value="other"><MapPin className="inline w-4 h-4 mr-2"/>Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="priority" className={labelClass}><PriorityIcon className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Prioridad</Label>
              <Select name="priority" value={formData.priority} onValueChange={(value) => handleSelectChange('priority', value)}>
                <SelectTrigger className={inputClass}><SelectValue placeholder="Seleccionar prioridad" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="low">Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="status" className={labelClass}><Activity className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Estado</Label>
              <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger className={inputClass}><SelectValue placeholder="Seleccionar estado" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="progress">En Proceso</SelectItem>
                  <SelectItem value="completed">Completada</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="responsible" className={labelClass}><Users className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Responsable</Label>
            <Select name="responsible" value={formData.responsible} onValueChange={(value) => handleSelectChange('responsible', value)}>
              <SelectTrigger className={inputClass}><SelectValue placeholder="Seleccionar responsable" /></SelectTrigger>
              <SelectContent>
                {empleados.map(empleado => (
                  <SelectItem key={empleado} value={empleado === "No asignar" ? "NONE" : empleado}>
                    {empleado}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="frequency" className={labelClass}><RefreshCw className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Frecuencia</Label>
              <Select name="frequency" value={formData.frequency} onValueChange={(value) => handleSelectChange('frequency', value)}>
                <SelectTrigger className={inputClass}><SelectValue placeholder="Seleccionar frecuencia" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Diaria</SelectItem>
                  <SelectItem value="weekly">Semanal</SelectItem>
                  <SelectItem value="biweekly">Quincenal</SelectItem>
                  <SelectItem value="monthly">Mensual</SelectItem>
                  <SelectItem value="other">Otra</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="next_clean_due" className={labelClass}><CalendarDays className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Próxima Limpieza</Label>
              <Input type="date" name="next_clean_due" id="next_clean_due" value={formData.next_clean_due} onChange={handleChange} className={`${inputClass} appearance-none`} required />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" variant="default">
              <Save className="w-4 h-4 mr-2" />
              Guardar Tarea
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default AddCleaningJobModal;
