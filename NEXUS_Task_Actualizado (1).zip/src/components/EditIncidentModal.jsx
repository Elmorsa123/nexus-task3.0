
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, Save, AlertTriangle, Building, User, Type, MessageSquare, CalendarDays, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';


const EditIncidentModal = ({ incident, onClose, onSave, users }) => {
  const [formData, setFormData] = useState({
    title: '',
    residence: '',
    description: '',
    status: 'pending',
    priority: 'medium',
    assignedto: 'NONE', // Corrected from assignedTo
    reporteddate: '', // Corrected from reportedDate
  });

  useEffect(() => {
    if (incident) {
      setFormData({
        title: incident.title || '',
        residence: incident.residence || '',
        description: incident.description || '',
        status: incident.status || 'pending',
        priority: incident.priority || 'medium',
        assignedto: incident.assignedto || 'NONE', // Corrected from assignedTo
        reporteddate: incident.reporteddate || new Date().toISOString().split('T')[0], // Corrected from reportedDate
      });
    }
  }, [incident]);

  if (!incident) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ ...incident, ...formData });
  };
  
  const inputClass = "w-full px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm";
  const labelClass = "text-sm font-medium text-text-secondary mb-1.5 block";
  const safeUsers = Array.isArray(users) ? users : [];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 10 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-card border-border rounded-xl shadow-subtle p-6 sm:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-text-main flex items-center">
            <Edit className="w-6 h-6 mr-3 text-primary" />
            Editar Incidencia
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-text-secondary hover:text-text-main hover:bg-accent">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label htmlFor="title" className={labelClass}><Type className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Título</Label>
            <Input type="text" name="title" id="title" value={formData.title} onChange={handleChange} className={inputClass} required />
          </div>

          <div>
            <Label htmlFor="residence" className={labelClass}><Building className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Residencia/Edificio</Label>
            <Input type="text" name="residence" id="residence" value={formData.residence} onChange={handleChange} className={inputClass} required />
          </div>
          
          <div>
            <Label htmlFor="description" className={labelClass}><MessageSquare className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Descripción</Label>
            <Textarea name="description" id="description" value={formData.description} onChange={handleChange} className={`${inputClass} min-h-[100px]`} required />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="status" className={labelClass}>Estado</Label>
              <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="progress">En Progreso</SelectItem>
                  <SelectItem value="completed">Completado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="priority" className={labelClass}>Prioridad</Label>
              <Select name="priority" value={formData.priority} onValueChange={(value) => handleSelectChange('priority', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar prioridad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baja</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <Label htmlFor="assignedto" className={labelClass}><User className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Asignado A</Label>
              <Select name="assignedto" value={formData.assignedto} onValueChange={(value) => handleSelectChange('assignedto', value)}>
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Seleccionar técnico" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NONE">No asignar</SelectItem>
                  {safeUsers.map(user => (
                    <SelectItem key={user.id} value={user.name}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="reporteddate" className={labelClass}><CalendarDays className="inline w-4 h-4 mr-1.5 text-text-secondary"/>Fecha Reporte</Label>
              <Input type="date" name="reporteddate" id="reporteddate" value={formData.reporteddate} onChange={handleChange} className={`${inputClass} appearance-none`} />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" variant="default">
              <Save className="w-4 h-4 mr-2" />
              Guardar Cambios
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default EditIncidentModal;
