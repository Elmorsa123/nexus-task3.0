
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Lightbulb, AlertTriangle, CheckCircle, Clock, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

const ChatMessage = ({ message, isUser, timestamp }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}
  >
    <div className={`flex items-start space-x-3 max-w-[80%] ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}>
      <div className={`p-2 rounded-full ${isUser ? 'bg-primary' : 'bg-secondary'}`}>
        {isUser ? <User className="w-5 h-5 text-primary-foreground" /> : <Bot className="w-5 h-5 text-secondary-foreground" />}
      </div>
      <div className={`p-4 rounded-xl ${isUser ? 'bg-primary text-primary-foreground' : 'bg-card border border-border'}`}>
        <p className="text-sm whitespace-pre-wrap">{message}</p>
        <span className={`text-xs mt-2 block ${isUser ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
          {timestamp}
        </span>
      </div>
    </div>
  </motion.div>
);

const SuggestionCard = ({ icon: Icon, title, description, onClick }) => (
  <Card className="cursor-pointer hover:bg-accent transition-colors" onClick={onClick}>
    <CardContent className="p-4">
      <div className="flex items-start space-x-3">
        <div className="p-2 rounded-lg bg-primary/10">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold text-sm text-text-main">{title}</h3>
          <p className="text-xs text-text-secondary mt-1">{description}</p>
        </div>
      </div>
    </CardContent>
  </Card>
);

const ChatView = ({ handleShowToast }) => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      message: "¡Hola! Soy tu asistente inteligente de NEXUS Task. Puedo ayudarte con:\n\n• Resolver incidencias comunes\n• Sugerir soluciones para problemas repetitivos\n• Optimizar flujos de trabajo\n• Responder preguntas sobre el sistema\n\n¿En qué puedo ayudarte hoy?",
      isUser: false,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const aiResponses = {
    'fuga de agua': {
      solution: 'Para fugas de agua: 1) Cerrar la llave de paso principal, 2) Evaluar la gravedad, 3) Contactar fontanero si es necesario, 4) Documentar daños',
      frequency: 'Esta incidencia se repite cada 3-4 meses',
      prevention: 'Revisar tuberías mensualmente y cambiar juntas cada 6 meses'
    },
    'calefacción': {
      solution: 'Para problemas de calefacción: 1) Verificar termostato, 2) Revisar radiadores, 3) Comprobar caldera, 4) Purgar sistema si es necesario',
      frequency: 'Problema común en invierno, ocurre 2-3 veces por temporada',
      prevention: 'Mantenimiento preventivo antes del invierno y revisión mensual'
    },
    'luz fundida': {
      solution: 'Para luces fundidas: 1) Verificar interruptor, 2) Cambiar bombilla, 3) Revisar fusibles, 4) Comprobar instalación eléctrica',
      frequency: 'Incidencia frecuente, 1-2 veces por semana',
      prevention: 'Usar bombillas LED de calidad y revisar instalación anualmente'
    },
    'ascensor': {
      solution: 'Para problemas de ascensor: 1) No usar hasta revisión, 2) Contactar empresa mantenimiento, 3) Activar protocolo escaleras, 4) Informar a residentes',
      frequency: 'Problema ocasional, 1 vez cada 2-3 meses',
      prevention: 'Mantenimiento mensual obligatorio y revisión técnica trimestral'
    },
    'medicación': {
      solution: 'Para gestión de medicación: 1) Verificar horarios en el sistema, 2) Confirmar dosis con historial médico, 3) Registrar administración, 4) Reportar cualquier reacción',
      frequency: 'Actividad diaria crítica',
      prevention: 'Doble verificación siempre, alarmas automáticas, formación continua'
    },
    'limpieza': {
      solution: 'Para optimizar limpieza: 1) Seguir rutas establecidas, 2) Usar productos adecuados, 3) Verificar inventario, 4) Documentar áreas completadas',
      frequency: 'Tareas diarias y semanales',
      prevention: 'Planificación semanal, rotación de tareas, mantenimiento de equipos'
    }
  };

  const getAIResponse = (userMessage) => {
    const message = userMessage.toLowerCase();
    
    for (const [key, response] of Object.entries(aiResponses)) {
      if (message.includes(key)) {
        return `🔧 **Solución recomendada:**\n${response.solution}\n\n📊 **Frecuencia observada:**\n${response.frequency}\n\n🛡️ **Prevención:**\n${response.prevention}\n\n¿Te ha sido útil esta información? ¿Necesitas más detalles sobre algún paso específico?`;
      }
    }
    
    if (message.includes('tarea') || message.includes('asignar')) {
      return "Para gestionar tareas:\n\n• Ve a la sección 'Tareas' en el menú\n• Haz clic en 'Nueva Tarea'\n• Completa los campos requeridos\n• Asigna a un responsable\n• Establece prioridad y fecha límite\n\n¿Necesitas ayuda con algún paso específico?";
    }
    
    if (message.includes('incidencia') || message.includes('problema')) {
      return "Para reportar incidencias:\n\n• Accede a 'Incidencias' desde el menú\n• Describe el problema detalladamente\n• Indica la ubicación exacta\n• Establece la prioridad\n• El sistema asignará automáticamente al técnico apropiado\n\n¿Qué tipo de incidencia necesitas reportar?";
    }
    
    if (message.includes('residente') || message.includes('medicación')) {
      return "Para gestión de residentes:\n\n• Sección 'Residentes' para ver información completa\n• Control de medicación con horarios\n• Historial médico actualizado\n• Contactos de emergencia\n• Notas especiales de cuidado\n\n¿Necesitas ayuda con algún residente específico?";
    }
    
    if (message.includes('estadística') || message.includes('reporte')) {
      return "Las estadísticas te ayudan a:\n\n• Monitorear productividad del equipo\n• Identificar patrones en incidencias\n• Optimizar asignación de recursos\n• Generar reportes de rendimiento\n• Planificar mejoras operativas\n\n¿Qué tipo de análisis necesitas?";
    }
    
    return "Entiendo tu consulta. Aquí tienes algunas opciones:\n\n• **Incidencias comunes**: Pregúntame sobre fugas, calefacción, luces, etc.\n• **Gestión de tareas**: Cómo crear, asignar y seguir tareas\n• **Cuidado de residentes**: Medicación, horarios, emergencias\n• **Optimización**: Mejores prácticas y eficiencia\n\n¿Sobre qué tema específico te gustaría saber más?";
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      message: inputMessage,
      isUser: true,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    setTimeout(() => {
      const aiResponse = {
        id: Date.now() + 1,
        message: getAIResponse(inputMessage),
        isUser: false,
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSuggestionClick = (suggestion) => {
    setInputMessage(suggestion);
  };

  const suggestions = [
    {
      icon: AlertTriangle,
      title: "¿Cómo resolver una fuga de agua?",
      description: "Protocolo de emergencia para fugas",
      query: "fuga de agua"
    },
    {
      icon: Wrench,
      title: "Problema con la calefacción",
      description: "Pasos para diagnosticar calefacción",
      query: "calefacción no funciona"
    },
    {
      icon: CheckCircle,
      title: "¿Cómo crear una nueva tarea?",
      description: "Guía para asignar tareas al equipo",
      query: "crear nueva tarea"
    },
    {
      icon: Clock,
      title: "Gestión de medicación",
      description: "Horarios y control de medicamentos",
      query: "medicación residentes"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="h-[calc(100vh-12rem)] flex flex-col"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border mb-6">
        <div className="flex items-center space-x-3">
          <Bot className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold text-text-main">Asistente IA</h1>
            <p className="text-text-secondary">Tu ayudante inteligente para resolver problemas y optimizar procesos</p>
          </div>
        </div>
      </div>

      <div className="flex-1 bg-card/80 backdrop-blur-md rounded-xl border-border overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <ChatMessage
              key={message.id}
              message={message.message}
              isUser={message.isUser}
              timestamp={message.timestamp}
            />
          ))}
          
          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start mb-4"
            >
              <div className="flex items-start space-x-3">
                <div className="p-2 rounded-full bg-secondary">
                  <Bot className="w-5 h-5 text-secondary-foreground" />
                </div>
                <div className="p-4 rounded-xl bg-card border border-border">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {messages.length === 1 && (
          <div className="p-6 border-t border-border">
            <h3 className="text-sm font-medium text-text-main mb-3 flex items-center">
              <Lightbulb className="w-4 h-4 mr-2 text-primary" />
              Sugerencias rápidas
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {suggestions.map((suggestion, index) => (
                <SuggestionCard
                  key={index}
                  icon={suggestion.icon}
                  title={suggestion.title}
                  description={suggestion.description}
                  onClick={() => handleSuggestionClick(suggestion.query)}
                />
              ))}
            </div>
          </div>
        )}

        <div className="p-6 border-t border-border">
          <div className="flex space-x-2">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Escribe tu pregunta aquí..."
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1"
              disabled={isTyping}
            />
            <Button onClick={handleSendMessage} disabled={!inputMessage.trim() || isTyping}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ChatView;
