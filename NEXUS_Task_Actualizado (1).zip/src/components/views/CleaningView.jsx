import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Users, CalendarDays, RefreshCw, CheckCircle, Clock, SprayCan, AlertTriangle as PriorityIcon, MapPin, MoreVertical, Edit2, Home, Route, Building } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';


const CleaningJobCard = ({ job, handleShowToast, onUpdateStatus, onEditJob }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'pending': return { text: 'Pendiente', Icon: Clock, color: 'text-warning-foreground dark:text-yellow-300', bg: 'bg-warning/20 border-warning/30' };
      case 'progress': return { text: 'En Proceso', Icon: RefreshCw, color: 'text-primary', bg: 'bg-primary/10 border-primary/30' };
      case 'completed': return { text: 'Realizada', Icon: CheckCircle, color: 'text-success-foreground dark:text-green-300', bg: 'bg-success/20 border-success/30' };
      default: return { text: 'Desconocido', Icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted/20 border-muted/30' };
    }
  };

  const getPriorityInfo = (priority) => {
    switch (priority) {
      case 'high': return { text: 'Alta', color: 'text-destructive' };
      case 'medium': return { text: 'Media', color: 'text-warning-foreground dark:text-yellow-300' };
      case 'low': return { text: 'Baja', color: 'text-primary' };
      default: return { text: 'Normal', color: 'text-muted-foreground' };
    }
  };

  const getFrequencyLabel = (frequency) => {
    const labels = { daily: 'Diaria', weekly: 'Semanal', biweekly: 'Quincenal', monthly: 'Mensual', other: 'Otra' };
    return labels[frequency] || frequency;
  };

  const getZoneTypeIcon = (zoneType) => {
    switch(zoneType) {
      case 'room': return Home;
      case 'hallway': return Route;
      case 'common_area': return Building;
      default: return MapPin;
    }
  };

  const statusInfo = getStatusInfo(job.status);
  const priorityInfo = getPriorityInfo(job.priority);
  const ZoneIcon = getZoneTypeIcon(job.zone_type);

  const handleCompleteClick = (e) => {
    e.stopPropagation();
    if (job.status !== 'completed') {
       onUpdateStatus(job.id, 'completed');
    } else {
       onUpdateStatus(job.id, 'pending');
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-card backdrop-blur-md rounded-xl shadow-sm border-border p-5 hover:border-primary/50 transition-all duration-300 flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-text-main flex items-center">
              <ZoneIcon className="w-5 h-5 mr-2 text-primary"/>{job.area}
            </h3>
            <div className="flex flex-wrap gap-2 mt-1">
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full inline-flex items-center ${statusInfo.bg} ${statusInfo.color}`}>
                <statusInfo.Icon className="w-3.5 h-3.5 mr-1.5" />{statusInfo.text}
              </span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full inline-flex items-center bg-secondary/20 text-secondary-foreground border border-border`}>
                <PriorityIcon className={`w-3.5 h-3.5 mr-1.5 ${priorityInfo.color}`} />Prioridad: {priorityInfo.text}
              </span>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-text-main hover:bg-accent w-8 h-8">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover border-border text-popover-foreground shadow-xl">
              <DropdownMenuItem onClick={() => onEditJob(job)} className="hover:!bg-accent focus:!bg-accent cursor-pointer">
                <Edit2 className="w-4 h-4 mr-2 text-primary" /> Editar Tarea
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={handleCompleteClick} 
                className={`hover:!bg-accent focus:!bg-accent cursor-pointer ${job.status !== 'completed' ? 'text-success' : 'text-warning'}`}
              >
                {job.status !== 'completed' ? <CheckCircle className="w-4 h-4 mr-2"/> : <RefreshCw className="w-4 h-4 mr-2"/>}
                {job.status !== 'completed' ? 'Marcar Realizada' : 'Reabrir Tarea'}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="space-y-1.5 text-sm text-text-secondary mb-4">
          <div className="flex items-center"><Users className="w-4 h-4 mr-2 text-muted-foreground" />Responsable: {job.responsible || 'No asignado'}</div>
          <div className="flex items-center"><RefreshCw className="w-4 h-4 mr-2 text-muted-foreground" />Frecuencia: {getFrequencyLabel(job.frequency)}</div>
          {job.last_cleaned && <div className="flex items-center"><CalendarDays className="w-4 h-4 mr-2 text-muted-foreground" />Última limpieza: {job.last_cleaned}</div>}
          {job.next_clean_due && <div className="flex items-center"><CalendarDays className="w-4 h-4 mr-2 text-muted-foreground" />Próxima limpieza: {job.next_clean_due}</div>}
        </div>
      </div>
    </motion.div>
  );
};

const CleaningView = ({ cleaningJobs, handleShowToast, onAddCleaningJob, onUpdateStatus, users }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const safeCleaningJobs = Array.isArray(cleaningJobs) ? cleaningJobs : [];

  const filteredCleaningJobs = useMemo(() => {
    return safeCleaningJobs
    .filter(job => 
      (job.area && job.area.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (job.responsible && job.responsible.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .filter(job => filterPriority === 'all' || job.priority === filterPriority)
    .filter(job => filterStatus === 'all' || job.status === filterStatus);
  },[safeCleaningJobs, searchTerm, filterPriority, filterStatus]);
    
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-sm border-border">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 w-full md:w-auto flex-wrap gap-y-2">
            <div className="relative flex-1 min-w-[180px] md:w-52">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Buscar por área o responsable..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                 className="w-full pl-10 pr-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm"
              />
            </div>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="min-w-[150px]"><SelectValue placeholder="Prioridad (Todas)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Prioridad (Todas)</SelectItem>
                <SelectItem value="high">Alta</SelectItem>
                <SelectItem value="medium">Media</SelectItem>
                <SelectItem value="low">Baja</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="min-w-[150px]"><SelectValue placeholder="Estado (Todos)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Estado (Todos)</SelectItem>
                <SelectItem value="pending">Pendiente</SelectItem>
                <SelectItem value="progress">En Proceso</SelectItem>
                <SelectItem value="completed">Realizada</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button 
            onClick={onAddCleaningJob} 
            variant="default"
            className="w-full md:w-auto text-sm py-2.5"
          >
            <Plus className="w-4.5 h-4.5 mr-2" />
            Nueva Tarea de Limpieza
          </Button>
        </div>
      </div>

      {filteredCleaningJobs.length > 0 ? (
         <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence>
            {filteredCleaningJobs.map(job => (
              <CleaningJobCard key={job.id} job={job} handleShowToast={handleShowToast} onUpdateStatus={onUpdateStatus} onEditJob={() => handleShowToast("Editar Tarea Limpieza", `Próximamente: Editar tarea de limpieza para ${job.area}`)} />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-10 bg-card/50 rounded-xl">
            <SprayCan className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-text-main mb-2">No se encontraron tareas de limpieza</h3>
            <p className="text-text-secondary">Intenta ajustar los filtros o programa una nueva limpieza.</p>
        </div>
      )}
    </motion.div>
  );
};

export default CleaningView;