
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Settings, Palette, UserCog, Trash2, Bell, FileDown, ChevronRight, Globe, MessageSquare, Paintbrush, Eye, Contrast, Type } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import jsPDF from 'jspdf';
import 'jspdf-autotable';


const SettingsItem = ({ icon: Icon, title, description, onClick, actionElement, disabled = false, isDestructive = false }) => (
  <motion.div
    whileHover={!disabled ? { backgroundColor: 'hsl(var(--accent))' } : {}}
    className={`flex items-center justify-between p-4 bg-card/70 rounded-xl transition-colors border-border shadow-sm ${
      disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-accent cursor-pointer'
    }`}
    onClick={disabled ? undefined : onClick}
  >
    <div className="flex items-center space-x-4">
      <div className={`p-3 rounded-lg ${isDestructive ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <h3 className="font-semibold text-text-main text-md">{title}</h3>
        <p className="text-sm text-text-secondary">{description}</p>
      </div>
    </div>
    {actionElement ? actionElement : <ChevronRight className={`w-5 h-5 ${isDestructive ? 'text-destructive' : 'text-muted-foreground'}`} />}
  </motion.div>
);

const SettingsView = ({ theme, toggleTheme, handleShowToast, appSettings, updateAppSettings, onOpenEditProfile, tasks = [], incidents = [], cleaningJobs = [], resetAllData }) => {
  const [localSettings, setLocalSettings] = useState({
    ...appSettings,
    highVisibility: appSettings.highVisibility || false,
    fontSize: appSettings.fontSize || 'normal',
    contrast: appSettings.contrast || 'normal'
  });
  const [isResetAlertOpen, setIsResetAlertOpen] = useState(false);

  const handleSettingChange = (key, value) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    updateAppSettings(newSettings);
    
    if (key === 'highVisibility' || key === 'fontSize' || key === 'contrast') {
      applyAccessibilitySettings(newSettings);
    }
  };

  const applyAccessibilitySettings = (settings) => {
    const root = document.documentElement;
    
    if (settings.highVisibility) {
      root.classList.add('high-visibility');
    } else {
      root.classList.remove('high-visibility');
    }
    
    root.setAttribute('data-font-size', settings.fontSize);
    root.setAttribute('data-contrast', settings.contrast);
  };
  
  const handleConfirmReset = () => {
    resetAllData();
    setIsResetAlertOpen(false);
  };

  const allHistoryItems = useMemo(() => {
    const allTasks = tasks.map(task => ({
      date: task.duedate, type: 'Tarea', description: task.title, responsible: task.assignedto, status: task.status, notes: task.details
    }));
    const allIncidents = incidents.map(incident => ({
      date: incident.reporteddate, type: 'Incidencia', description: incident.title, responsible: incident.assignedto, status: incident.status, notes: incident.description
    }));
    const allCleaningJobs = cleaningJobs.map(job => ({
      date: job.next_clean_due, type: 'Limpieza', description: `Limpieza: ${job.area}`, responsible: job.responsible, status: job.status, notes: `Frecuencia: ${job.frequency}`
    }));
    return [...allTasks, ...allIncidents, ...allCleaningJobs].filter(item => item.date).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [tasks, incidents, cleaningJobs]);


  const handleExportPDF = () => {
    if (allHistoryItems.length === 0) {
      handleShowToast("Sin datos", "No hay datos para exportar.", "warning");
      return;
    }
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Informe Completo de Actividades - NEXUS Task", 14, 15);
    doc.setFontSize(10);
    doc.text(`Generado el: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`, 14, 22);

    const tableColumn = ["Fecha", "Tipo", "Descripción", "Responsable", "Estado", "Observaciones"];
    const tableRows = [];

    allHistoryItems.forEach(item => {
      const itemData = [
        item.date ? format(new Date(item.date), 'dd/MM/yyyy') : 'N/A',
        item.type || 'N/A',
        item.description || 'N/A',
        item.responsible || 'Sin asignar',
        item.status || 'N/A',
        item.notes || '',
      ];
      tableRows.push(itemData);
    });

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      theme: 'grid',
      headStyles: { fillColor: [59, 130, 246] },
    });

    doc.save('informe_completo_nexus_task.pdf');
    handleShowToast("PDF Generado", "El informe completo se ha descargado.", "success");
  };

  const colorOptions = [
    { value: '#3B82F6', label: 'Azul (Predeterminado)', color: 'bg-blue-500' },
    { value: '#10B981', label: 'Verde', color: 'bg-green-500' },
    { value: '#8B5CF6', label: 'Púrpura', color: 'bg-purple-500' },
    { value: '#F59E0B', label: 'Naranja', color: 'bg-orange-500' },
    { value: '#EF4444', label: 'Rojo', color: 'bg-red-500' },
    { value: '#6B7280', label: 'Gris', color: 'bg-gray-500' }
  ];

  const settingsOptions = [
    {
      id: 'theme',
      icon: Palette,
      title: 'Modo de Apariencia',
      description: `Actualmente: ${theme === 'dark' ? 'Oscuro' : 'Claro'}. Tema automático: ${localSettings.autoTheme ? 'Activado' : 'Desactivado'}.`,
      actionElement: (
        <div className="flex items-center space-x-2" onClick={e => e.stopPropagation()}>
          <div className="flex items-center space-x-2 mr-2">
            <Switch
              id="auto-theme-switch"
              checked={localSettings.autoTheme}
              onCheckedChange={(checked) => handleSettingChange('autoTheme', checked)}
            />
            <Label htmlFor="auto-theme-switch" className="text-xs">Auto</Label>
          </div>
          <Button 
            variant={theme === 'dark' ? "default" : "outline"} 
            onClick={toggleTheme} 
            className="text-xs px-3 py-1 h-auto"
            disabled={localSettings.autoTheme}
          >
            {theme === 'dark' ? 'Claro' : 'Oscuro'}
          </Button>
        </div>
      ),
      onClick: () => {},
    },
    {
      id: 'accessibility',
      icon: Eye,
      title: 'Modo de Alta Visibilidad',
      description: `Mejora la legibilidad para personas mayores o con problemas de visión. ${localSettings.highVisibility ? 'Activado' : 'Desactivado'}.`,
      actionElement: (
        <div className="flex items-center space-x-2" onClick={e => e.stopPropagation()}>
          <Switch
            id="high-visibility-switch"
            checked={localSettings.highVisibility}
            onCheckedChange={(checked) => handleSettingChange('highVisibility', checked)}
          />
        </div>
      ),
      onClick: () => handleSettingChange('highVisibility', !localSettings.highVisibility),
    },
    {
      id: 'fontSize',
      icon: Type,
      title: 'Tamaño de Fuente',
      description: 'Ajusta el tamaño del texto para mejorar la legibilidad.',
      actionElement: (
        <div onClick={e => e.stopPropagation()}>
          <Select value={localSettings.fontSize} onValueChange={(value) => handleSettingChange('fontSize', value)}>
            <SelectTrigger className="w-32 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="small">Pequeño</SelectItem>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="large">Grande</SelectItem>
              <SelectItem value="extra-large">Extra Grande</SelectItem>
            </SelectContent>
          </Select>
        </div>
      ),
      onClick: () => {},
    },
    {
      id: 'contrast',
      icon: Contrast,
      title: 'Contraste',
      description: 'Ajusta el contraste para mejorar la visibilidad.',
      actionElement: (
        <div onClick={e => e.stopPropagation()}>
          <Select value={localSettings.contrast} onValueChange={(value) => handleSettingChange('contrast', value)}>
            <SelectTrigger className="w-32 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="high">Alto</SelectItem>
              <SelectItem value="extra-high">Extra Alto</SelectItem>
            </SelectContent>
          </Select>
        </div>
      ),
      onClick: () => {},
    },
    {
      id: 'language',
      icon: Globe,
      title: 'Idioma de la Interfaz',
      description: `Idioma actual: ${localSettings.language === 'es' ? 'Español' : 'English'}.`,
      actionElement: (
        <div onClick={e => e.stopPropagation()}>
          <Select value={localSettings.language} onValueChange={(value) => handleSettingChange('language', value)}>
            <SelectTrigger className="w-32 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="es">🇪🇸 Español</SelectItem>
              <SelectItem value="en">🇺🇸 English</SelectItem>
            </SelectContent>
          </Select>
        </div>
      ),
      onClick: () => {},
    },
    {
      id: 'primaryColor',
      icon: Paintbrush,
      title: 'Color Principal de la Interfaz',
      description: 'Personaliza el color principal de la aplicación.',
      actionElement: (
        <div onClick={e => e.stopPropagation()}>
          <Select value={localSettings.primaryColor} onValueChange={(value) => handleSettingChange('primaryColor', value)}>
            <SelectTrigger className="w-40 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {colorOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${option.color}`}></div>
                    <span className="text-xs">{option.label}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      ),
      onClick: () => {},
    },
    {
      id: 'welcomeMessage',
      icon: MessageSquare,
      title: 'Mensaje de Bienvenida Personalizado',
      description: 'Cambia el mensaje que aparece en el dashboard.',
      actionElement: (
        <div onClick={e => e.stopPropagation()} className="w-48">
          <Input
            value={localSettings.welcomeMessage}
            onChange={(e) => handleSettingChange('welcomeMessage', e.target.value)}
            placeholder="¡Bienvenido de nuevo!"
            className="h-8 text-xs"
          />
        </div>
      ),
      onClick: () => {},
    },
    {
      id: 'notifications',
      icon: Bell,
      title: 'Notificaciones',
      description: `Actualmente: ${localSettings.notifications ? 'Activadas' : 'Desactivadas'}.`,
      actionElement: (
        <div onClick={e => e.stopPropagation()} className="flex items-center space-x-2">
          <Switch
            id="notifications-switch"
            checked={localSettings.notifications}
            onCheckedChange={(checked) => handleSettingChange('notifications', checked)}
          />
        </div>
      ),
      onClick: () => handleSettingChange('notifications', !localSettings.notifications),
    },
    {
      id: 'profile',
      icon: UserCog,
      title: 'Modificar Perfil de Usuario',
      description: 'Cambia tu información personal y preferencias.',
      onClick: onOpenEditProfile,
    },
    {
      id: 'export',
      icon: FileDown,
      title: 'Exportar Todos los Datos a PDF',
      description: 'Genera un informe completo de todas las actividades.',
      onClick: handleExportPDF,
    },
    {
      id: 'reset',
      icon: Trash2,
      title: 'Resetear Datos de la Aplicación',
      description: 'Elimina todos los datos (acción irreversible).',
      onClick: () => setIsResetAlertOpen(true),
      isDestructive: true,
    },
  ];

  React.useEffect(() => {
    applyAccessibilitySettings(localSettings);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <header className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
        <div className="flex items-center space-x-3">
          <Settings className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold text-text-main">Ajustes</h1>
            <p className="text-text-secondary">Configura y personaliza tu experiencia.</p>
          </div>
        </div>
      </header>

      <div className="space-y-4">
        {settingsOptions.map(option => (
          <SettingsItem
            key={option.id}
            icon={option.icon}
            title={option.title}
            description={option.description}
            onClick={option.onClick}
            actionElement={option.actionElement}
            disabled={option.disabled}
            isDestructive={option.isDestructive}
          />
        ))}
      </div>
      
      <AlertDialog open={isResetAlertOpen} onOpenChange={setIsResetAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás absolutamente seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción es irreversible. Se eliminarán permanentemente todos los datos de la aplicación, incluyendo tareas, incidencias, usuarios y residentes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsResetAlertOpen(false)}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmReset} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Sí, resetear todo
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default SettingsView;