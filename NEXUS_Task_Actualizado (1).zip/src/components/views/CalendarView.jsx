
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, CalendarDays, AlertTriangle, ListChecks, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const CalendarView = ({ tasks = [], incidents = [], handleShowToast, setActiveView, onEditTask, onEditIncident }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const daysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year, month) => new Date(year, month, 1).getDay(); 

  const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const numDays = daysInMonth(year, month);
  const firstDayIndex = (firstDayOfMonth(year, month) + 6) % 7; 

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const goToToday = () => setCurrentDate(new Date());

  const calendarGrid = useMemo(() => {
    const grid = [];
    let dayCounter = 1;
    for (let i = 0; i < 6; i++) { 
      const week = [];
      for (let j = 0; j < 7; j++) {
        if (i === 0 && j < firstDayIndex) {
          week.push(null);
        } else if (dayCounter <= numDays) {
          week.push(dayCounter++);
        } else {
          week.push(null);
        }
      }
      grid.push(week);
      if (dayCounter > numDays && week.every(d => d === null)) break; 
    }
    return grid;
  }, [year, month, numDays, firstDayIndex]);

  const getItemsForDate = (day) => {
    if (!day) return [];
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    
    const safeTasks = Array.isArray(tasks) ? tasks : [];
    const safeIncidents = Array.isArray(incidents) ? incidents : [];

    const dayTasks = safeTasks.filter(task => task.duedate === dateStr); // Corrected from task.dueDate
    const dayIncidents = safeIncidents.filter(incident => incident.reporteddate === dateStr && incident.status !== 'completed'); // Corrected from incident.reportedDate
    
    return [...dayTasks, ...dayIncidents];
  };

  const isToday = (day) => {
    const today = new Date();
    return day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
  };

  const handleItemClick = (item) => {
    if (item.duedate) { // Corrected from item.dueDate
      setActiveView('tasks');
      onEditTask(item);
      handleShowToast("Tarea Seleccionada", `Editando tarea: ${item.title}`, "info");
    } else if (item.reporteddate) { // Corrected from item.reportedDate
      setActiveView('incidents');
      onEditIncident(item);
      handleShowToast("Incidencia Seleccionada", `Editando incidencia: ${item.title}`, "info");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-6 shadow-subtle border-border"
    >
      <div className="flex flex-col sm:flex-row items-center justify-between mb-6">
        <div className="flex items-center space-x-2 sm:space-x-3">
          <Button variant="outline" size="icon" onClick={prevMonth} className="hover:text-primary">
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <h2 className="text-xl sm:text-2xl font-semibold text-text-main w-40 sm:w-auto text-center">
            {monthNames[month]} {year}
          </h2>
          <Button variant="outline" size="icon" onClick={nextMonth} className="hover:text-primary">
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
        <Button onClick={goToToday} variant="outline" className="mt-3 sm:mt-0 text-sm hover:text-primary">
          Hoy
        </Button>
      </div>

      <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
        {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map(dayName => (
          <div key={dayName} className="text-center py-2.5 text-xs font-medium text-text-secondary bg-accent/50">
            {dayName}
          </div>
        ))}
        {calendarGrid.flat().map((day, index) => {
          const items = getItemsForDate(day);
          return (
            <div
              key={index}
              className={cn(
                "relative min-h-[6rem] sm:min-h-[7rem] p-1.5 sm:p-2 bg-card hover:bg-accent/70 transition-colors duration-150",
                day === null && "opacity-50 bg-background",
                isToday(day) && "bg-primary/10 ring-2 ring-primary z-10"
              )}
            >
              {day && <span className={cn("text-xs sm:text-sm font-medium", isToday(day) ? "text-primary" : "text-text-main")}>{day}</span>}
              {items.length > 0 && (
                <div className="mt-1 space-y-1 overflow-y-auto max-h-[calc(6rem-1.5rem)] sm:max-h-[calc(7rem-1.75rem)] pr-1">
                  {items.map(item => (
                    <motion.div
                      key={item.id + (item.duedate ? '-task' : '-incident')} // Corrected from item.dueDate
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2 }}
                      onClick={() => handleItemClick(item)}
                      className={cn(
                        "text-xs px-1.5 py-0.5 rounded-md cursor-pointer flex items-center truncate",
                        item.duedate ? "bg-primary/20 text-primary hover:bg-primary/30" : "bg-warning/20 text-yellow-600 dark:text-warning hover:bg-warning/30" // Corrected from item.dueDate
                      )}
                      title={item.title}
                    >
                      {item.duedate ? <ListChecks className="w-3 h-3 mr-1 shrink-0" /> : <AlertTriangle className="w-3 h-3 mr-1 shrink-0" />} {/* Corrected from item.dueDate */}
                      <span className="truncate">{item.title}</span>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs">
        <div className="flex items-center"><span className="w-3 h-3 rounded-full bg-primary mr-1.5"></span><span className="text-text-secondary">Tarea</span></div>
        <div className="flex items-center"><span className="w-3 h-3 rounded-full bg-warning mr-1.5"></span><span className="text-text-secondary">Incidencia Pendiente</span></div>
      </div>
    </motion.div>
  );
};

export default CalendarView;
