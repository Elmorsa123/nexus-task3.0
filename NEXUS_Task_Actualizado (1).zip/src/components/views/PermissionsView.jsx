
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { PERMISSIONS_MAP } from '@/utils/rolePermissions';

const PermissionsView = ({ permissions, roles, handleShowToast, onUpdatePermissions }) => {
  const [localPermissions, setLocalPermissions] = useState(permissions);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    setLocalPermissions(permissions);
    setHasChanges(false);
  }, [permissions]);

  const handlePermissionChange = (roleKey, permissionKey, isChecked) => {
    setLocalPermissions(prev => ({
      ...prev,
      [roleKey]: {
        ...prev[roleKey],
        [permissionKey]: isChecked
      }
    }));
    setHasChanges(true);
  };

  const handleSaveChanges = () => {
    onUpdatePermissions(localPermissions);
    setHasChanges(false);
    handleShowToast("Permisos Actualizados", "Los cambios se han guardado correctamente.", "success");
  };

  const getRoleDisplayName = (roleKey) => {
    return roleKey.charAt(0).toUpperCase() + roleKey.slice(1).replace(/_/g, ' ');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <header className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
        <div className="flex items-center space-x-3">
          <ShieldCheck className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold text-text-main">Gestión de Permisos</h1>
            <p className="text-text-secondary">Define qué puede hacer cada rol en la aplicación.</p>
          </div>
        </div>
      </header>

      <ScrollArea className="w-full whitespace-nowrap rounded-lg">
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          <div className="grid grid-cols-[minmax(250px,2fr)_repeat(auto-fill,minmax(150px,1fr))]">
            {/* Header Fijo de Permisos */}
            <div className="sticky left-0 bg-card p-4 font-semibold text-text-main border-r border-b border-border z-10">
              Permiso
            </div>
            {/* Headers de Roles */}
            {Object.keys(localPermissions).map(roleKey => (
              <div key={roleKey} className="p-4 font-semibold text-text-main text-center border-r border-b border-border">
                {getRoleDisplayName(roleKey)}
              </div>
            ))}

            {/* Filas de Permisos */}
            {Object.keys(PERMISSIONS_MAP).map(permissionKey => (
              <React.Fragment key={permissionKey}>
                <div className="sticky left-0 bg-card p-4 border-r border-b border-border z-10">
                  <p className="font-medium text-text-main text-sm">{PERMISSIONS_MAP[permissionKey].label}</p>
                  <p className="text-xs text-text-secondary">{PERMISSIONS_MAP[permissionKey].description}</p>
                </div>
                {Object.keys(localPermissions).map(roleKey => (
                  <div key={`${roleKey}-${permissionKey}`} className="flex items-center justify-center p-4 border-r border-b border-border">
                    <Checkbox
                      checked={!!localPermissions[roleKey]?.[permissionKey]}
                      onCheckedChange={(checked) => handlePermissionChange(roleKey, permissionKey, checked)}
                      id={`${roleKey}-${permissionKey}`}
                    />
                  </div>
                ))}
              </React.Fragment>
            ))}
          </div>
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
      
      {hasChanges && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-end sticky bottom-6"
        >
          <Button onClick={handleSaveChanges}>
            <Save className="w-4 h-4 mr-2" />
            Guardar Cambios
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default PermissionsView;
