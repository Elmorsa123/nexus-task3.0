
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, ChevronDown, ChevronUp, AlertTriangle as AlertTriangleIcon, CheckCircle, Clock, Building, User as UserIcon, CalendarDays, Edit3, Filter, ListFilter, MessageSquare, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { hasPermission } from '@/utils/rolePermissions';

const IncidentCard = ({ incident, onToggleDetails, expanded, handleShowToast, onEditIncident }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'pending': return { text: 'Pendiente', Icon: Clock, color: 'text-warning-foreground dark:text-yellow-300', bg: 'bg-warning/20 border-warning/30' };
      case 'progress': return { text: 'En Progreso', Icon: AlertTriangleIcon, color: 'text-primary', bg: 'bg-primary/10 border-primary/30' };
      case 'completed': return { text: 'Completado', Icon: CheckCircle, color: 'text-success-foreground dark:text-green-300', bg: 'bg-success/20 border-success/30' };
      default: return { text: 'Desconocido', Icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted/20 border-muted/30' };
    }
  };

  const getPriorityInfo = (priority) => {
    switch (priority) {
      case 'high': return { text: 'Alta', color: 'text-destructive', bg: 'bg-destructive/20 border-destructive/30' };
      case 'medium': return { text: 'Media', color: 'text-warning-foreground dark:text-yellow-300', bg: 'bg-warning/20 border-warning/30' };
      case 'low': return { text: 'Baja', color: 'text-primary', bg: 'bg-primary/10 border-primary/30' };
      default: return { text: 'Normal', color: 'text-muted-foreground', bg: 'bg-muted/20 border-muted/30' };
    }
  };

  const statusInfo = getStatusInfo(incident.status);
  const priorityInfo = getPriorityInfo(incident.priority);

  const handleEditClick = (e) => {
    e.stopPropagation();
    handleShowToast("Editar Incidencia", "🚧 Esta función aún no está implementada. ¡Puedes solicitarla en tu próximo prompt! 🚀", "info");
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="bg-card backdrop-blur-md rounded-xl shadow-subtle border border-border overflow-hidden hover:border-primary/50 transition-colors duration-300"
    >
      <div className="p-4 sm:p-5 cursor-pointer" onClick={() => onToggleDetails(incident.id)}>
        <div className="flex flex-col sm:flex-row justify-between sm:items-start mb-2">
          <h3 className="text-md font-semibold text-text-main mb-1 sm:mb-0">{incident.title}</h3>
          <div className="flex items-center space-x-2 mt-1 sm:mt-0 self-start sm:self-center">
            <span className={`px-2 py-0.5 text-xs font-medium rounded-full flex items-center ${priorityInfo.bg} ${priorityInfo.color}`}>
              {priorityInfo.text}
            </span>
            <span className={`px-2 py-0.5 text-xs font-medium rounded-full flex items-center ${statusInfo.bg} ${statusInfo.color}`}>
              <statusInfo.Icon className="w-3 h-3 mr-1" />
              {statusInfo.text}
            </span>
          </div>
        </div>
        <div className="flex items-center text-xs text-text-secondary space-x-3">
            <span className="flex items-center"><Building className="w-3.5 h-3.5 mr-1 text-muted-foreground" /> {incident.residence}</span>
            <span className="flex items-center"><CalendarDays className="w-3.5 h-3.5 mr-1 text-muted-foreground" /> {incident.reporteddate}</span>
        </div>
         <div className="text-xs text-text-secondary mt-2">
            <span className="flex items-center"><UserIcon className="w-3.5 h-3.5 mr-1 text-muted-foreground" /> Asignado a: <span className="text-primary ml-1">{incident.assignedto || 'No asignado'}</span></span>
        </div>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "circOut" }}
            className="border-t border-border bg-background/50"
          >
            <div className="p-4 sm:p-5 space-y-4">
              <p className="text-sm text-text-secondary">{incident.description}</p>
              
              <div className="border-t border-border pt-3">
                <h4 className="text-sm font-semibold text-text-main mb-2 flex items-center"><MessageSquare className="w-4 h-4 mr-2 text-primary" />Comentarios</h4>
                <p className="text-xs text-muted-foreground">🚧 La funcionalidad de comentarios estará disponible próximamente.</p>
              </div>

              <div className="border-t border-border pt-3">
                <h4 className="text-sm font-semibold text-text-main mb-2 flex items-center"><History className="w-4 h-4 mr-2 text-primary" />Historial</h4>
                <p className="text-xs text-muted-foreground">🚧 El historial de cambios estará disponible próximamente.</p>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <Button variant="outline" size="sm" className="flex items-center" onClick={handleEditClick}>
                  <Edit3 className="w-3.5 h-3.5 mr-1.5" />
                  Editar/Reasignar
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
       <button 
        onClick={() => onToggleDetails(incident.id)} 
        className="w-full py-2 px-4 sm:px-5 text-xs text-muted-foreground hover:bg-accent hover:text-primary flex items-center justify-center transition-colors"
        aria-expanded={expanded}
        aria-controls={`incident-details-${incident.id}`}
      >
        {expanded ? <ChevronUp className="w-4 h-4 mr-1" /> : <ChevronDown className="w-4 h-4 mr-1" />}
        {expanded ? 'Ocultar Detalles' : 'Ver Detalles'}
      </button>
    </motion.div>
  );
};


const IncidentsView = ({ incidents, handleShowToast, users, currentUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterAssignedTo, setFilterAssignedTo] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  const handleToggleDetails = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const safeIncidents = Array.isArray(incidents) ? incidents : [];

  const filteredIncidents = useMemo(() => {
    return safeIncidents
      .filter(incident => 
        (incident.title && incident.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (incident.residence && incident.residence.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (incident.assignedto && incident.assignedto.toLowerCase().includes(searchTerm.toLowerCase()))
      )
      .filter(incident => filterStatus === 'all' || incident.status === filterStatus)
      .filter(incident => filterPriority === 'all' || incident.priority === filterPriority)
      .filter(incident => filterAssignedTo === 'all' || incident.assignedto === filterAssignedTo || (filterAssignedTo === "UNASSIGNED" && (!incident.assignedto || incident.assignedto === 'NONE')));
  }, [safeIncidents, searchTerm, filterStatus, filterPriority, filterAssignedTo]);
  
  const uniqueAssignedUsers = useMemo(() => {
    return [...new Set(safeIncidents.map(i => i.assignedto).filter(Boolean))];
  }, [safeIncidents]);

  const canAddIncident = hasPermission(currentUser, 'canManageIncidents');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-subtle border-border">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 w-full">
             <div className="relative sm:col-span-2 lg:col-span-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Buscar incidentes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger><SelectValue placeholder="Estado (Todos)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Estado (Todos)</SelectItem>
                <SelectItem value="pending">Pendiente</SelectItem>
                <SelectItem value="progress">En Progreso</SelectItem>
                <SelectItem value="completed">Completado</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger><SelectValue placeholder="Prioridad (Todas)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Prioridad (Todas)</SelectItem>
                <SelectItem value="high">Alta</SelectItem>
                <SelectItem value="medium">Media</SelectItem>
                <SelectItem value="low">Baja</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterAssignedTo} onValueChange={setFilterAssignedTo}>
              <SelectTrigger><SelectValue placeholder="Asignado (Todos)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Asignado (Todos)</SelectItem>
                {uniqueAssignedUsers.map(user => (
                  <SelectItem key={user} value={user}>{user}</SelectItem>
                ))}
                <SelectItem value="UNASSIGNED">No Asignado</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {canAddIncident && (
            <Button 
              onClick={() => handleShowToast("Nueva Incidencia", "🚧 Esta función aún no está implementada. ¡Puedes solicitarla en tu próximo prompt! 🚀", "info")} 
              variant="default"
              className="w-full md:w-auto flex-shrink-0"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nueva Incidencia
            </Button>
          )}
        </div>
      </div>

      {filteredIncidents.length > 0 ? (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
          <AnimatePresence>
            {filteredIncidents.map(incident => (
              <IncidentCard 
                key={incident.id} 
                incident={incident} 
                onToggleDetails={handleToggleDetails} 
                expanded={expandedId === incident.id}
                handleShowToast={handleShowToast}
                onEditIncident={() => {}}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
         <div className="text-center py-10 bg-card/50 rounded-xl">
            <ListFilter className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-text-main mb-2">No se encontraron incidencias</h3>
            <p className="text-text-secondary">Intenta ajustar los filtros o crea una nueva incidencia.</p>
        </div>
      )}
    </motion.div>
  );
};

export default IncidentsView;
