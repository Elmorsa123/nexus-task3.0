
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Edit, Trash2, UserCircle, BedDouble, Pill, Clock, MoreVertical, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { hasPermission } from '@/utils/rolePermissions';

const MedicationItem = ({ med, residentId, medIndex, onUpdateMedicationStatus }) => {
  const isTaken = med.status === 'taken';
  return (
    <div className="flex items-center justify-between text-xs p-2 bg-accent/50 rounded-md">
      <div className="flex items-center">
        <Checkbox
          id={`med-${residentId}-${medIndex}`}
          checked={isTaken}
          onCheckedChange={(checked) => onUpdateMedicationStatus(residentId, medIndex, checked ? 'taken' : 'pending')}
          className="mr-2"
        />
        <Label htmlFor={`med-${residentId}-${medIndex}`} className={`cursor-pointer ${isTaken ? 'line-through text-muted-foreground' : 'text-text-main'}`}>
          <p className="font-medium">{med.name} ({med.dosage})</p>
          <p className="text-muted-foreground">Horario: {med.schedule}</p>
        </Label>
      </div>
      {isTaken ? <Check className="w-4 h-4 text-success" /> : <Clock className="w-4 h-4 text-warning" />}
    </div>
  );
};

const ResidentCard = ({ resident, onEdit, onDelete, onUpdateMedicationStatus, canManage }) => {
  const [showMedications, setShowMedications] = useState(false);
  const safeMedications = Array.isArray(resident.medications) ? resident.medications : [];
  const userInitial = (resident.name || 'R').charAt(0).toUpperCase();

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-card backdrop-blur-md rounded-xl shadow-sm border border-border p-5 hover:border-primary/50 transition-all duration-300 flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={resident.photo_url || ''} alt={resident.name} />
              <AvatarFallback className="bg-primary/20 text-primary font-bold">{userInitial}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-lg font-semibold text-text-main">{resident.name}</h3>
              <p className="text-sm text-text-secondary flex items-center">
                <BedDouble className="w-4 h-4 mr-2 text-muted-foreground" />
                Habitación: {resident.room_number || 'N/A'}
              </p>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-text-main hover:bg-accent w-8 h-8" disabled={!canManage}>
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover border-border text-popover-foreground shadow-xl">
              <DropdownMenuItem onClick={() => onEdit(resident)} className="hover:!bg-accent focus:!bg-accent cursor-pointer" disabled={!canManage}>
                <Edit className="w-4 h-4 mr-2 text-primary" /> Editar Residente
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-border" />
              <DropdownMenuItem onClick={() => onDelete(resident)} className="hover:!bg-destructive/10 focus:!bg-destructive/10 text-destructive cursor-pointer" disabled={!canManage}>
                <Trash2 className="w-4 h-4 mr-2" /> Eliminar Residente
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {safeMedications.length > 0 && (
          <div className="mt-3">
            <Button variant="link" size="sm" onClick={() => setShowMedications(!showMedications)} className="text-primary p-0 h-auto text-sm">
              {showMedications ? 'Ocultar' : 'Mostrar'} Medicación ({safeMedications.length})
            </Button>
            <AnimatePresence>
            {showMedications && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-2 space-y-2 border-t border-border pt-2"
              >
                {safeMedications.map((med, index) => (
                  <MedicationItem 
                    key={index} 
                    med={med} 
                    residentId={resident.id} 
                    medIndex={index} 
                    onUpdateMedicationStatus={onUpdateMedicationStatus} 
                  />
                ))}
              </motion.div>
            )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </motion.div>
  );
};

const ResidentsView = ({ residents, handleShowToast, onAddResident, onEditResident, onDeleteResident, onUpdateMedicationStatus, currentUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const safeResidents = Array.isArray(residents) ? residents : [];
  const canManage = hasPermission(currentUser, 'canManageResidents');

  const filteredResidents = useMemo(() => {
    return safeResidents.filter(resident => 
      (resident.name && resident.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (resident.room_number && resident.room_number.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [safeResidents, searchTerm]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-subtle border-border">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative flex-1 w-full md:w-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar por nombre o habitación..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm"
            />
          </div>
          {canManage && (
            <Button 
              onClick={onAddResident} 
              variant="default"
              className="w-full md:w-auto text-sm py-2.5"
            >
              <Plus className="w-4.5 h-4.5 mr-2" />
              Añadir Residente
            </Button>
          )}
        </div>
      </div>

      {filteredResidents.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence>
            {filteredResidents.map(resident => (
              <ResidentCard 
                key={resident.id} 
                resident={resident} 
                onEdit={onEditResident} 
                onDelete={onDeleteResident}
                onUpdateMedicationStatus={onUpdateMedicationStatus}
                canManage={canManage}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-10 bg-card/50 rounded-xl">
            <UserCircle className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-text-main mb-2">No se encontraron residentes</h3>
            <p className="text-text-secondary">Intenta ajustar la búsqueda o añade un nuevo residente.</p>
        </div>
      )}
    </motion.div>
  );
};

export default ResidentsView;
