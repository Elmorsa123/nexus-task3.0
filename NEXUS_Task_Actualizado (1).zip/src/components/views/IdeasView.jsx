import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Lightbulb, Edit, Trash2, MoreVertical, Clock, CheckCircle, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const IdeaCard = ({ idea, onEdit, onDelete }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'pending': return { text: 'Pendiente', Icon: Clock, color: 'text-warning-foreground dark:text-yellow-300', bg: 'bg-warning/20 border-warning/30' };
      case 'applied': return { text: 'Aplicada', Icon: CheckCircle, color: 'text-success-foreground dark:text-green-300', bg: 'bg-success/20 border-success/30' };
      default: return { text: 'Pendiente', Icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted/20 border-muted/30' };
    }
  };
  const statusInfo = getStatusInfo(idea.status);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-card backdrop-blur-md rounded-xl shadow-subtle border border-border p-4 flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-md font-semibold text-text-main pr-2">{idea.title}</h3>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-text-main hover:bg-accent w-8 h-8 flex-shrink-0">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover border-border text-popover-foreground shadow-xl">
              <DropdownMenuItem onClick={() => onEdit(idea)} className="hover:!bg-accent focus:!bg-accent cursor-pointer">
                <Edit className="w-4 h-4 mr-2 text-primary" /> Editar Idea
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDelete(idea)} className="hover:!bg-destructive/10 focus:!bg-destructive/10 text-destructive cursor-pointer">
                <Trash2 className="w-4 h-4 mr-2" /> Eliminar Idea
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <p className="text-sm text-text-secondary mb-3">{idea.description}</p>
      </div>
      <div className="flex justify-between items-center text-xs text-muted-foreground">
        <span>{new Date(idea.created_at).toLocaleDateString()}</span>
        <span className={`font-medium px-2 py-0.5 rounded-full inline-flex items-center ${statusInfo.bg} ${statusInfo.color}`}>
          <statusInfo.Icon className="w-3 h-3 mr-1.5" />{statusInfo.text}
        </span>
      </div>
    </motion.div>
  );
};

const KanbanColumn = ({ title, ideas, onEdit, onDelete, status, icon: Icon, color }) => (
  <div className="bg-background/50 rounded-xl p-3 w-full md:w-80 flex-shrink-0">
    <div className="flex items-center justify-between mb-3 px-1">
      <h2 className={`font-semibold text-md flex items-center ${color}`}>
        <Icon className="w-5 h-5 mr-2" />
        {title}
      </h2>
      <span className={`text-sm font-bold px-2 py-0.5 rounded-full ${color} bg-opacity-10`}>{ideas.length}</span>
    </div>
    <div className="space-y-3 h-full overflow-y-auto">
      <AnimatePresence>
        {ideas.map(idea => (
          <IdeaCard key={idea.id} idea={idea} onEdit={onEdit} onDelete={onDelete} />
        ))}
      </AnimatePresence>
    </div>
  </div>
);

const IdeasView = ({ ideas, onAddIdea, onEditIdea, onDeleteIdea }) => {
  const safeIdeas = Array.isArray(ideas) ? ideas : [];

  const pendingIdeas = useMemo(() => safeIdeas.filter(i => i.status === 'pending'), [safeIdeas]);
  const appliedIdeas = useMemo(() => safeIdeas.filter(i => i.status === 'applied'), [safeIdeas]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6 h-full flex flex-col"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-subtle border-border flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center space-x-3">
          <Lightbulb className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold text-text-main">Panel de Ideas</h1>
            <p className="text-text-secondary text-sm">Gestiona tus propuestas de mejora.</p>
          </div>
        </div>
        <Button onClick={onAddIdea} variant="default" className="w-full md:w-auto">
          <Plus className="w-4 h-4 mr-2" />
          Añadir Idea
        </Button>
      </div>

      <div className="flex-1 flex flex-col md:flex-row gap-5 overflow-x-auto pb-4">
        <KanbanColumn 
          title="Ideas Pendientes" 
          ideas={pendingIdeas} 
          onEdit={onEditIdea} 
          onDelete={onDeleteIdea} 
          status="pending"
          icon={Clock}
          color="text-warning-foreground dark:text-yellow-300"
        />
        <KanbanColumn 
          title="Ideas Aplicadas" 
          ideas={appliedIdeas} 
          onEdit={onEditIdea} 
          onDelete={onDeleteIdea} 
          status="applied"
          icon={CheckCircle}
          color="text-success-foreground dark:text-green-300"
        />
      </div>
    </motion.div>
  );
};

export default IdeasView;