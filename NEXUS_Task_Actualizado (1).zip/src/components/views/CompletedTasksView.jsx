
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, CheckCircle, Calendar, User, Tag, Filter, History, Clock, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const CompletedTaskCard = ({ task }) => {
  const getTaskTypeLabel = (type) => {
    const labels = {
      mantenimiento: 'Mantenimiento',
      limpieza: 'Limpieza',
      'atencion-a-residente': 'Atención a residente',
      'revision-medica': 'Revisión médica',
      'comida-y-cocina': 'Comida y cocina',
      jardineria: 'Jardinería',
      otro: 'Otro',
      repair: 'Reparación',
      inspection: 'Inspección',
      medication: 'Medicación',
    };
    return labels[type] || (type ? (type.charAt(0).toUpperCase() + type.slice(1)).replace(/-/g, ' ') : 'No especificado');
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-destructive';
      case 'medium': return 'text-warning-foreground dark:text-yellow-300';
      case 'low': return 'text-primary';
      default: return 'text-muted-foreground';
    }
  };

  const completedDate = task.history?.find(h => h.action === 'completed')?.date || task.duedate;
  const completedBy = task.history?.find(h => h.action === 'completed')?.user || task.assignedto;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="bg-card backdrop-blur-md rounded-xl shadow-sm border border-border p-5 hover:border-success/50 transition-all duration-300"
    >
      <div className="flex justify-between items-start mb-3">
        <h3 className="text-lg font-semibold text-text-main">{task.title}</h3>
        <span className="px-2 py-1 text-xs font-medium rounded-full bg-success/20 text-success-foreground dark:text-green-300 flex items-center">
          <CheckCircle className="w-3 h-3 mr-1" />
          Completada
        </span>
      </div>
      
      <p className="text-sm text-text-secondary mb-4 line-clamp-2">{task.details}</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-muted-foreground">
        <div className="flex items-center">
          <Tag className="w-3.5 h-3.5 mr-2" />
          <span>Tipo: {getTaskTypeLabel(task.type)}</span>
        </div>
        <div className="flex items-center">
          <span className={`flex items-center font-medium ${getPriorityColor(task.priority)}`}>
            Prioridad: {task.priority === 'high' ? 'Alta' : task.priority === 'medium' ? 'Media' : 'Baja'}
          </span>
        </div>
        <div className="flex items-center">
          <User className="w-3.5 h-3.5 mr-2" />
          <span>Completada por: {completedBy || 'N/A'}</span>
        </div>
        <div className="flex items-center">
          <Calendar className="w-3.5 h-3.5 mr-2" />
          <span>Fecha: {completedDate ? new Date(completedDate).toLocaleDateString() : 'N/A'}</span>
        </div>
        {task.zone && (
          <div className="flex items-center sm:col-span-2">
            <MapPin className="w-3.5 h-3.5 mr-2" />
            <span>Zona: {task.zone}</span>
          </div>
        )}
      </div>

      {task.history && task.history.length > 0 && (
        <div className="mt-4 pt-3 border-t border-border">
          <h4 className="text-xs font-medium text-text-main mb-2 flex items-center">
            <History className="w-3 h-3 mr-1" />
            Historial
          </h4>
          <div className="space-y-1">
            {task.history.slice(-2).map((entry, index) => (
              <div key={index} className="text-xs text-muted-foreground flex items-center">
                <Clock className="w-3 h-3 mr-1.5" />
                <span>{entry.action === 'completed' ? 'Completada' : entry.action === 'created' ? 'Creada' : entry.action} por {entry.user} - {new Date(entry.date).toLocaleDateString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
};

const CompletedTasksView = ({ tasks = [], handleShowToast }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterUser, setFilterUser] = useState('all');
  const [dateRange, setDateRange] = useState('all');

  const completedTasks = useMemo(() => {
    return Array.isArray(tasks) ? tasks.filter(task => task.status === 'completed') : [];
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    let filtered = completedTasks.filter(task => 
      (task.title && task.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (task.details && task.details.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    if (filterType !== 'all') {
      filtered = filtered.filter(task => task.type === filterType);
    }

    if (filterPriority !== 'all') {
      filtered = filtered.filter(task => task.priority === filterPriority);
    }

    if (filterUser !== 'all') {
      filtered = filtered.filter(task => task.assignedto === filterUser);
    }

    if (dateRange !== 'all') {
      const now = new Date();
      const filterDate = new Date();
      
      switch (dateRange) {
        case 'week':
          filterDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          filterDate.setMonth(now.getMonth() - 1);
          break;
        case 'quarter':
          filterDate.setMonth(now.getMonth() - 3);
          break;
      }
      
      filtered = filtered.filter(task => {
        const completedDate = task.history?.find(h => h.action === 'completed')?.date || task.duedate;
        return completedDate && new Date(completedDate) >= filterDate;
      });
    }

    return filtered.sort((a, b) => {
      const dateA = a.history?.find(h => h.action === 'completed')?.date || a.duedate;
      const dateB = b.history?.find(h => h.action === 'completed')?.date || b.duedate;
      return new Date(dateB) - new Date(dateA);
    });
  }, [completedTasks, searchTerm, filterType, filterPriority, filterUser, dateRange]);

  const uniqueUsers = useMemo(() => {
    return [...new Set(completedTasks.map(task => task.assignedto).filter(Boolean))];
  }, [completedTasks]);

  const taskTypes = [
    { value: 'mantenimiento', label: 'Mantenimiento' },
    { value: 'limpieza', label: 'Limpieza' },
    { value: 'atencion-a-residente', label: 'Atención a residente' },
    { value: 'revision-medica', label: 'Revisión médica' },
    { value: 'comida-y-cocina', label: 'Comida y cocina' },
    { value: 'jardineria', label: 'Jardinería' },
    { value: 'otro', label: 'Otro' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
        <div className="flex items-center space-x-3 mb-6">
          <CheckCircle className="w-8 h-8 text-success" />
          <div>
            <h1 className="text-2xl font-semibold text-text-main">Historial de Tareas Completadas</h1>
            <p className="text-text-secondary">Revisa todas las tareas finalizadas y su historial</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
          <div className="lg:col-span-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Buscar tareas completadas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger>
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los tipos</SelectItem>
              {taskTypes.map(type => (
                <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterPriority} onValueChange={setFilterPriority}>
            <SelectTrigger>
              <SelectValue placeholder="Prioridad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las prioridades</SelectItem>
              <SelectItem value="high">Alta</SelectItem>
              <SelectItem value="medium">Media</SelectItem>
              <SelectItem value="low">Baja</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterUser} onValueChange={setFilterUser}>
            <SelectTrigger>
              <SelectValue placeholder="Usuario" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los usuarios</SelectItem>
              {uniqueUsers.map(user => (
                <SelectItem key={user} value={user}>{user}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger>
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todo el tiempo</SelectItem>
              <SelectItem value="week">Última semana</SelectItem>
              <SelectItem value="month">Último mes</SelectItem>
              <SelectItem value="quarter">Últimos 3 meses</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
          <span>Mostrando {filteredTasks.length} de {completedTasks.length} tareas completadas</span>
          {filteredTasks.length > 0 && (
            <span>Última actualización: {new Date().toLocaleDateString()}</span>
          )}
        </div>
      </div>

      {filteredTasks.length > 0 ? (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
          <AnimatePresence>
            {filteredTasks.map(task => (
              <CompletedTaskCard key={task.id} task={task} />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-12 bg-card/50 rounded-xl">
          <Filter className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold text-text-main mb-2">No se encontraron tareas completadas</h3>
          <p className="text-text-secondary">Intenta ajustar los filtros o completa algunas tareas primero.</p>
        </div>
      )}
    </motion.div>
  );
};

export default CompletedTasksView;
