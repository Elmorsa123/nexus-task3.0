import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ChevronDown, ChevronUp, ListChecks, AlertTriangle, CheckCircle, Clock, CalendarDays, Tag, ListFilter, Edit2, MapPin, AlertOctagon, UserCheck, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { hasPermission } from '@/utils/rolePermissions';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const TaskCard = ({ task, onToggleDetails, expanded, handleShowToast, onUpdateStatus, users, onQuickUpdateTask, onEditTask }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'pending': return { text: 'Pendiente', Icon: Clock, color: 'text-warning-foreground dark:text-yellow-300', bg: 'bg-warning/20 border-warning/30' };
      case 'progress': return { text: 'En Progreso', Icon: AlertTriangle, color: 'text-primary', bg: 'bg-primary/10 border-primary/30' };
      case 'completed': return { text: 'Completada', Icon: CheckCircle, color: 'text-success-foreground dark:text-green-300', bg: 'bg-success/20 border-success/30' };
      default: return { text: 'Desconocido', Icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted/20 border-muted/30' };
    }
  };

  const getPriorityInfo = (priority) => {
    switch (priority) {
      case 'high': return { text: 'Alta', color: 'text-destructive', iconColor: 'text-destructive' };
      case 'medium': return { text: 'Media', color: 'text-warning-foreground dark:text-yellow-300', iconColor: 'text-warning' };
      case 'low': return { text: 'Baja', color: 'text-primary', iconColor: 'text-primary' };
      default: return { text: 'Normal', color: 'text-muted-foreground', iconColor: 'text-muted-foreground' };
    }
  };
  
  const getTaskTypeLabel = (type) => {
    const labels = {
      mantenimiento: 'Mantenimiento',
      limpieza: 'Limpieza',
      'atencion-a-residente': 'Atención a residente',
      'revision-medica': 'Revisión médica',
      'comida-y-cocina': 'Comida y cocina',
      jardineria: 'Jardinería',
      otro: 'Otro',
      repair: 'Reparación',
      inspection: 'Inspección',
      medication: 'Medicación',
    };
    return labels[type] || (type ? (type.charAt(0).toUpperCase() + type.slice(1)).replace(/-/g, ' ') : 'No especificado');
  };

  const statusInfo = getStatusInfo(task.status);
  const priorityInfo = getPriorityInfo(task.priority);
  const safeUsers = Array.isArray(users) ? users : [];

  const handleStatusToggle = (e) => {
    e.stopPropagation(); 
    let nextStatus = 'pending';
    if (task.status === 'pending') nextStatus = 'progress';
    else if (task.status === 'progress') nextStatus = 'completed';
    else if (task.status === 'completed') nextStatus = 'pending'; 
    onUpdateStatus(task.id, nextStatus);
  };
  
  const getNextActionText = () => {
    if (task.status === 'pending') return 'Iniciar Tarea';
    if (task.status === 'progress') return 'Marcar Finalizada';
    if (task.status === 'completed') return 'Reabrir Tarea';
    return 'Actualizar';
  };

  const isOverdue = task.duedate && new Date(task.duedate) < new Date() && task.status !== 'completed';

  const QuickEditSelect = ({ label, field, currentValue, options, icon: Icon }) => (
    <div className="flex-1 min-w-[150px]">
      <Label className="text-xs text-text-secondary mb-1 flex items-center">
        {Icon && <Icon className="w-3 h-3 mr-1.5" />}
        {label}
      </Label>
      <Select
        value={currentValue === null || currentValue === undefined || currentValue === '' ? 'NONE' : currentValue}
        onValueChange={(value) => onQuickUpdateTask(task.id, field, value)}
      >
        <SelectTrigger className="w-full h-9 text-xs bg-input border-border focus:ring-ring">
          <SelectValue placeholder={`Seleccionar ${label.toLowerCase()}`} />
        </SelectTrigger>
        <SelectContent>
          {options.map(opt => (
            <SelectItem key={opt.value} value={opt.value} className="text-xs">
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className={`bg-card backdrop-blur-md rounded-xl shadow-subtle border ${isOverdue ? 'border-destructive/70 hover:border-destructive/70' : 'border-border hover:border-primary/50'} overflow-hidden transition-colors duration-300`}
    >
      <div className="p-4 sm:p-5 cursor-pointer" onClick={() => onToggleDetails(task.id)}>
        <div className="flex flex-col sm:flex-row justify-between sm:items-start mb-2">
          <h3 className="text-md font-semibold text-text-main mb-1 sm:mb-0">{task.title || 'Tarea sin título'}</h3>
          <div className="flex items-center space-x-2 mt-1 sm:mt-0 self-start sm:self-center">
            {isOverdue && (
              <span className="px-2 py-0.5 text-xs font-medium rounded-full flex items-center bg-destructive/20 text-destructive border border-destructive/40">
                <AlertOctagon className="w-3 h-3 mr-1" /> Vencida
              </span>
            )}
            <span className={`px-2 py-0.5 text-xs font-medium rounded-full flex items-center ${statusInfo.bg} ${statusInfo.color}`}>
              <statusInfo.Icon className="w-3 h-3 mr-1" />
              {statusInfo.text}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-text-secondary">
            <span className={`flex items-center font-medium ${priorityInfo.color}`}><AlertTriangle className={`w-3.5 h-3.5 mr-1 ${priorityInfo.iconColor}`} />Prioridad: {priorityInfo.text}</span>
            <span className="flex items-center"><Tag className="w-3.5 h-3.5 mr-1 text-muted-foreground" />Tipo: {getTaskTypeLabel(task.type)}</span>
            <span className="flex items-center"><CalendarDays className="w-3.5 h-3.5 mr-1 text-muted-foreground" />Vence: {task.duedate || 'N/A'}</span>
        </div>
         <div className="text-xs text-text-secondary mt-2">
            {task.zone && <span className="flex items-center"><MapPin className="w-3.5 h-3.5 mr-1 text-muted-foreground" /> Zona: <span className="text-purple-400 dark:text-purple-300 ml-1">{task.zone}</span></span>}
        </div>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "circOut" }}
            className="border-t border-border bg-background/50"
          >
            <div className="p-4 sm:p-5 space-y-4">
              <p className="text-sm text-text-secondary">{task.details || 'Sin detalles adicionales.'}</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <QuickEditSelect
                  label="Estado"
                  field="status"
                  currentValue={task.status}
                  icon={Clock}
                  options={[
                    { value: 'pending', label: 'Pendiente' },
                    { value: 'progress', label: 'En Progreso' },
                    { value: 'completed', label: 'Completada' },
                  ]}
                />
                <QuickEditSelect
                  label="Prioridad"
                  field="priority"
                  currentValue={task.priority}
                  icon={AlertTriangle}
                  options={[
                    { value: 'low', label: 'Baja' },
                    { value: 'medium', label: 'Media' },
                    { value: 'high', label: 'Alta' },
                  ]}
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); onEditTask(task); }}>
                  <Edit2 className="w-3.5 h-3.5 mr-1.5" /> Editar
                </Button>
                <Button 
                  size="sm" 
                  variant={
                    task.status === 'pending' ? 'default' : 
                    task.status === 'progress' ? 'success' : 
                    'warning'
                  }
                  onClick={handleStatusToggle}
                >
                  {getNextActionText()}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <button 
        onClick={() => onToggleDetails(task.id)} 
        className="w-full py-2 px-4 sm:px-5 text-xs text-muted-foreground hover:bg-accent hover:text-primary flex items-center justify-center transition-colors"
        aria-expanded={expanded}
        aria-controls={`task-details-${task.id}`}
      >
        {expanded ? <ChevronUp className="w-4 h-4 mr-1" /> : <ChevronDown className="w-4 h-4 mr-1" />}
        {expanded ? 'Ocultar Detalles' : 'Ver Detalles'}
      </button>
    </motion.div>
  );
};

const MyTasksView = ({ tasks, handleShowToast, updateTaskStatus, users, onQuickUpdateTask, currentUser, onEditTask, onAddTask }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  const handleToggleDetails = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const userName = currentUser?.user_metadata?.name || currentUser?.email?.split('@')[0] || "Usuario";
  const safeTasks = Array.isArray(tasks) ? tasks : [];
  const safeUsers = Array.isArray(users) ? users : [];
  const canCreate = hasPermission(currentUser, 'canCreateTasks');

  const myTasks = useMemo(() => {
    return safeTasks.filter(task => task.assignedto === userName);
  }, [safeTasks, userName]);

  const filteredTasks = useMemo(() => {
    return myTasks
      .filter(task => 
        (task.title && task.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (task.zone && task.zone.toLowerCase().includes(searchTerm.toLowerCase()))
      )
      .filter(task => filterPriority === 'all' || task.priority === filterPriority)
      .filter(task => filterStatus === 'all' || task.status === filterStatus);
  }, [myTasks, searchTerm, filterPriority, filterStatus]);
    
  const inputClass = "px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm appearance-none";
  const selectStyle = { backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='%23${(getComputedStyle(document.documentElement).getPropertyValue('--text-secondary') || '#6B7280').trim().replace('#','')}' class='w-5 h-5'%3E%3Cpath fill-rule='evenodd' d='M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z' clip-rule='evenodd' /%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 0.75rem center', backgroundSize: '1.25em' };

  const pendingCount = myTasks.filter(t => t.status === 'pending').length;
  const progressCount = myTasks.filter(t => t.status === 'progress').length;
  const completedCount = myTasks.filter(t => t.status === 'completed').length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-subtle border-border">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4">
            <div className="flex items-center space-x-3">
              <UserCheck className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-2xl font-semibold text-text-main">Mis Tareas Asignadas</h1>
                <p className="text-text-secondary text-sm">Gestiona las tareas que tienes asignadas, {userName}.</p>
              </div>
            </div>
            {canCreate && (
                <Button onClick={() => onAddTask(currentUser.id)}>
                    <Plus className="w-4 h-4 mr-2" /> Añadir Nueva Tarea
                </Button>
            )}
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center p-3 bg-warning/10 rounded-lg border border-warning/20">
            <div className="text-2xl font-bold text-warning-foreground dark:text-yellow-300">{pendingCount}</div>
            <div className="text-xs text-text-secondary">Pendientes</div>
          </div>
          <div className="text-center p-3 bg-primary/10 rounded-lg border border-primary/20">
            <div className="text-2xl font-bold text-primary">{progressCount}</div>
            <div className="text-xs text-text-secondary">En Progreso</div>
          </div>
          <div className="text-center p-3 bg-success/10 rounded-lg border border-success/20">
            <div className="text-2xl font-bold text-success-foreground dark:text-green-300">{completedCount}</div>
            <div className="text-xs text-text-secondary">Completadas</div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 w-full md:w-auto flex-wrap gap-y-2">
            <div className="relative flex-1 min-w-[180px] md:w-52">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar mis tareas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm"
              />
            </div>
            <select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)} className={inputClass} style={selectStyle}>
              <option value="all" className="bg-popover text-popover-foreground">Prioridad (Todas)</option>
              <option value="high" className="bg-popover text-popover-foreground">Alta</option>
              <option value="medium" className="bg-popover text-popover-foreground">Media</option>
              <option value="low" className="bg-popover text-popover-foreground">Baja</option>
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className={inputClass} style={selectStyle}>
              <option value="all" className="bg-popover text-popover-foreground">Estado (Todos)</option>
              <option value="pending" className="bg-popover text-popover-foreground">Pendiente</option>
              <option value="progress" className="bg-popover text-popover-foreground">En Progreso</option>
              <option value="completed" className="bg-popover text-popover-foreground">Completada</option>
            </select>
          </div>
        </div>
      </div>

      {filteredTasks.length > 0 ? (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
          <AnimatePresence>
            {filteredTasks.map(task => (
              <TaskCard 
                key={task.id} 
                task={task}
                onToggleDetails={handleToggleDetails} 
                expanded={expandedId === task.id}
                handleShowToast={handleShowToast} 
                onUpdateStatus={updateTaskStatus}
                users={safeUsers}
                onQuickUpdateTask={onQuickUpdateTask}
                onEditTask={onEditTask}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-10 bg-card/50 rounded-xl">
            <ListFilter className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-text-main mb-2">No tienes tareas asignadas</h3>
            <p className="text-text-secondary">Cuando te asignen tareas, aparecerán aquí.</p>
        </div>
      )}
    </motion.div>
  );
};

export default MyTasksView;