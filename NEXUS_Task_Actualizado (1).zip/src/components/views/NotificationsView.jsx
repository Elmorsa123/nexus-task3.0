
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, BellOff, AlertTriangle, CheckCircle, Clock, Pill, Settings, Trash2, BookMarked as MarkAsUnread, BookMarked as MarkAsRead } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const NotificationCard = ({ notification, onMarkAsRead, onDelete }) => {
  const getNotificationIcon = (type) => {
    switch (type) {
      case 'task_overdue': return AlertTriangle;
      case 'medication_reminder': return Pill;
      case 'incident_assigned': return Settings;
      case 'cleaning_due': return Clock;
      case 'system_update': return CheckCircle;
      default: return Bell;
    }
  };

  const getNotificationColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-destructive/50 bg-destructive/5';
      case 'medium': return 'border-warning/50 bg-warning/5';
      case 'low': return 'border-primary/50 bg-primary/5';
      default: return 'border-border bg-card';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-destructive';
      case 'medium': return 'text-warning-foreground dark:text-yellow-300';
      case 'low': return 'text-primary';
      default: return 'text-muted-foreground';
    }
  };

  const Icon = getNotificationIcon(notification.type);
  const timeAgo = new Date(notification.created_at).toLocaleString();

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className={`p-4 rounded-xl border transition-all duration-300 hover:shadow-md ${getNotificationColor(notification.priority)} ${
        notification.read ? 'opacity-70' : ''
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-1">
          <div className={`p-2 rounded-lg ${notification.read ? 'bg-muted' : 'bg-primary/10'}`}>
            <Icon className={`w-5 h-5 ${notification.read ? 'text-muted-foreground' : getPriorityColor(notification.priority)}`} />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className={`font-semibold text-sm ${notification.read ? 'text-muted-foreground' : 'text-text-main'}`}>
              {notification.title}
            </h3>
            <p className={`text-sm mt-1 ${notification.read ? 'text-muted-foreground' : 'text-text-secondary'}`}>
              {notification.message}
            </p>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-muted-foreground">{timeAgo}</span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                notification.priority === 'high' ? 'bg-destructive/20 text-destructive' :
                notification.priority === 'medium' ? 'bg-warning/20 text-warning-foreground dark:text-yellow-300' :
                'bg-primary/20 text-primary'
              }`}>
                {notification.priority === 'high' ? 'Alta' : notification.priority === 'medium' ? 'Media' : 'Baja'}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-1 ml-2">
          <Button
            variant="ghost"
            size="icon"
            className="w-8 h-8"
            onClick={() => onMarkAsRead(notification.id, !notification.read)}
          >
            {notification.read ? <MarkAsUnread className="w-4 h-4" /> : <MarkAsRead className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-8 h-8 text-destructive hover:text-destructive"
            onClick={() => onDelete(notification.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

const NotificationsView = ({ handleShowToast }) => {
  const [filter, setFilter] = useState('all');
  const [notifications, setNotifications] = useState(() => {
    const stored = localStorage.getItem('nexus-notifications');
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        console.error('Error parsing notifications:', e);
      }
    }
    return [
      {
        id: '1',
        type: 'task_overdue',
        title: 'Tarea vencida',
        message: 'La tarea "Revisión mensual de extintores" venció hace 2 días',
        priority: 'high',
        user: 'Juan García (Mantenimiento)',
        created_at: '2024-01-16T08:00:00Z',
        read: false
      },
      {
        id: '2',
        type: 'medication_reminder',
        title: 'Recordatorio de medicación',
        message: 'Carmen García López necesita tomar Enalapril a las 20:00',
        priority: 'high',
        user: 'Ana Torres (Enfermería)',
        created_at: '2024-01-16T19:45:00Z',
        read: false
      },
      {
        id: '3',
        type: 'incident_assigned',
        title: 'Nueva incidencia asignada',
        message: 'Se te ha asignado la incidencia "Puerta de emergencia bloqueada"',
        priority: 'medium',
        user: 'Juan García (Mantenimiento)',
        created_at: '2024-01-16T08:15:00Z',
        read: true
      },
      {
        id: '4',
        type: 'cleaning_due',
        title: 'Limpieza programada',
        message: 'La limpieza de "Baños Planta 1" está programada para hoy',
        priority: 'medium',
        user: 'Laura Pérez (Limpieza)',
        created_at: '2024-01-16T07:00:00Z',
        read: false
      },
      {
        id: '5',
        type: 'system_update',
        title: 'Actualización del sistema',
        message: 'Nueva funcionalidad de estadísticas disponible',
        priority: 'low',
        user: 'all',
        created_at: '2024-01-15T12:00:00Z',
        read: true
      }
    ];
  });

  const filteredNotifications = useMemo(() => {
    let filtered = notifications;
    
    switch (filter) {
      case 'unread':
        filtered = notifications.filter(n => !n.read);
        break;
      case 'read':
        filtered = notifications.filter(n => n.read);
        break;
      case 'high':
        filtered = notifications.filter(n => n.priority === 'high');
        break;
      case 'medium':
        filtered = notifications.filter(n => n.priority === 'medium');
        break;
      case 'low':
        filtered = notifications.filter(n => n.priority === 'low');
        break;
    }
    
    return filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }, [notifications, filter]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAsRead = (id, read) => {
    setNotifications(prev => {
      const updated = prev.map(n => n.id === id ? { ...n, read } : n);
      localStorage.setItem('nexus-notifications', JSON.stringify(updated));
      return updated;
    });
    handleShowToast(
      read ? "Marcada como no leída" : "Marcada como leída",
      "Notificación actualizada",
      "success"
    );
  };

  const handleDelete = (id) => {
    setNotifications(prev => {
      const updated = prev.filter(n => n.id !== id);
      localStorage.setItem('nexus-notifications', JSON.stringify(updated));
      return updated;
    });
    handleShowToast("Notificación eliminada", "La notificación ha sido eliminada", "success");
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => {
      const updated = prev.map(n => ({ ...n, read: true }));
      localStorage.setItem('nexus-notifications', JSON.stringify(updated));
      return updated;
    });
    handleShowToast("Todas marcadas como leídas", "Todas las notificaciones han sido marcadas como leídas", "success");
  };

  const handleClearAll = () => {
    setNotifications([]);
    localStorage.setItem('nexus-notifications', JSON.stringify([]));
    handleShowToast("Notificaciones eliminadas", "Todas las notificaciones han sido eliminadas", "success");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center space-x-3">
            <Bell className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-2xl font-semibold text-text-main">Centro de Notificaciones</h1>
              <p className="text-text-secondary">
                {unreadCount > 0 ? `Tienes ${unreadCount} notificaciones sin leer` : 'Todas las notificaciones están al día'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las notificaciones</SelectItem>
                <SelectItem value="unread">No leídas ({unreadCount})</SelectItem>
                <SelectItem value="read">Leídas</SelectItem>
                <SelectItem value="high">Prioridad alta</SelectItem>
                <SelectItem value="medium">Prioridad media</SelectItem>
                <SelectItem value="low">Prioridad baja</SelectItem>
              </SelectContent>
            </Select>
            {unreadCount > 0 && (
              <Button variant="outline" size="sm" onClick={handleMarkAllAsRead}>
                Marcar todas como leídas
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={handleClearAll}>
              <Trash2 className="w-4 h-4 mr-2" />
              Limpiar todo
            </Button>
          </div>
        </div>
      </div>

      {filteredNotifications.length > 0 ? (
        <div className="space-y-3">
          <AnimatePresence>
            {filteredNotifications.map(notification => (
              <NotificationCard
                key={notification.id}
                notification={notification}
                onMarkAsRead={handleMarkAsRead}
                onDelete={handleDelete}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-12 bg-card/50 rounded-xl">
          <BellOff className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold text-text-main mb-2">No hay notificaciones</h3>
          <p className="text-text-secondary">
            {filter === 'all' ? 'No tienes notificaciones en este momento.' : 'No hay notificaciones que coincidan con el filtro seleccionado.'}
          </p>
        </div>
      )}
    </motion.div>
  );
};

export default NotificationsView;
