
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, Users, Clock, CheckCircle, AlertTriangle, Calendar, Award, Target, Activity } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const StatCard = ({ title, value, subtitle, icon: Icon, trend, color = "text-primary" }) => (
  <Card className="bg-card/80 backdrop-blur-md border-border">
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-text-secondary">{title}</p>
          <p className={`text-2xl font-bold ${color}`}>{value}</p>
          {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        <div className={`p-3 rounded-lg bg-primary/10`}>
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
      </div>
      {trend && (
        <div className="mt-4 flex items-center">
          <TrendingUp className="w-4 h-4 text-success mr-1" />
          <span className="text-sm text-success font-medium">{trend}</span>
          <span className="text-sm text-muted-foreground ml-1">vs mes anterior</span>
        </div>
      )}
    </CardContent>
  </Card>
);

const PerformanceBar = ({ name, completed, pending, efficiency }) => {
  const total = completed + pending;
  const completionRate = total > 0 ? (completed / total) * 100 : 0;
  
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium text-text-main">{name}</span>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <span>{completed} completadas</span>
          <span>•</span>
          <span>{efficiency}% eficiencia</span>
        </div>
      </div>
      <div className="w-full bg-secondary/20 rounded-full h-2">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-300" 
          style={{ width: `${completionRate}%` }}
        />
      </div>
    </div>
  );
};

const StatisticsView = ({ tasks = [], incidents = [], users = [], handleShowToast }) => {
  const [timeRange, setTimeRange] = useState('week');
  
  const statistics = useMemo(() => {
    const storedStats = localStorage.getItem('nexus-statistics');
    if (storedStats) {
      try {
        return JSON.parse(storedStats);
      } catch (e) {
        console.error('Error parsing statistics:', e);
      }
    }
    
    return {
      weekly_stats: {
        tasks_completed: 28,
        tasks_pending: 8,
        incidents_resolved: 5,
        incidents_pending: 3,
        completion_rate: 78,
        average_resolution_time: '2.5 días',
        most_active_user: 'Ana Torres (Enfermería)',
        most_common_task_type: 'Atención a residente'
      },
      monthly_stats: {
        tasks_completed: 112,
        tasks_pending: 15,
        incidents_resolved: 18,
        incidents_pending: 4,
        completion_rate: 88,
        average_resolution_time: '2.1 días',
        productivity_trend: '+12%',
        efficiency_score: 92
      },
      user_performance: [
        { name: 'Ana Torres (Enfermería)', completed: 28, pending: 2, efficiency: 93 },
        { name: 'Laura Pérez (Limpieza)', completed: 22, pending: 1, efficiency: 96 },
        { name: 'Juan García (Mantenimiento)', completed: 15, pending: 3, efficiency: 83 },
        { name: 'Carlos Ruiz (Jardinería)', completed: 8, pending: 2, efficiency: 80 },
        { name: 'Pedro Administrador', completed: 5, pending: 1, efficiency: 83 }
      ]
    };
  }, []);

  const currentStats = timeRange === 'week' ? statistics.weekly_stats : statistics.monthly_stats;
  const timeLabel = timeRange === 'week' ? 'Esta Semana' : 'Este Mes';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center space-x-3">
            <BarChart3 className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-2xl font-semibold text-text-main">Panel de Estadísticas</h1>
              <p className="text-text-secondary">Métricas de rendimiento y productividad</p>
            </div>
          </div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Esta Semana</SelectItem>
              <SelectItem value="month">Este Mes</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title={`Tareas Completadas (${timeLabel})`}
          value={currentStats.tasks_completed}
          subtitle={`${currentStats.tasks_pending} pendientes`}
          icon={CheckCircle}
          trend={timeRange === 'month' ? currentStats.productivity_trend : undefined}
          color="text-success"
        />
        <StatCard
          title={`Incidencias Resueltas (${timeLabel})`}
          value={currentStats.incidents_resolved}
          subtitle={`${currentStats.incidents_pending} pendientes`}
          icon={AlertTriangle}
          color="text-warning"
        />
        <StatCard
          title="Tasa de Finalización"
          value={`${currentStats.completion_rate}%`}
          subtitle="Tareas completadas a tiempo"
          icon={Target}
          color="text-primary"
        />
        <StatCard
          title="Tiempo Promedio"
          value={currentStats.average_resolution_time}
          subtitle="Resolución de incidencias"
          icon={Clock}
          color="text-info"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card/80 backdrop-blur-md border-border">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2 text-primary" />
              Rendimiento por Usuario
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {statistics.user_performance.map((user, index) => (
              <PerformanceBar
                key={index}
                name={user.name}
                completed={user.completed}
                pending={user.pending}
                efficiency={user.efficiency}
              />
            ))}
          </CardContent>
        </Card>

        <Card className="bg-card/80 backdrop-blur-md border-border">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2 text-primary" />
              Resumen de Actividad
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-primary/10 rounded-lg">
                <Award className="w-8 h-8 mx-auto text-primary mb-2" />
                <p className="text-sm text-text-secondary">Usuario Más Activo</p>
                <p className="font-semibold text-text-main text-sm">{currentStats.most_active_user}</p>
              </div>
              <div className="text-center p-4 bg-secondary/10 rounded-lg">
                <Calendar className="w-8 h-8 mx-auto text-secondary mb-2" />
                <p className="text-sm text-text-secondary">Tipo Más Común</p>
                <p className="font-semibold text-text-main text-sm">{currentStats.most_common_task_type}</p>
              </div>
            </div>
            
            {timeRange === 'month' && (
              <div className="mt-4 p-4 bg-success/10 rounded-lg border border-success/20">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-text-main">Puntuación de Eficiencia</span>
                  <span className="text-2xl font-bold text-success">{currentStats.efficiency_score}/100</span>
                </div>
                <div className="w-full bg-secondary/20 rounded-full h-2 mt-2">
                  <div 
                    className="bg-success h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${currentStats.efficiency_score}%` }}
                  />
                </div>
              </div>
            )}

            <div className="mt-4 space-y-2">
              <h4 className="font-medium text-text-main">Próximas Mejoras</h4>
              <ul className="text-sm text-text-secondary space-y-1">
                <li>• Gráficos interactivos de tendencias</li>
                <li>• Comparativas entre períodos</li>
                <li>• Alertas de rendimiento</li>
                <li>• Exportación de reportes</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
};

export default StatisticsView;
