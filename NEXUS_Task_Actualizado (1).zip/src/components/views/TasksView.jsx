import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { SortableContext, useSortable, rectSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Plus, GripVertical, AlertTriangle, CheckCircle, Clock, User as UserIcon, CalendarDays, Tag, MapPin, AlertOctagon, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { getRoleStyle, getUserRole, hasPermission } from '@/utils/rolePermissions';
import { useTranslation } from 'react-i18next';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';


const TaskCard = ({ task }) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task.id });
  const style = { transform: CSS.Transform.toString(transform), transition };

  const getStatusInfo = (status) => {
    switch (status) {
      case 'pending': return { text: 'Pendiente', Icon: Clock, color: 'text-warning-foreground dark:text-yellow-300', bg: 'bg-warning/20' };
      case 'progress': return { text: 'En Progreso', Icon: AlertTriangle, color: 'text-primary', bg: 'bg-primary/10' };
      case 'completed': return { text: 'Completada', Icon: CheckCircle, color: 'text-success-foreground dark:text-green-300', bg: 'bg-success/20' };
      default: return { text: 'Desconocido', Icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted/20' };
    }
  };

  const getPriorityInfo = (priority) => {
    switch (priority) {
      case 'high': return { text: 'Alta', color: 'text-destructive' };
      case 'medium': return { text: 'Media', color: 'text-warning-foreground dark:text-yellow-300' };
      case 'low': return { text: 'Baja', color: 'text-primary' };
      default: return { text: 'Normal', color: 'text-muted-foreground' };
    }
  };

  const statusInfo = getStatusInfo(task.status);
  const priorityInfo = getPriorityInfo(task.priority);
  const isOverdue = task.duedate && new Date(task.duedate) < new Date() && task.status !== 'completed';

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`bg-card/80 backdrop-blur-md rounded-xl shadow-sm border ${isOverdue ? 'border-destructive/50' : 'border-border'} p-3.5 mb-3 touch-none ${isDragging ? 'shadow-2xl opacity-80' : 'shadow-sm'}`}
    >
      <div className="flex items-start justify-between">
        <h4 className="font-semibold text-sm text-text-main flex-1 pr-2">{task.title}</h4>
        <div {...attributes} {...listeners} className="cursor-grab text-muted-foreground hover:text-text-main p-1">
          <GripVertical className="w-4 h-4" />
        </div>
      </div>
      <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-text-secondary mt-1">
        <span className={`flex items-center font-medium ${priorityInfo.color}`}><AlertTriangle className="w-3 h-3 mr-1" />{priorityInfo.text}</span>
        <span className="flex items-center"><CalendarDays className="w-3 h-3 mr-1" />{task.duedate || 'N/A'}</span>
      </div>
       {isOverdue && (
        <div className="mt-2 text-xs font-medium flex items-center text-destructive">
          <AlertOctagon className="w-3.5 h-3.5 mr-1" /> Vencida
        </div>
      )}
    </div>
  );
};

const UserColumn = ({ user, tasks, onAddTask }) => {
  const { setNodeRef } = useSortable({ id: user.id, data: { type: 'column' } });
  const userRole = getUserRole(user);
  const roleStyle = getRoleStyle(userRole);
  const userInitial = (user.name || 'U').charAt(0).toUpperCase();

  return (
    <div ref={setNodeRef} className="w-72 flex-shrink-0">
      <div className="bg-card/50 rounded-xl h-full flex flex-col">
        <div className="p-3 border-b border-border flex justify-between items-center">
          <div className="flex items-center space-x-2">
            {user.id !== 'unassigned' && (
              <Avatar className="w-8 h-8">
                <AvatarImage src={user.avatar_url} />
                <AvatarFallback className={`${roleStyle.avatar} font-bold text-xs`}>{userInitial}</AvatarFallback>
              </Avatar>
            )}
            <h3 className="font-semibold text-text-main text-sm">{user.name}</h3>
          </div>
          <span className="text-xs font-medium bg-secondary text-secondary-foreground px-2 py-1 rounded-full">{tasks.length}</span>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-3">
            <SortableContext items={tasks.map(t => t.id)} strategy={rectSortingStrategy}>
              {tasks.map(task => <TaskCard key={task.id} task={task} />)}
            </SortableContext>
          </div>
        </ScrollArea>
        <div className="p-3 border-t border-border">
          <Button variant="ghost" size="sm" className="w-full" onClick={() => onAddTask(user.id)}>
            <Plus className="w-4 h-4 mr-2" /> Añadir Tarea
          </Button>
        </div>
      </div>
    </div>
  );
};

const TasksView = ({ tasks, users, handleShowToast, onAddTask, onQuickUpdateTask, currentUser }) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));

  const canCreate = hasPermission(currentUser, 'canCreateTasks');

  const filteredTasks = useMemo(() => {
    return (tasks || [])
      .filter(task => 
        (task.title && task.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (task.zone && task.zone.toLowerCase().includes(searchTerm.toLowerCase()))
      )
      .filter(task => filterPriority === 'all' || task.priority === filterPriority)
      .filter(task => filterStatus === 'all' || task.status === filterStatus);
  }, [tasks, searchTerm, filterPriority, filterStatus]);

  const columns = useMemo(() => {
    const userColumns = users
      .filter(u => u.status === 'active' && (getUserRole(u) === 'técnico' || getUserRole(u) === 'responsable'))
      .map(user => ({
        id: user.id,
        name: user.name,
        type: 'user',
        tasks: filteredTasks.filter(task => task.assignedto === user.name)
      }));

    const unassignedTasks = filteredTasks.filter(task => !task.assignedto || !users.find(u => u.name === task.assignedto));
    const unassignedColumn = { id: 'unassigned', name: t('tasks.unassigned'), type: 'unassigned', tasks: unassignedTasks };
    
    return [unassignedColumn, ...userColumns];
  }, [filteredTasks, users, t]);

  const handleDragEnd = (event) => {
    const { active, over } = event;
    if (!over) return;
    
    const activeTask = tasks.find(t => t.id === active.id);
    if (!activeTask) return;

    const overColumnContainer = over.data.current;
    const overColumnId = overColumnContainer?.id || over.id;
    
    const overColumn = columns.find(c => c.id === overColumnId);
    if (!overColumn) return;

    const newAssignee = overColumn.type === 'user' ? overColumn.name : null;

    if (activeTask.assignedto !== newAssignee) {
      onQuickUpdateTask(active.id, 'assignedto', newAssignee);
      handleShowToast('Tarea Reasignada', `Se asignó "${activeTask.title}" a ${newAssignee || 'Sin Asignar'}.`, 'success');
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6 h-full flex flex-col"
    >
      <header className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-subtle border-border flex-shrink-0">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-text-main">{t('tasks.title')}</h1>
              <p className="text-text-secondary">{t('tasks.description')}</p>
            </div>
            {canCreate && (
                <Button onClick={() => onAddTask()}>
                    <Plus className="w-4 h-4 mr-2" />
                    Añadir Nueva Tarea
                </Button>
            )}
        </div>
        <div className="mt-4 flex flex-col md:flex-row gap-3 items-center">
            <div className="relative w-full md:w-auto md:flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Buscar por título o zona..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9"
              />
            </div>
             <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger className="w-full md:w-auto min-w-[150px]">
                    <SelectValue placeholder="Prioridad (todas)" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Prioridad (todas)</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                    <SelectItem value="medium">Media</SelectItem>
                    <SelectItem value="low">Baja</SelectItem>
                </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-auto min-w-[150px]">
                    <SelectValue placeholder="Estado (todos)" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Estado (todos)</SelectItem>
                    <SelectItem value="pending">Pendiente</SelectItem>
                    <SelectItem value="progress">En Progreso</SelectItem>
                    <SelectItem value="completed">Completada</SelectItem>
                </SelectContent>
            </Select>
        </div>
      </header>

      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <ScrollArea className="w-full flex-1 pb-4">
          <div className="flex space-x-4">
            <SortableContext items={columns.map(c => c.id)}>
              {columns.map(column => (
                <UserColumn 
                  key={column.id} 
                  user={{id: column.id, name: column.name, ...users.find(u => u.id === column.id)}}
                  tasks={column.tasks} 
                  onAddTask={onAddTask} 
                />
              ))}
            </SortableContext>
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </DndContext>
    </motion.div>
  );
};

export default TasksView;