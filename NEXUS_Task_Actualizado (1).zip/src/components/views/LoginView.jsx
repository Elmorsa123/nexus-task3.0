import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SlidersHorizontal, LogIn, UserPlus, Mail, Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const LoginView = ({ setCurrentUser, handleShowToast }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false); 
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulación de login, ya que Supabase está desconectado
    if (email && password) {
      const mockUser = { id: 'mock-user-id', email: email, name: email.split('@')[0] };
      setCurrentUser(mockUser);
      handleShowToast("Inicio de Sesión Simulado", `¡Bienvenido, ${mockUser.name}! (Modo sin Supabase)`, "success");
      navigate('/dashboard');
    } else {
      handleShowToast("Error de Inicio de Sesión", "Por favor, ingresa email y contraseña.", "destructive");
    }
    setIsSubmitting(false);
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulación de registro
    if (email && password) {
      handleShowToast("Registro Simulado", "¡Cuenta simulada creada! (Modo sin Supabase)", "success");
      setIsSignUp(false); 
    } else {
      handleShowToast("Error de Registro", "Por favor, completa todos los campos.", "destructive");
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-primary/30 via-background to-background p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center space-x-3 mb-10"
      >
        <div className="p-3 bg-primary rounded-xl shadow-lg">
          <SlidersHorizontal className="w-8 h-8 text-primary-foreground" />
        </div>
        <h1 className="text-4xl font-bold text-text-main">
          NEXUS Task
        </h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="w-full max-w-md bg-card p-8 sm:p-10 rounded-2xl shadow-2xl border border-border"
      >
        <h2 className="text-2xl font-semibold text-text-main text-center mb-1">
          {isSignUp ? 'Crear Nueva Cuenta' : 'Bienvenido de Nuevo'}
        </h2>
        <p className="text-sm text-text-secondary text-center mb-6">
          {isSignUp ? 'Completa tus datos para registrarte.' : 'Ingresa tus credenciales para acceder.'}
        </p>

        <form onSubmit={isSignUp ? handleSignUp : handleLogin} className="space-y-6">
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-text-secondary flex items-center mb-1.5">
              <Mail className="w-4 h-4 mr-2 text-muted-foreground" /> Correo Electrónico
            </Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="tu@email.com"
              required
              className="bg-input border-border focus:ring-primary"
            />
          </div>
          <div>
            <Label htmlFor="password" className="text-sm font-medium text-text-secondary flex items-center mb-1.5">
              <Lock className="w-4 h-4 mr-2 text-muted-foreground" /> Contraseña
            </Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="bg-input border-border focus:ring-primary"
            />
          </div>
          <Button type="submit" className="w-full text-base py-3" disabled={isSubmitting}>
            {isSubmitting ? (
              <motion.div 
                animate={{ rotate: 360 }} 
                transition={{ duration: 0.7, repeat: Infinity, ease: "linear" }}
                className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full mr-2"
              />
            ) : (isSignUp ? <UserPlus className="w-5 h-5 mr-2" /> : <LogIn className="w-5 h-5 mr-2" />)}
            {isSubmitting ? (isSignUp ? 'Registrando...' : 'Ingresando...') : (isSignUp ? 'Registrarse' : 'Iniciar Sesión')}
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-text-secondary">
          {isSignUp ? '¿Ya tienes una cuenta?' : '¿No tienes una cuenta?'}
          <Button variant="link" onClick={() => setIsSignUp(!isSignUp)} className="font-semibold text-primary hover:text-primary/80 px-1">
            {isSignUp ? 'Inicia Sesión' : 'Regístrate aquí'}
          </Button>
        </p>
      </motion.div>
      <p className="text-xs text-muted-foreground mt-8 text-center">
        &copy; {new Date().getFullYear()} NEXUS Task. Todos los derechos reservados. (Modo sin Supabase)
      </p>
    </div>
  );
};

export default LoginView;