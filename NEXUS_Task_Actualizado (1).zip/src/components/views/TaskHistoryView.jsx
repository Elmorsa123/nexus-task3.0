import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { History, FileDown, Calendar as CalendarIcon, X as XIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { format, isWithinInterval } from 'date-fns';
import { es } from 'date-fns/locale';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { cn } from '@/lib/utils';

const statusStyles = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
  progress: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300',
  completed: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
};

const StatusBadge = ({ status }) => {
  const normalizedStatus = status ? status.toLowerCase() : 'pending';
  const style = statusStyles[normalizedStatus] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
  const text = {
    pending: 'Pendiente',
    progress: 'En Progreso',
    completed: 'Completada',
  }[normalizedStatus] || 'Pendiente';

  return (
    <span className={`px-2 py-1 text-xs font-medium rounded-full ${style}`}>
      {text}
    </span>
  );
};

const TaskHistoryView = ({ tasks = [], incidents = [], cleaningJobs = [] }) => {
  const [dateRange, setDateRange] = useState(undefined);
  const [filterType, setFilterType] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 10;

  const historyItems = useMemo(() => {
    const allTasks = tasks.map(task => ({
      id: `task-${task.id}`,
      date: task.duedate,
      type: 'Tarea',
      description: task.title || 'Tarea General',
      responsible: task.assignedto || 'Sin asignar',
      status: task.status,
      notes: task.details || '',
    }));

    const allIncidents = incidents.map(incident => ({
      id: `incident-${incident.id}`,
      date: incident.reporteddate,
      type: 'Incidencia',
      description: incident.title || `Incidencia en ${incident.residence || 'N/A'}`,
      responsible: incident.assignedto || 'Sin asignar',
      status: incident.status,
      notes: incident.description || '',
    }));

    const allCleaningJobs = cleaningJobs.map(job => ({
      id: `cleaning-${job.id}`,
      date: job.next_clean_due,
      type: 'Limpieza',
      description: `Limpieza: ${job.area}`,
      responsible: job.responsible || 'Sin asignar',
      status: job.status,
      notes: `Frecuencia: ${job.frequency || 'N/A'}`,
    }));
    
    return [...allTasks, ...allIncidents, ...allCleaningJobs]
      .filter(item => item.date)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [tasks, incidents, cleaningJobs]);

  const filteredItems = useMemo(() => {
    setCurrentPage(1);
    return historyItems.filter(item => {
      const itemDate = new Date(item.date);
      const isDateInRange = !dateRange || (dateRange.from && !dateRange.to && format(itemDate, 'yyyy-MM-dd') === format(dateRange.from, 'yyyy-MM-dd')) || (dateRange.from && dateRange.to && isWithinInterval(itemDate, { start: dateRange.from, end: dateRange.to }));
      const isTypeMatch = filterType === 'all' || item.type === filterType;
      return isDateInRange && isTypeMatch;
    });
  }, [historyItems, dateRange, filterType]);

  const paginatedItems = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    return filteredItems.slice(startIndex, endIndex);
  }, [filteredItems, currentPage]);

  const pageCount = Math.ceil(filteredItems.length / ITEMS_PER_PAGE);

  const handleExportPDF = () => {
    const doc = new jsPDF();
    let title = "Historial de Actividades - NEXUS Task";
    let startY = 25;

    doc.setFontSize(16);
    doc.text(title, 14, 15);

    if (dateRange?.from) {
      const from = format(dateRange.from, 'dd/MM/yyyy');
      const to = dateRange.to ? format(dateRange.to, 'dd/MM/yyyy') : from;
      doc.setFontSize(10);
      doc.text(`Periodo: ${from} - ${to}`, 14, 20);
    }
    if (filterType !== 'all') {
       doc.setFontSize(10);
       doc.text(`Tipo: ${filterType}`, 100, 20);
    }
    
    const tableColumn = ["Fecha", "Tipo", "Descripción", "Responsable", "Estado", "Observaciones"];
    const tableRows = [];

    filteredItems.forEach(item => {
      const itemData = [
        item.date ? format(new Date(item.date), 'dd/MM/yyyy') : 'N/A',
        item.type || 'N/A',
        item.description || 'N/A',
        item.responsible || 'N/A',
        item.status || 'N/A',
        item.notes || '',
      ];
      tableRows.push(itemData);
    });

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: startY,
      theme: 'grid',
      headStyles: { fillColor: [59, 130, 246] },
    });

    doc.save('historial_nexus_task.pdf');
  };

  const resetFilters = () => {
    setDateRange(undefined);
    setFilterType('all');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <Card className="bg-card/80 backdrop-blur-md">
        <CardHeader>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="bg-primary/10 p-3 rounded-lg border border-primary/20">
                <History className="w-8 h-8 text-primary" />
              </div>
              <div>
                <CardTitle className="text-2xl">Historial / Exportar</CardTitle>
                <CardDescription>Filtra, visualiza y exporta el registro de actividades.</CardDescription>
              </div>
            </div>
            <Button onClick={handleExportPDF} disabled={filteredItems.length === 0}>
              <FileDown className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 items-end p-4 bg-muted/50 rounded-lg">
            <div className="grid gap-2 w-full md:w-auto">
              <Label htmlFor="date-range">Rango de Fechas</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="date-range"
                    variant={"outline"}
                    className={cn(
                      "w-full md:w-[300px] justify-start text-left font-normal",
                      !dateRange && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange?.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "LLL dd, y", { locale: es })} -{" "}
                          {format(dateRange.to, "LLL dd, y", { locale: es })}
                        </>
                      ) : (
                        format(dateRange.from, "LLL dd, y", { locale: es })
                      )
                    ) : (
                      <span>Selecciona un rango</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                    locale={es}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="grid gap-2 w-full md:w-auto">
              <Label htmlFor="type-filter">Tipo de Actividad</Label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger id="type-filter" className="w-full md:w-[180px]">
                  <SelectValue placeholder="Filtrar por tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="Tarea">Tarea</SelectItem>
                  <SelectItem value="Incidencia">Incidencia</SelectItem>
                  <SelectItem value="Limpieza">Limpieza</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button variant="ghost" onClick={resetFilters} className="w-full md:w-auto">
              <XIcon className="w-4 h-4 mr-2" />
              Limpiar Filtros
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-border">
              <thead className="bg-muted/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Fecha</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Tipo</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Descripción</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Responsable</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Estado</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Observaciones</th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {paginatedItems.map((item) => (
                  <motion.tr 
                    key={item.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                    className="hover:bg-muted/50"
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{item.date ? format(new Date(item.date), 'dd/MM/yyyy') : 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">{item.type}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">{item.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{item.responsible}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <StatusBadge status={item.status} />
                    </td>
                    <td className="px-6 py-4 whitespace-normal text-sm text-muted-foreground max-w-xs truncate" title={item.notes}>{item.notes}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
           {filteredItems.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p>No se encontraron resultados para los filtros aplicados.</p>
            </div>
          )}
        </CardContent>
        {pageCount > 1 && (
          <CardFooter className="flex items-center justify-between border-t px-6 py-4">
            <span className="text-sm text-muted-foreground">
              Página {currentPage} de {pageCount}
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
                Anterior
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, pageCount))}
                disabled={currentPage === pageCount}
              >
                Siguiente
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardFooter>
        )}
      </Card>
    </motion.div>
  );
};

export default TaskHistoryView;