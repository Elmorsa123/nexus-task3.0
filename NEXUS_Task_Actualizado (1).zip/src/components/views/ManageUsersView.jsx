
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Edit, Trash2, UserPlus, Users, Shield, Briefcase, Mail, ToggleLeft, ToggleRight, MoreVertical, Tag, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { hasPermission, getUserRole, getRoleStyle } from '@/utils/rolePermissions';

const UserCard = ({ user, onEdit, onDelete, onToggleStatus, canManage }) => {
  const userRole = getUserRole(user);
  const roleStyle = getRoleStyle(userRole);
  const userInitial = (user.name || 'U').charAt(0).toUpperCase();

  const displayRole = userRole.charAt(0).toUpperCase() + userRole.slice(1).replace(/_/g, ' ');

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-card backdrop-blur-md rounded-xl shadow-subtle border border-border p-5 hover:border-primary/50 transition-all duration-300 flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center space-x-4">
            <Avatar className="w-12 h-12">
              <AvatarImage src={user.avatar_url} />
              <AvatarFallback className={`${roleStyle.avatar} font-bold`}>{userInitial}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-lg font-semibold text-text-main">{user.name}</h3>
              <div className={`text-xs font-medium px-2 py-0.5 rounded-full inline-flex items-center mt-1 ${roleStyle.avatar}`}>
                  <Crown className={`w-3.5 h-3.5 mr-1 ${roleStyle.text}`} /> {displayRole}
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-text-main hover:bg-accent w-8 h-8" disabled={!canManage}>
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover border-border text-popover-foreground shadow-xl">
              <DropdownMenuItem onClick={() => onEdit(user)} className="hover:!bg-accent focus:!bg-accent cursor-pointer" disabled={!canManage}>
                <Edit className="w-4 h-4 mr-2 text-primary" /> Editar Usuario
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onToggleStatus(user.id)} className="hover:!bg-accent focus:!bg-accent cursor-pointer" disabled={!canManage}>
                {user.status === 'active' ? <ToggleLeft className="w-4 h-4 mr-2 text-warning-foreground dark:text-yellow-300" /> : <ToggleRight className="w-4 h-4 mr-2 text-success-foreground dark:text-green-300" />}
                {user.status === 'active' ? 'Desactivar' : 'Activar'}
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-border" />
              <DropdownMenuItem onClick={() => onDelete(user)} className="hover:!bg-destructive/10 focus:!bg-destructive/10 text-destructive cursor-pointer" disabled={!canManage}>
                <Trash2 className="w-4 h-4 mr-2" /> Eliminar Usuario
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="space-y-1.5 text-sm text-text-secondary mb-4">
          <div className="flex items-center"><Mail className="w-4 h-4 mr-2 text-muted-foreground" />{user.email}</div>
        </div>
      </div>
      <div className="mt-auto">
        <span className={`px-2.5 py-1 text-xs font-medium rounded-full flex items-center self-start w-fit ${user.status === 'active' ? 'bg-success/20 text-success-foreground dark:text-green-300' : 'bg-muted text-muted-foreground'}`}>
          {user.status === 'active' ? 'Activo' : 'Inactivo'}
        </span>
      </div>
    </motion.div>
  );
};

const ManageUsersView = ({ users, availableRoles, handleShowToast, onAddUser, onEditUser, onDeleteUser, onToggleUserStatus, currentUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all'); 
  const safeUsers = Array.isArray(users) ? users : [];
  const safeAvailableRoles = Array.isArray(availableRoles) ? availableRoles : [];

  const canManage = hasPermission(currentUser, 'canManageUsers');

  const filteredUsers = useMemo(() => {
    return safeUsers
    .filter(user => 
      (user.name && user.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .filter(userToFilter => {
      if (filterRole === 'all') return true;
      return getUserRole(userToFilter) === filterRole;
    });
  }, [safeUsers, searchTerm, filterRole]);


  const inputClass = "px-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm appearance-none";
  const selectStyle = { backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='%23${(getComputedStyle(document.documentElement).getPropertyValue('--text-secondary') || '#6B7280').trim().replace('#','')}' class='w-5 h-5'%3E%3Cpath fill-rule='evenodd' d='M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z' clip-rule='evenodd' /%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 0.75rem center', backgroundSize: '1.25em' };

  const allRoleNamesForFilter = useMemo(() => {
    const roleNames = new Set(safeUsers.map(user => getUserRole(user)));
    return Array.from(roleNames).sort();
  }, [safeUsers]);


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-4 sm:p-5 shadow-subtle border-border">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Buscar por nombre o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border-border bg-input text-foreground rounded-lg focus:ring-2 focus:ring-ring placeholder:text-muted-foreground text-sm"
              />
            </div>
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className={inputClass}
              style={selectStyle}
            >
              <option value="all" className="bg-popover text-popover-foreground">Todos los Roles</option>
              {allRoleNamesForFilter.map(roleName => (
                 <option key={roleName} value={roleName} className="bg-popover text-popover-foreground">{roleName.charAt(0).toUpperCase() + roleName.slice(1).replace(/_/g, ' ')}</option>
              ))}
            </select>
          </div>
          {canManage && (
            <Button 
              onClick={onAddUser} 
              variant="default"
              className="w-full md:w-auto text-sm py-2.5"
            >
              <UserPlus className="w-4.5 h-4.5 mr-2" />
              Añadir Usuario
            </Button>
          )}
        </div>
      </div>

      {filteredUsers.length > 0 ? (
         <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence>
            {filteredUsers.map(user => (
              <UserCard 
                key={user.id} 
                user={user} 
                onEdit={onEditUser} 
                onDelete={onDeleteUser}
                onToggleStatus={onToggleUserStatus}
                canManage={canManage}
              />
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-10 bg-card/50 rounded-xl">
            <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-text-main mb-2">No se encontraron usuarios</h3>
            <p className="text-text-secondary">Intenta ajustar los filtros o añade un nuevo usuario.</p>
        </div>
      )}
    </motion.div>
  );
};

export default ManageUsersView;
