
import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle as AlertTriangleIcon, ListChecks, SprayCan, ArrowRight, Zap, CheckCircle, Clock, Activity, UserCircle as UserCircleIcon, Crown } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { getUserRole } from '@/utils/rolePermissions';

const StatCard = ({ title, value, icon, gradientFrom, gradientTo, unit, onClick, ctaText = "Ver Detalles" }) => (
  <motion.div 
    whileHover={{ scale: 1.03, y: -5, boxShadow: "0 20px 25px -5px hsla(var(--primary-base), 0.1), 0 10px 10px -5px hsla(var(--primary-base), 0.04)" }}
    transition={{ type: "spring", stiffness: 300, damping: 20 }}
    onClick={onClick} 
    className={`bg-card backdrop-blur-md rounded-xl p-6 shadow-sm border-border cursor-pointer transform transition-all duration-300 ease-out overflow-hidden relative group`}
  >
    <div className={`absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity duration-300 bg-gradient-to-br ${gradientFrom} ${gradientTo}`}></div>
    <div className="relative z-10">
      <div className="flex items-center justify-between mb-3">
        <div className={`p-3 rounded-lg shadow-md bg-gradient-to-br ${gradientFrom} ${gradientTo}`}>
          {React.createElement(icon, { className: "w-6 h-6 text-primary-foreground" })}
        </div>
      </div>
      <p className="text-sm font-medium text-text-secondary mb-1">{title}</p>
      <p className="text-3xl font-bold text-text-main mb-1">
        {value} {unit && <span className="text-lg text-text-secondary">{unit}</span>}
      </p>
      <div className="flex items-center text-xs text-primary group-hover:underline transition-all">
        {ctaText}
        <ArrowRight className="w-3 h-3 ml-1 transform group-hover:translate-x-1 transition-transform" />
      </div>
    </div>
  </motion.div>
);

const RecentActivityItem = ({ title, type, status, date, icon, statusColorClass, statusBgClass, onClick }) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    whileHover={{ x: 5, backgroundColor: 'hsl(var(--accent))' }} 
    onClick={onClick} 
    className="flex items-center justify-between p-3 bg-card/70 rounded-lg hover:bg-accent transition-colors cursor-pointer border-border shadow-sm"
  >
    <div className="flex items-center space-x-3">
      <div className={`p-2.5 rounded-lg ${statusBgClass} border ${statusColorClass} border-opacity-30`}>
        {React.createElement(icon, { className: `w-5 h-5 ${statusColorClass}` })}
      </div>
      <div>
        <h3 className="font-semibold text-text-main text-sm">{title}</h3>
        <p className="text-xs text-text-secondary">{type} - {date}</p>
      </div>
    </div>
    <div className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusBgClass} ${statusColorClass}`}>
      {status}
    </div>
  </motion.div>
);

const getStatusDetails = status => {
  switch (status) {
    case 'pending': return { text: 'Pendiente', icon: Clock, colorClass: 'text-warning-foreground dark:text-yellow-300', bgClass: 'bg-warning/20' };
    case 'progress': return { text: 'En Progreso', icon: Activity, colorClass: 'text-primary', bgClass: 'bg-primary/10' };
    case 'completed': return { text: 'Completado', icon: CheckCircle, colorClass: 'text-success-foreground dark:text-green-300', bgClass: 'bg-success/20' };
    default: return { text: 'Desconocido', icon: Clock, colorClass: 'text-muted-foreground', bgClass: 'bg-muted/20' };
  }
};

const DashboardView = ({ incidents = [], tasks = [], cleaningJobs = [], handleShowToast, setActiveView, currentUser, appSettings }) => {
  const navigate = useNavigate();
  const openIncidents = incidents.filter(i => i.status !== 'completed').length;
  const pendingTasks = tasks.filter(t => t.status === 'pending').length;
  const dueCleaning = cleaningJobs.filter(c => c.status === 'pending').length;

  const userName = currentUser?.user_metadata?.name || currentUser?.email?.split('@')[0] || "Usuario";
  const userRole = getUserRole(currentUser);
  const roleDisplayName = userRole.charAt(0).toUpperCase() + userRole.slice(1).replace(/_/g, ' ');
  
  const myTasks = tasks.filter(task => task.assignedto === userName && task.status !== 'completed');

  const recentActivities = [
    ...incidents.sort((a,b) => new Date(b.reporteddate) - new Date(a.reporteddate)).slice(0, 2).map(i => ({
      title: i.title,
      type: `Incidencia en ${i.residence || 'N/A'}`,
      status: getStatusDetails(i.status).text,
      date: i.reporteddate,
      icon: getStatusDetails(i.status).icon,
      statusColorClass: getStatusDetails(i.status).colorClass,
      statusBgClass: getStatusDetails(i.status).bgClass,
      onClick: () => { navigate('/incidents'); }
    })),
    ...tasks.sort((a,b) => new Date(b.duedate) - new Date(a.duedate)).slice(0, 1).map(t => ({
      title: t.title,
      type: `Tarea: ${t.type}`,
      status: getStatusDetails(t.status).text,
      date: t.duedate,
      icon: getStatusDetails(t.status).icon,
      statusColorClass: getStatusDetails(t.status).colorClass,
      statusBgClass: getStatusDetails(t.status).bgClass,
      onClick: () => { navigate('/tasks'); }
    }))
  ].sort((a,b) => new Date(b.date) - new Date(a.date));

  const getRoleColor = (role) => {
    switch (role) {
      case 'super_admin':
      case 'administrador': return 'text-purple-500 dark:text-purple-400';
      case 'enfermera_jefe':
      case 'responsable': return 'text-blue-500 dark:text-blue-400';
      case 'enfermera': return 'text-green-500 dark:text-green-400';
      case 'técnico': return 'text-orange-500 dark:text-orange-400';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }} 
      className="space-y-6"
    >
      <div className="bg-card/80 backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
        <h1 className="text-2xl sm:text-3xl font-bold text-text-main">
          {appSettings?.welcomeMessage || '¡Bienvenido de nuevo!'}, {userName}!
        </h1>
        <p className="text-text-secondary mt-1 flex items-center">
          Aquí tienes un resumen de tu actividad como 
          <span className={`ml-1.5 flex items-center font-medium ${getRoleColor(userRole)}`}>
            <Crown className="w-4 h-4 mr-1" />
            {roleDisplayName}
          </span>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard title="Incidencias Abiertas" value={openIncidents} icon={AlertTriangleIcon} gradientFrom="from-destructive/70" gradientTo="to-orange-500/70" onClick={() => navigate('/incidents')} ctaText="Gestionar Incidencias"/>
        <StatCard title="Tareas Pendientes" value={pendingTasks} icon={ListChecks} gradientFrom="from-primary/70" gradientTo="to-sky-500/70" onClick={() => navigate('/tasks')} ctaText="Administrar Tareas"/>
        <StatCard title="Limpiezas Programadas" value={dueCleaning} icon={SprayCan} gradientFrom="from-success/70" gradientTo="to-emerald-500/70" onClick={() => navigate('/cleaning')} ctaText="Controlar Limpieza"/>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-card backdrop-blur-md rounded-xl p-6 shadow-sm border-border">
            <h2 className="text-xl font-semibold text-text-main flex items-center mb-4">
              <UserCircleIcon className="w-6 h-6 mr-2 text-primary"/>
              Mis Tareas Asignadas
            </h2>
            <div className="space-y-3">
              {myTasks.length > 0 ? myTasks.slice(0, 4).map((task, index) => (
                <RecentActivityItem 
                  key={index} 
                  title={task.title}
                  type={`Vence: ${task.duedate}`}
                  status={getStatusDetails(task.status).text}
                  date={task.type}
                  icon={getStatusDetails(task.status).icon}
                  statusColorClass={getStatusDetails(task.status).colorClass}
                  statusBgClass={getStatusDetails(task.status).bgClass}
                  onClick={() => navigate('/mytasks')}
                />
              )) : (
                <p className="text-text-secondary text-center py-6">No tienes tareas asignadas pendientes.</p>
              )}
              {myTasks.length > 0 && (
                <div className="pt-2">
                   <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => navigate('/mytasks')}
                      className="w-full"
                    >
                      Ver todas mis tareas ({myTasks.length})
                    </Button>
                  </motion.div>
                </div>
              )}
            </div>
        </Card>
        
        <div className="bg-gradient-to-br from-primary via-blue-500 to-sky-500 dark:from-primary/50 dark:via-blue-500/50 dark:to-sky-500/50 rounded-xl p-6 shadow-lg text-white">
           <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold flex items-center">
              <Zap className="w-6 h-6 mr-2"/>
              Asistente IA
            </h2>
          </div>
          <p className="opacity-90 mb-4 text-sm">
            Nuestro asistente inteligente te ayuda a optimizar la gestión.
          </p>
          <ul className="space-y-1.5 text-sm opacity-90 mb-5">
            {[
              "Priorización automática de tareas.",
              "Sugerencias proactivas.",
              "Respuestas a dudas frecuentes."
            ].map((item, idx) => (
              <li key={idx} className="flex items-start">
                <CheckCircle className="w-4 h-4 mr-2 mt-0.5 shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
           <Button 
            onClick={() => navigate('/chat')} 
            className="w-full bg-white/20 hover:bg-white/30 text-white font-semibold py-2.5 px-4 rounded-lg shadow-lg transition-all"
          >
            Hablar con el Asistente
          </Button>
        </div>
      </div>
    </motion.div>
  );
};
export default DashboardView;