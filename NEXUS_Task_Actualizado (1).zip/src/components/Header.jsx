
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Bell, Settings, Sun, Moon, LogOut, UserCircle, Crown, Menu, ArrowLeft } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getUserRole, getRoleStyle } from '@/utils/rolePermissions';
import { useTranslation } from 'react-i18next';

const Header = ({ appName, handleShowToast, theme, toggleTheme, onLogout, currentUser, appSettings, tasks, onOpenEditProfile, onOpenAccountSettings, onNavigate, setIsMobileSidebarOpen, location, navigate }) => {
  const { t } = useTranslation();
  const userName = currentUser?.user_metadata?.name || currentUser?.email || "Usuario";
  const userInitial = userName.charAt(0).toUpperCase();
  const userRole = getUserRole(currentUser);
  const roleStyle = getRoleStyle(userRole);
  const roleDisplayName = userRole.charAt(0).toUpperCase() + userRole.slice(1).replace(/_/g, ' ');

  const overdueTasksCount = Array.isArray(tasks) ? tasks.filter(t => new Date(t.duedate) < new Date() && t.status !== 'completed').length : 0;

  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/83d8e912-765e-4cb9-9d9a-78a069036ea4/c03bb469b45307bd4ce8d6847a053a22.png";

  const isDashboard = location.pathname === '/dashboard' || location.pathname === '/';

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card/80 backdrop-blur-lg border-b border-border sticky top-0 z-40 shadow-sm"
    >
      <div className="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="lg:hidden flex items-center">
              {!isDashboard ? (
                <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="Volver atrás">
                  <ArrowLeft className="w-6 h-6" />
                </Button>
              ) : (
                <Button variant="ghost" size="icon" onClick={() => setIsMobileSidebarOpen(true)} aria-label="Abrir menú">
                  <Menu className="w-6 h-6" />
                </Button>
              )}
            </div>
            <div className={`${!isDashboard ? 'hidden lg:flex' : 'flex'} items-center space-x-2`}>
              <img src={logoUrl} alt="NEXUS Task Logo" className="h-10 w-auto" />
            </div>
          </div>
          
          <div className="flex items-center space-x-1 sm:space-x-2">
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button variant="ghost" size="icon" className="text-text-secondary hover:text-primary hover:bg-accent" onClick={toggleTheme} aria-label={t('header.changeTheme')}>
                {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button variant="ghost" size="icon" className="text-text-secondary hover:text-primary hover:bg-accent relative" onClick={() => onNavigate('/notifications')} aria-label={t('header.viewNotifications')}>
                <Bell className="w-5 h-5" />
                {overdueTasksCount > 0 && (
                   <motion.span
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
                    className="absolute top-2 right-2 flex h-2.5 w-2.5"
                  >
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-destructive"></span>
                  </motion.span>
                )}
              </Button>
            </motion.div>
            
            <div className="lg:hidden">
              <Button variant="ghost" size="icon" onClick={() => setIsMobileSidebarOpen(true)} aria-label="Abrir menú">
                <Menu className="w-6 h-6" />
              </Button>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                 <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }} className="hidden lg:block">
                  <Button variant="ghost" className="flex items-center space-x-2 px-2 py-1 h-auto rounded-full hover:bg-accent">
                     <Avatar className="w-8 h-8">
                       <AvatarImage src={currentUser.user_metadata?.avatar_url} />
                       <AvatarFallback className={`${roleStyle.avatar} font-bold`}>{userInitial}</AvatarFallback>
                     </Avatar>
                    <div className="hidden md:block text-left">
                      <div className="text-sm font-medium text-text-main">{userName}</div>
                      <div className={`text-xs flex items-center ${roleStyle.text}`}>
                        <Crown className="w-3 h-3 mr-1" />
                        {roleDisplayName}
                      </div>
                    </div>
                  </Button>
                </motion.div>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-popover border-border text-popover-foreground shadow-xl mt-2">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none text-text-main">{userName}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {currentUser?.email}
                    </p>
                    <p className={`text-xs leading-none flex items-center ${roleStyle.text}`}>
                      <Crown className="w-3 h-3 mr-1" />
                      {roleDisplayName}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-border" />
                <DropdownMenuItem onClick={onOpenEditProfile} className="hover:!bg-accent focus:!bg-accent cursor-pointer">
                  <UserCircle className="w-4 h-4 mr-2 text-muted-foreground" /> {t('header.editProfile')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onOpenAccountSettings} className="hover:!bg-accent focus:!bg-accent cursor-pointer">
                  <Settings className="w-4 h-4 mr-2 text-muted-foreground" /> {t('header.accountSettings')}
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-border" />
                <DropdownMenuItem onClick={onLogout} className="text-destructive hover:!bg-destructive/10 focus:!bg-destructive/10 cursor-pointer">
                  <LogOut className="w-4 h-4 mr-2" /> {t('header.logout')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
