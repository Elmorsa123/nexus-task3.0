
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar as CalendarIcon, User, Tag, ListChecks, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { hasPermission } from '@/utils/rolePermissions';

const AddTaskModal = ({ onClose, onSave, users, preselectedUserId, currentUser }) => {
  const [task, setTask] = useState({
    title: '',
    details: '',
    type: 'Mantenimiento',
    priority: 'medium',
    status: 'pending',
    assignedto: preselectedUserId || (users.length > 0 ? 'NONE' : ''),
    duedate: '',
    zone: ''
  });

  useEffect(() => {
    if (preselectedUserId) {
      setTask(prev => ({ ...prev, assignedto: preselectedUserId }));
    }
  }, [preselectedUserId]);

  const [errors, setErrors] = useState({});

  const validate = () => {
    let tempErrors = {};
    if (!task.title.trim()) tempErrors.title = "El título es obligatorio.";
    if (!task.duedate) tempErrors.duedate = "La fecha de vencimiento es obligatoria.";
    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (validate()) {
      onSave(task);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTask({ ...task, [name]: value });
  };
  
  const handleSelectChange = (name, value) => {
    setTask({ ...task, [name]: value });
  };

  const canAssignTasks = hasPermission(currentUser, 'canAssignTasks');

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="bg-card border-border w-full max-w-lg rounded-2xl shadow-xl relative"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between p-6 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 p-2 rounded-lg">
                <ListChecks className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-xl font-semibold text-text-main">Añadir Nueva Tarea</h2>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
              <X className="w-5 h-5" />
            </Button>
          </div>
          <form onSubmit={handleSave}>
            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="space-y-2">
                <Label htmlFor="title">Título de la Tarea</Label>
                <Input
                  id="title"
                  name="title"
                  value={task.title}
                  onChange={handleChange}
                  placeholder="Ej: Reparar la puerta principal"
                  className={errors.title ? 'border-destructive' : ''}
                />
                {errors.title && <p className="text-xs text-destructive">{errors.title}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Categoría</Label>
                  <Select name="type" value={task.type} onValueChange={(value) => handleSelectChange('type', value)}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Seleccionar categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Mantenimiento">Mantenimiento</SelectItem>
                      <SelectItem value="Limpieza">Limpieza</SelectItem>
                      <SelectItem value="Jardinería">Jardinería</SelectItem>
                      <SelectItem value="Otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="priority">Prioridad</Label>
                  <Select name="priority" value={task.priority} onValueChange={(value) => handleSelectChange('priority', value)}>
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Seleccionar prioridad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Baja</SelectItem>
                      <SelectItem value="medium">Media</SelectItem>
                      <SelectItem value="high">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div className="space-y-2">
                    <Label htmlFor="assignedto">Asignar a</Label>
                    <Select name="assignedto" value={task.assignedto} onValueChange={(value) => handleSelectChange('assignedto', value)} disabled={!canAssignTasks}>
                        <SelectTrigger id="assignedto">
                            <SelectValue placeholder="Seleccionar usuario" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="NONE">Sin Asignar</SelectItem>
                            {users.map(user => (
                                <SelectItem key={user.id} value={user.name}>{user.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    {!canAssignTasks && <p className="text-xs text-muted-foreground">No tienes permisos para asignar tareas.</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="duedate">Fecha de Vencimiento</Label>
                   <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={`w-full justify-start text-left font-normal ${!task.duedate && "text-muted-foreground"} ${errors.duedate ? 'border-destructive' : ''}`}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {task.duedate ? format(new Date(task.duedate), "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={task.duedate ? new Date(task.duedate) : null}
                        onSelect={(date) => handleSelectChange('duedate', date ? format(date, 'yyyy-MM-dd') : '')}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  {errors.duedate && <p className="text-xs text-destructive">{errors.duedate}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="details">Detalles Adicionales</Label>
                <Textarea
                  id="details"
                  name="details"
                  value={task.details}
                  onChange={handleChange}
                  placeholder="Añade una descripción más detallada de la tarea..."
                  rows={3}
                />
              </div>
            </div>
            <div className="flex items-center justify-end p-6 border-t border-border bg-background/50 rounded-b-2xl">
              <Button type="button" variant="ghost" onClick={onClose} className="mr-2">Cancelar</Button>
              <Button type="submit">Guardar Tarea</Button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default AddTaskModal;